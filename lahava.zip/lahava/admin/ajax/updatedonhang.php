<?php 
require_once("../lib/classQuanTri.php");
$qt = new quantri;	

$idDH = (int) $_POST['idDH'];
$status = (int) $_POST['status'];
$sql = "UPDATE donhang SET status = $status WHERE idDH = $idDH";
mysql_query($sql);
?>