<?php
function resizeHoang($file,$width,$height,$file_name,$des){
	require_once "lib/class.resize.php";
	$re = new resizes;
	$re->load($file);
	$re->resize($width,$height);
	$re->save($des.$file_name); 
}
$allowedExts = array("jpg", "jpeg", "gif", "png");
$arrRes['text'] = "<div><ul>";
$strHinhAnh = "";

if(!is_dir("../upload/".date('Y')."/".date('m')."/".date('d')."/"))
mkdir("../upload/".date('Y')."/".date('m')."/".date('d')."/",0777,true);

if(!is_dir("../upload/".date('Y')."/".date('m')."/".date('d')."/330/"))
mkdir("../upload/".date('Y')."/".date('m')."/".date('d')."/330/",0777,true);

if(!is_dir("../upload/".date('Y')."/".date('m')."/".date('d')."/255/"))
mkdir("../upload/".date('Y')."/".date('m')."/".date('d')."/255/",0777,true);

if(!is_dir("../upload/".date('Y')."/".date('m')."/".date('d')."/54/"))
mkdir("../upload/".date('Y')."/".date('m')."/".date('d')."/54/",0777,true);

if(!is_dir("../upload/".date('Y')."/".date('m')."/".date('d')."/65/"))
mkdir("../upload/".date('Y')."/".date('m')."/".date('d')."/65/",0777,true);

$url = "../upload/".date('Y')."/".date('m')."/".date('d')."/";

for($i=0;$i<count($_FILES['images']['name']);$i++){
	$extension = end(explode(".", $_FILES["images"]["name"][$i]));
	if ((($_FILES["images"]["type"][$i] == "image/gif") || ($_FILES["images"]["type"][$i] == "image/jpeg") || ($_FILES["images"]["type"][$i] == "image/png")
	|| ($_FILES["images"]["type"][$i] == "image/pjpeg"))	
	&& in_array($extension, $allowedExts))
	  {
	  if ($_FILES["images"]["error"][$i] > 0)
		{
		//echo "Return Code: " . $_FILES["images"]["error"][$i] . "<br />";
		}
	  else
		{		
	
		if (file_exists($url. $_FILES["images"]["name"][$i]))
		  {
		  //echo $_FILES["images"]["name"][$i] . " đã tồn tại. "."<br />";		 
		  }
		else
		  {
		  if(move_uploaded_file($_FILES["images"]["tmp_name"][$i],
		  $url. $_FILES["images"]["name"][$i])==true){
			resizeHoang(
				$url.$_FILES["images"]["name"][$i],
				330,450,
				$_FILES["images"]["name"][$i],
				$url."330/"
			); 
			resizeHoang(
				$url.$_FILES["images"]["name"][$i],
				255,360,
				$_FILES["images"]["name"][$i],
				$url."255/"
			); 
			resizeHoang(
				$url.$_FILES["images"]["name"][$i],
				54,80,
				$_FILES["images"]["name"][$i],
				$url."54/"
			);  
			resizeHoang(
				$url.$_FILES["images"]["name"][$i],
				65,83,
				$_FILES["images"]["name"][$i],
				$url."65/"
			);  
		  	$count++;
			$strHinhAnh.= str_replace("../","",$url). $_FILES["images"]["name"][$i].";";
			$arrRes['text'] .="<li style='float:left;display:inline;margin-right:10px;text-align:center'>
				<img src='".$url. $_FILES["images"]["name"][$i]."' width='100' /><br />
				<input type='radio' name='hinh_dai_dien' value='".str_replace("../","",$url).$_FILES["images"]["name"][$i]."' /></li>";
			
		  }
		  }
		}
		
	  }
	  
	  $arrRes['text'].="</ul></div>";
}

if($count>0){
	$strHinhAnh= substr($strHinhAnh,0,-1);
	$arrRes['thongbao'] = "Upload thành công $count images";
	$arrRes['str_hinhanh']="<input type='hidden' name='hinh_anh' value='".$strHinhAnh."'>";
}else{
	$arrRes['thongbao'] = "Có lỗi xảy ra ! Không upload được file .";
}
echo json_encode($arrRes);
?>