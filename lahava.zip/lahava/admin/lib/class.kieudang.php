<?php 
require_once "class.db.php";
class kieudang extends db{
	
	function Kieu_Them(&$loi){	
	
		$thanhcong=true;
		
		$kieu_vi= $this->processData($_POST[kieu_vi]);
		$kieu_en= $this->processData($_POST[kieu_en]);		
       
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO kieu
					VALUES(NULL,'$kieu_vi','$kieu_en')";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	
	function Kieu_Edit($kieu_id,&$loi){
		settype($kieu_id,"int");
		$thanhcong=true;
		
		$thanhcong=true;
		
		$kieu_vi= $this->processData($_POST[kieu_vi]);
		$kieu_en= $this->processData($_POST[kieu_en]);		
       
		
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE kieu 
					SET kieu_vi = '$kieu_vi',kieu_en = '$kieu_en'
					WHERE kieu_id = $kieu_id";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function getListKieuDang(){
		$sql = "SELECT * FROM kieu ORDER BY kieu_id ASC  ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function Kieu_ChiTiet($kieu_id){
		$sql = "SELECT * FROM kieu WHERE kieu_id = $kieu_id";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
}

?>