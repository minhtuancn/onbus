<?php 
require_once "class.db.php";
class donhang extends db{
	
	/* QUAN LY USER */
	
	function DonHang_List($status= -1,$limit=-1,$offset=-1){
		$sql = "SELECT * FROM donhang WHERE (status = $status OR $status = -1) 
				ORDER BY idDH DESC ";
		if($limit >0 && $offset >=0) $sql.= " LIMIT $offset,$limit";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getDetailDonHang($idDH){
		$arrList = array();
		$sql = "SELECT * FROM donhangct WHERE idDH = $idDH";		
		$rs = mysql_query($sql) or die(mysql_error());
		while($row = mysql_fetch_assoc($rs)){
			$arrList[] = $row;
		};		
		return $arrList;
	}	
}

?>