<?php 
require_once "class.db.php";
class chatlieu extends db{
	

	function getListChatLieu($lang='vi'){
		$sql = "SELECT * FROM chatlieu ORDER BY chat_id ASC ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getDetailChatLieu($chat_id){
		$sql = "SELECT * FROM chatlieu WHERE chat_id =$chat_id ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}	

	function Chat_Them(&$loi){	
	
		$thanhcong=true;
		
		$chat_vi= $this->processData($_POST[chat_vi]);
		$chat_en= $this->processData($_POST[chat_en]);		
       
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO chatlieu
					VALUES(NULL,'$chat_vi','$chat_en')";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	
	function Chat_Edit($chat_id,&$loi){
		settype($chat_id,"int");
		$thanhcong=true;
		
		$thanhcong=true;
		
		$chat_vi= $this->processData($_POST[chat_vi]);
		$chat_en= $this->processData($_POST[chat_en]);		
       
		
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE chatlieu 
					SET chat_vi = '$chat_vi',chat_en = '$chat_en'
					WHERE chat_id = $chat_id";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function Chat_ChiTiet($chat_id){
		$sql = "SELECT * FROM chatlieu WHERE chat_id = $chat_id";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	
}

?>