<?php 
require_once "class.db.php";
class khachhang extends db{
	
	/* QUAN LY USER */
	
	function getDetailCustommer($idKH){
		$sql = "SELECT * FROM khachhang WHERE idKH = $idKH";		
		$rs = mysql_query($sql) or die(mysql_error());
		$arrDetail = mysql_fetch_assoc($rs);
		return $arrDetail;
	}
	function KhachHang_List($limit=-1,$offset=-1){
		$sql = "SELECT * FROM khachhang ORDER BY tongtien DESC ";
		if($limit >0 && $offset >=0) $sql.= " LIMIT $offset,$limit";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
}

?>