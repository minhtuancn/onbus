<?php 
require_once "class.db.php";
class sanpham extends db{	
	/* SAN PHAM */
	function SanPham_Them(&$loi){
       
        $thanhcong=true;
		$loai_id =(int) $_POST[loai_id];
		$kieu_id =(int) $_POST[kieu_id];
		
		$ma_sp = $this->processData($_POST[ma_sp]);
		
		$ten_sp_vi = $this->processData($_POST[ten_sp_vi]);
		$ten_sp_vi_kd = $this->processData($_POST[ten_sp_vi_kd]);
		
		$ten_sp_en = $this->processData($_POST[ten_sp_en]);
		$ten_sp_en_kd = $this->processData($_POST[ten_sp_en_kd]);
		
		$gia = $this->processData($_POST[gia]);
		$khuyen_mai = $this->processData($_POST[khuyen_mai]);	
		
		$ngay = date('Y-m-d',strtotime($this->processData($_POST[ngay])));
		
		$hinh_dai_dien = $this->processData($_POST[hinh_dai_dien]);
		$hinh_anh = $this->processData($_POST[hinh_anh]);	
      
		
		
		$mo_ta_vi = $this->processData($_POST[mo_ta_vi]);
		$mo_ta_en = $this->processData($_POST[mo_ta_en]);

	
		
		$tags_vi = rtrim(trim($_POST[tags_vi]),";");
		$tags_vi = str_replace(',',';',$tags_vi);
		
		$tags_en = rtrim(trim($_POST[tags_en]),";");
		$tags_en = str_replace(',',';',$tags_en);		
		$arrTagVi  = explode("; ",$tags_vi);		
	    $arrTagEn  = explode("; ",$tags_en);	
		
		$arrChat = $_POST['chat_id'];	
		$arrMau = $_POST['mau'];
		$arrKieu = $_POST['kieu_id'];
		$arrLoai = $_POST['loai_id'];
		$arrSize = $_POST['size'];		
	
			
		if($ten_sp_vi_kd=="") $ten_sp_vi_kd = $this->changeTitle($ten_sp_vi);
		if($ten_sp_en_kd=="") $ten_sp_en_kd = $this->changeTitle($ten_sp_en);
				
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO sanpham
					VALUES(NULL,'$ma_sp','$ten_sp_vi','$ten_sp_vi_kd','$ten_sp_en',
					'$ten_sp_en_kd','$mo_ta_vi','$mo_ta_en','$hinh_dai_dien','$hinh_anh',
                    '$gia','$khuyen_mai','$ngay')";
			mysql_query($sql) or die(mysql_error().$sql);	
			$sp_id = mysql_insert_id();
			foreach($arrMau as $maus){
				mysql_query("INSERT INTO sp_mau VALUES($sp_id,$maus)");				
			}
			foreach($arrSize as $sizes){
				mysql_query("INSERT INTO sp_size VALUES($sp_id,$sizes)");				
			}
			foreach($arrKieu as $kieu_id){
				mysql_query("INSERT INTO sp_kieu VALUES($kieu_id,$sp_id)");				
			}
			foreach($arrLoai as $loai_id){
				mysql_query("INSERT INTO sp_loai VALUES($loai_id,$sp_id)");				
			}
			foreach($arrChat as $chat_id){
				mysql_query("INSERT INTO sp_chat VALUES($chat_id,$sp_id)");				
			}
						
			/* Tags */
			if(!empty($arrTagVi)){
				foreach($arrTagVi as $tag){
					$tag_id = $this->checkTagTonTai($tag,"vi");
					$this->addTagToArticle($sp_id,$tag_id,"vi");
				}
			}
			if(!empty($arrTagEn)){
				foreach($arrTagEn as $tag){
					$tag_id = $this->checkTagTonTai($tag,"en");
					$this->addTagToArticle($sp_id,$tag_id,"en");
				}
			}	
		}
		return $thanhcong;
    }
    
    function SanPham_Sua($sp_id,&$loi){
        settype($sp_id,"int");
       $thanhcong=true;
		$loai_id =(int) $_POST[loai_id];
		$kieu_id =(int) $_POST[kieu_id];
		

		
		$ma_sp = $this->processData($_POST[ma_sp]);
		
		$ten_sp_vi = $this->processData($_POST[ten_sp_vi]);
		$ten_sp_vi_kd = $this->processData($_POST[ten_sp_vi_kd]);
		
		$ten_sp_en = $this->processData($_POST[ten_sp_en]);
		$ten_sp_en_kd = $this->processData($_POST[ten_sp_en_kd]);
		
		$gia = $this->processData($_POST[gia]);
		$khuyen_mai = $this->processData($_POST[khuyen_mai]);	
		
		$ngay = date('Y-m-d',strtotime($this->processData($_POST[ngay])));
		
		$hinh_dai_dien = $this->processData($_POST[hinh_dai_dien]);
		$hinh_anh_cu = $this->processData($_POST[hinh_anh_cu]);	
      	$hinh_anh = $this->processData($_POST['hinh_anh']);
		if($hinh_anh !=''){
			if($hinh_anh_cu !=''){
				$hinh_anh = $hinh_anh_cu . ";".$hinh_anh;
			}else{
				$hinh_anh = $hinh_anh;
			}			
		}else{
			$hinh_anh = $hinh_anh_cu;
		}
		
		$mo_ta_vi = $this->processData($_POST[mo_ta_vi]);
		$mo_ta_en = $this->processData($_POST[mo_ta_en]);	
		
		$tags_vi = rtrim(trim($_POST[tags_vi]),";");
		$tags_vi = str_replace(',',';',$tags_vi);

		$tags_en = rtrim(trim($_POST[tags_en]),";");
		$tags_en = str_replace(',',';',$tags_en);		
		if($tags_vi != '') $arrTagVi  = explode("; ",$tags_vi);		
	    if($tags_en != '') $arrTagEn  = explode("; ",$tags_en);	
		
		$arrChat = $_POST['chat_id'];	
		$arrMau = $_POST['mau'];
		$arrKieu = $_POST['kieu_id'];
		$arrLoai = $_POST['loai_id'];
		$arrSize = $_POST['size'];		
	
			
		if($ten_sp_vi_kd=="") $ten_sp_vi_kd = $this->changeTitle($ten_sp_vi);
		if($ten_sp_en_kd=="") $ten_sp_en_kd = $this->changeTitle($ten_sp_en);
				
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE sanpham SET
					ma_sp = '$ma_sp',ten_sp_vi = '$ten_sp_vi',
					ten_sp_vi_kd = '$ten_sp_vi_kd',ten_sp_en = '$ten_sp_en',
					ten_sp_en_kd = '$ten_sp_en_kd',mo_ta_vi ='$mo_ta_vi',
					mo_ta_en = '$mo_ta_en',hinh_dai_dien = '$hinh_dai_dien',
					hinh_anh = '$hinh_anh',gia = '$gia',
					khuyen_mai = '$khuyen_mai',ngay = '$ngay'
					WHERE sp_id = $sp_id";
			mysql_query($sql) or die(mysql_error().$sql);			
		
			
			if(mysql_query("DELETE FROM sp_mau WHERE sp_id = $sp_id")){
				foreach($arrMau as $maus){
					mysql_query("INSERT INTO sp_mau VALUES($sp_id,$maus)");				
				}
			}
			if(mysql_query("DELETE FROM sp_size WHERE sp_id = $sp_id")){
				foreach($arrSize as $sizes){
					mysql_query("INSERT INTO sp_size VALUES($sp_id,$sizes)");				
				}
			}
			if(mysql_query("DELETE FROM sp_kieu WHERE sp_id = $sp_id")){
				foreach($arrKieu as $kieu_id){
					mysql_query("INSERT INTO sp_kieu VALUES($kieu_id,$sp_id)");				
				}
			}
			if(mysql_query("DELETE FROM sp_loai WHERE sp_id = $sp_id")){
				foreach($arrLoai as $loai_id){
					mysql_query("INSERT INTO sp_loai VALUES($loai_id,$sp_id)");				
				}
			}
			if(mysql_query("DELETE FROM sp_chat WHERE sp_id = $sp_id")){
				foreach($arrChat as $chat_id){
					mysql_query("INSERT INTO sp_chat VALUES($chat_id,$sp_id)");				
				}
			}		
				/* Tags */
				if(!empty($arrTagVi)){					
					mysql_query("DELETE FROM sp_tag WHERE sp_id = $sp_id AND lang ='vi'");
					foreach($arrTagVi as $tag_v){
						$tag_id = $this->checkTagTonTai($tag_v,"vi");
						$this->addTagToArticle($sp_id,$tag_id,"vi");
					}
				}else{
					mysql_query("DELETE FROM sp_tag WHERE sp_id = $sp_id AND lang ='vi'");
				}
				if(!empty($arrTagEn)){					
					mysql_query("DELETE FROM sp_tag WHERE sp_id = $sp_id AND lang ='en'");
					foreach($arrTagEn as $tag_e){
						$tag_id = $this->checkTagTonTai($tag_e,"en");
						$this->addTagToArticle($sp_id,$tag_id,"en");
					}
				}else{
					mysql_query("DELETE FROM sp_tag WHERE sp_id = $sp_id AND lang ='en'");
				}
			
		}
		return $thanhcong;
    }
	
		function getDetailSP($sp_id){
			$sql= "SELECT * 
				FROM sanpham
				WHERE sp_id = $sp_id";
            $rs= mysql_query($sql) or die(mysql_error());
            return $rs;
		}
		function SanPham_List($loai_id,$tukhoa='',$limit=-1,$offset=-1){
			$sql = "SELECT sp_id,ten_sp_vi,hinh_dai_dien FROM sanpham 
					WHERE ten_sp_vi != ''";
			if($tukhoa!="") $sql.=" AND ten_sp_vi LIKE '%$tukhoa%' ";															
				$sql.="	ORDER BY sp_id DESC ";
			if($limit >0 && $offset >=0) $sql.= " LIMIT $offset,$limit";
	
			$rs = mysql_query($sql) or die(mysql_error());
			return $rs;					
		}
		
		function getSPNext($sp_id,$loai_id){
			$array = array();
			$sql = "SELECT MIN(sp_id) as sp_id FROM sp_loai WHERE sp_id > $sp_id AND loai_id IN('$loai_id')";
			$rs = mysql_query($sql);
			$kq = mysql_fetch_assoc($rs);			
			if($kq['sp_id']==NULL){
				return $array;
			}else{
				$sp = $this->getDetailSP($kq['sp_id']);
				$array = mysql_fetch_assoc($sp);
				return $array;
			}
		}
		function getSPPrev($sp_id,$loai_id){
			$array = array();
			$sql = "SELECT MAX(sp_id) as sp_id FROM sp_loai WHERE sp_id < $sp_id AND loai_id IN('$loai_id')";
			$rs = mysql_query($sql);
			$kq = mysql_fetch_assoc($rs);			
			if($kq['sp_id']==NULL){
				return $array;
			}else{
				$sp = $this->getDetailSP($kq['sp_id']);
				$array = mysql_fetch_assoc($sp);
				return $array;
			}
		}	
		function getLoaiId($sp_id){
			$sql = "SELECT loai_id FROM sp_loai WHERE sp_id = $sp_id";
			$rs = mysql_query($sql);
			$strLoai_id = '';
			while($row = mysql_fetch_assoc($rs)){
				$strLoai_id .= $row['loai_id'].",";
			}
			$strLoai_id = rtrim($strLoai_id,",");
			return $strLoai_id;
		}
		function getLoaiIdByProductId($sp_id){
			$arr = array();
			$sql = "SELECT loai_id FROM sp_loai WHERE sp_id = $sp_id";
			$rs = mysql_query($sql);			
			while($row = mysql_fetch_assoc($rs)){
				$arr[] = $row['loai_id']; 
			}
			return $arr;
		}
		function getKieuIdByProductId($sp_id){
			$arr = array();
			$sql = "SELECT kieu_id FROM sp_kieu WHERE sp_id = $sp_id";
			$rs = mysql_query($sql);			
			while($row = mysql_fetch_assoc($rs)){
				$arr[] = $row['kieu_id']; 
			}
			return $arr;
		}
		function getChatIdByProductId($sp_id){
			$arr = array();
			$sql = "SELECT chat_id FROM sp_chat WHERE sp_id = $sp_id";
			$rs = mysql_query($sql);			
			while($row = mysql_fetch_assoc($rs)){
				$arr[] = $row['chat_id']; 
			}
			return $arr;
		}
		function getTagsByProductId($sp_id,$lang='vi'){
			$sql = "SELECT tag_id FROM sp_tag WHERE sp_id = $sp_id AND lang = '$lang'";
			$rs = mysql_query($sql);
			return $rs;
		}
		function getTagsOfProductId($sp_id,$lang='vi'){
			$arr = array();
			$sql = "SELECT tag_id FROM sp_tag WHERE sp_id = $sp_id AND lang = '$lang'";
			$rs = mysql_query($sql);
			while($row = mysql_fetch_assoc($rs)){
				$arr[] = $row['tag_id']; 
			}
			return $arr;
		}
		function getDetailTag($tag_id){
			$sql = "SELECT * FROM tag WHERE tag_id = $tag_id";
			$rs = mysql_query($sql);
			return $rs;
		}
		
		function getSizeIdByProductId($sp_id){
			$arr = array();
			$sql = "SELECT size_id FROM sp_size WHERE sp_id = $sp_id";
			$rs = mysql_query($sql);			
			while($row = mysql_fetch_assoc($rs)){
				$arr[] = $row['size_id']; 
			}
			return $arr;
		}
		function getMauIdByProductId($sp_id){
			$arr = array();
			$sql = "SELECT mau_id FROM sp_mau WHERE sp_id = $sp_id";
			$rs = mysql_query($sql);			
			while($row = mysql_fetch_assoc($rs)){
				$arr[] = $row['mau_id']; 
			}
			return $arr;
		}
}

?>