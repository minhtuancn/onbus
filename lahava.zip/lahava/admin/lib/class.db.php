<?php 
error_reporting(E_ALL ^ E_NOTICE);
session_start();
require_once('phpmailer/class.phpmailer.php'); 
define('GUSER', 'lahavafashion2013@gmail.com');
define('GPWD', '15789hoang'); 
class db{   
    private $host = "localhost";
	private $user = "lahava_lahava";
	private $pass = "lahavavn@2012";	
	private $db = "lahavanew";
	function __construct(){		
		//mysql_connect("localhost",'lahava_lahava','lahavavn@2012');
		mysql_connect("localhost",'root','root');
		mysql_select_db($this->db) or die("Can't connect database");
		mysql_query("SET NAMES 'utf8'") or die(mysql_error());	
	}
	function processData($str)
	{
		$str=trim(strip_tags($str));	
		if (get_magic_quotes_gpc()== false) {
			$str = mysql_real_escape_string($str);			
		}
		return $str;
	}	
	function getArrImages($str){
		$arrImg = explode(";",$str);
		return $arrImg;
	}
	function getInfoSeo($table,$pk,$id){
		$sql = "SELECT title ,metad,metak FROM $table WHERE $pk = '$id'";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);
		$data = array($row['title'],$row['metad'],$row['metak']);
		return $data;
	}
		
	function string_limit($str,$limit){
		if (strlen($str) <= $limit) { 
			$str = $str;
		} 
		else { 
			$str = wordwrap($str,$limit); 
			$str = substr($str, 0, strpos($str, "\n"));					
		} 		
		return $str;	
	}
	
	function phantrang($page,$page_show,$total_page,$link){
		$dau=1;
		$cuoi=0;
		$dau=$page - floor($page_show/2);		
		if($dau<1) $dau=1;	
		$cuoi=$dau+$page_show;
		if($cuoi>$total_page)
		{
			
			$cuoi=$total_page+1;
			$dau=$cuoi-$page_show;
			if($dau<1) $dau=1;
		}
		echo "<div id='thanhphantrang'>";
		if($page > 1){
			($page==1) ? $class = " class='selected'" : $class="" ;	
			echo "<a".$class." href=".$link."&page=1>Đầu</a>"	;							
		}
		for($i=$dau; $i<$cuoi; $i++)
		{
			($page==$i) ? $class = " class='selected'" : $class="" ;		
			echo "<a".$class." href=".$link."&page=$i>$i</a>";			
		}
		if($page < $total_page) { 
			($page==$total_page) ? $class = " class='selected'" : $class="" ;		
			echo "<a".$class." href=".$link."&page=$total_page>Cuối</a>";
		}
		echo "</div>";
	}
    function ThuTuMax($table)
    {
        $sql = "SELECT MAX(ThuTu) as max FROM $table";
        $rs = mysql_query($sql);
        $row = mysql_fetch_assoc($rs);
        return $row[max];
        
    }
	
	function LayThuTuLen($table,$ThuTu){
		$sql = "SELECT MAX(ThuTu) as ThuTu_Len FROM $table WHERE ThuTu < $ThuTu";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);
		return $row[ThuTu_Len];
	}
	function LayThuTuXuong($table,$ThuTu){
		$sql = "SELECT MIN(ThuTu) as ThuTu_Xuong FROM $table WHERE ThuTu > $ThuTu";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);
		return $row[ThuTu_Xuong];
	}
	function LayId_DuaVaoThuTu($table,$tencot,$ThuTu)
	{
		$sql = "SELECT  $tencot  FROM $table WHERE ThuTu = $ThuTu";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);
		return $row[$tencot];
	}
	function ThuTuMin($table)
    {
        $sql = "SELECT MIN(ThuTu) as ThuTuMin FROM $table";
        $rs = mysql_query($sql);
        $row = mysql_fetch_assoc($rs);
        return $row[ThuTuMin];
        
    }
	
	function cat_gioi_han($str,$so_ky_tu){
		if(strlen($str) <= $so_ky_tu){
			$str = $str;
		}else{
			$str = wordwrap($str,$so_ky_tu); 
			$str = substr($str, 0, strpos($str, "\n"))."...";
		}
		return $str;
	}
	function LayIdBV($table,$TieuDe_KD){
		$sql = "SELECT idBV FROM $table WHERE TieuDe_KD = '$TieuDe_KD'";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);
		return $row[idBV];
		
	}
  
	function changeTitle($str){
		$str = $this->stripUnicode($str);
		$str = str_replace("?","",$str);
		$str = str_replace("&","",$str);
		$str = str_replace("'","",$str);		
		$str = str_replace("  "," ",$str);
		$str = trim($str);
		$str = mb_convert_case($str,MB_CASE_LOWER,'utf-8');// MB_CASE_UPPER/MB_CASE_TITLE/MB_CASE_LOWER
		$str = str_replace(" ","-",$str);
		$str = str_replace("---","-",$str);
		$str = str_replace("--","-",$str);
		$str = str_replace('"',"",$str);	
		$str = str_replace(":","",$str);
		$str = str_replace("(","",$str);
		$str = str_replace(")","",$str);
		$str = str_replace(",","",$str);
		$str = str_replace(".","",$str);
		return $str;
	}
	function stripUnicode($str){
	  if(!$str) return false;
	   $unicode = array(
		 'a'=>'á|à|ả|ã|ạ|ă|ắ|ằ|ẳ|ẵ|ặ|â|ấ|ầ|ẩ|ẫ|ậ',
		 'A'=>'Á|À|Ả|Ã|Ạ|Ă|Ắ|Ằ|Ẳ|Ẵ|Ặ|Â|Ấ|Ầ|Ẩ|Ẫ|Ậ',
		 'd'=>'đ',
		 'D'=>'Đ',
		 'e'=>'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ',
		  'E'=>'É|È|Ẻ|Ẽ|Ẹ|Ê|Ế|Ề|Ể|Ễ|Ệ',
		  'i'=>'í|ì|ỉ|ĩ|ị',	  
		  'I'=>'Í|Ì|Ỉ|Ĩ|Ị',
		 'o'=>'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
		  'O'=>'Ó|Ò|Ỏ|Õ|Ọ|Ô|Ố|Ồ|Ổ|Ỗ|Ộ|Ơ|Ớ|Ờ|Ở|Ỡ|Ợ',
		 'u'=>'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
		  'U'=>'Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',
		 'y'=>'ý|ỳ|ỷ|ỹ|ỵ',
		 'Y'=>'Ý|Ỳ|Ỷ|Ỹ|Ỵ',
		 ''=>'?',
		 '-'=>'/'
	   );
	   foreach($unicode as $khongdau=>$codau) {
			$arr=explode("|",$codau);
		  $str = str_replace($arr,$khongdau,$str);
	   }
	return $str;
	}
	
	function smtpmailer($to, $from, $from_name, $subject, $body) { 
        global $error;
        $mail = new PHPMailer(); 
        $mail->IsSMTP(); 
        $mail->SMTPDebug = 0;
        $mail->SMTPAuth = true; 
        $mail->SMTPSecure = 'ssl'; 
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 465; 
        $mail->Username = GUSER;  
        $mail->Password = GPWD;           
        $mail->SetFrom($from, $from_name);
        $mail->Subject = $subject;
        $mail->Body = $body;
		$mail->CharSet="utf-8";
        $mail->IsHTML(true);
        $mail->AddAddress($to);
        if(!$mail->Send()) {
            $error = 'Gởi mail bị lỗi : '.$mail->ErrorInfo; 
            return false;
        } else {
            $error = 'Thư của bạn đã được gởi đi !';
            return true;
        }
    }
	
	function insert($table,$data = array()){
		$key = "";
		$value = "";
		foreach($data as $k => $v){
			$key .= "," . $k;
			$value .= ",'" . $v  ."'";
		}
		echo $key."<br />";
		echo $value;
		if($key{0} == ",") $key{0} = "(";
		$key .= ")";
		if($value{0} == ",") $value{0} = "(";
		$value .= ")";
		$this->sql = "insert into ".$table.$key." values ".$value;
		$this->query();
		$this->insert_id = mysql_insert_id();
		return $this->result;
	}
	
	function update($data = array()){
		$values = "";
		foreach($data as $k => $v){
			$values .= ", " . $k . " = '" . $v  ."' ";
		}
		if($values{0} == ",") $values{0} = " ";
		$this->sql = "update " . $this->refix . $this->table . " set " . $values;
		$this->sql .= $this->where;
		return $this->query();
	}
	
	function delete(){
		$this->sql = "delete from " . $this->refix . $this->table . $this->where;
		return $this->query();
	}
	
	function select($str = "*"){
		$this->sql = "select " . $str;
		$this->sql .= " from " . $this->refix .$this->table;
		$this->sql .=  $this->where;
		$this->sql .=  $this->order;
		$this->sql .=  $this->limit;
		return $this->query();
	}
	function GetCat($id)
	{
			$sql ="SELECT ten_kd FROM table_product_cat WHERE id=$id";
			$rs=mysql_fetch_assoc(mysql_query($sql));
			return $rs[ten_kd];
	}
	function GetItem($id)
	{
			$sql ="SELECT ten_kd FROM table_product_item WHERE id=$id";
			$rs=mysql_fetch_assoc(mysql_query($sql));
			return $rs[ten_kd];
	}
	function GetDesc($table,$ten_kd){
		$sql = "SELECT descs FROM $table WHERE ten_kd = '$ten_kd'";
		$rs=mysql_fetch_assoc(mysql_query($sql));
		return $rs[descs];
	}
	function GetTitle($table,$ten_kd){
		$sql = "SELECT ten FROM $table WHERE ten_kd = '$ten_kd'";
		$rs=mysql_fetch_assoc(mysql_query($sql));
		return $rs[ten];
	}
	function GetKeys($table,$ten_kd){
		$sql = "SELECT keywords FROM $table WHERE ten_kd = '$ten_kd'";
		$rs=mysql_fetch_assoc(mysql_query($sql));
		return $rs[keywords];
	}
	public function Login(){
		
		$email = $_POST['email'];
		$password = $_POST['password'];
		if (get_magic_quotes_gpc()== false) {
			$email = trim(mysql_real_escape_string($email));
			$password = trim(mysql_real_escape_string($password));
		}	

		if ($email=="admin@lahava.vn" && $password=="lahava.vn@2012@") {
			$_SESSION['kt_login_id'] = 'admin@lahava.vn';	
			
			header("location:index.php");			
		} else  header("location:dangnhap.php"); 
	} 
	function checkTagTonTai($tag,$lang){
		$sql = "SELECT tag_id FROM tag WHERE BINARY tag_name LIKE '%$tag%'";
		$rs = mysql_query($sql);
		$row = mysql_num_rows($rs);
		if($row == 1){
			$row = mysql_fetch_assoc($rs);
			$idTag = $row[tag_id];
		}else{
			$tag_kd = $this->changeTitle($tag);
			$idTag = $this->insertTag($tag,$tag_kd,$lang);
		}
		return $idTag;
	}
	function insertTag($tag,$tag_kd,$lang){
		$sql = "INSERT INTO tag VALUES (NULL,'$tag','$tag_kd','$lang')";
		$rs = mysql_query($sql);
		$id= mysql_insert_id();
		return $id;			
	}
	function addTagToArticle($sp_id,$tag_id,$lang){
		$sql = "INSERT INTO sp_tag VALUES ($sp_id,$tag_id,'$lang')";
		mysql_query($sql) or die(mysql_error());
	}
	
	function getImageSizeHoang($url,$width){			
		$arrTmp = explode("/",$url);
		$sopt = count($arrTmp);
		$file_name = $arrTmp[$sopt-1];
		$urlResize = str_replace($file_name,$width."/".$file_name,$url);				
		$rot = $_SERVER['DOCUMENT_ROOT'].'/'; 		
		$urlResize =  str_replace('../','',$urlResize);
		
		if(!is_file($rot.$urlResize)){			
			return str_replace('../','',$url); 
		}else{
			return $urlResize;
		}
	}
	
	function checkEmailExist($email){
		$sql = "SELECT idKH FROM khachhang WHERE email = '$email'";
		$rs = mysql_query($sql);
		$row = mysql_num_rows($rs);
		if($row > 0) return true;
		else return false;
	}
	function getIDKH($email){
		$sql = "SELECT idKH FROM khachhang WHERE email = '$email'";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);
		$idKH = $row['idKH'];
		return $idKH;
	}
	function insertCustomer($email,$dienthoai,$diachi,$hoten){
		$tongtien = $_SESSION['tong_tien'];
		$time = strtotime('now');
		$sql = "INSERT into khachhang VALUES (NULL,'$hoten','$email','$dienthoai','$diachi','$tongtien',$time,1)";
		mysql_query($sql) or die(mysql_error().$sql);
	}
	function insertDonHang($idKH){		
		$tongtien = $_SESSION['tong_tien'];
		$tong_sp = $_SESSION['tong_so_sp'];
		$time = strtotime('now');
		$sql = "INSERT into donhang VALUES (NULL,$idKH,$tongtien,$tong_sp,$time,0)";
		mysql_query($sql) or die(mysql_error());
		$idDH = mysql_insert_id();
		return $idDH;
	}
	function updateInfoCustomer($idKH,$email){
		$tongtien = $_SESSION['tong_tien'];
		$time = strtotime('now');		
		$sql = "UPDATE khachhang 
				SET tongtien = (tongtien + $tongtien),
				lanmuacuoi = $time,solanmua = (solanmua + 1) 
				WHERE idKH = $idKH";
		mysql_query($sql) or die(mysql_error());
	}
	function insertDonHangChiTiet($idDH,$idSP,$soluong,$tiensp,$mau_id,$size){
		$sql = "INSERT into donhangct VALUES (NULL,$idDH,$idSP,$soluong,$tiensp,$mau_id,'$size')";
		mysql_query($sql) or die(mysql_error());
	}
	function checkEmail($email){
		if (filter_var($email,FILTER_VALIDATE_EMAIL)==FALSE) { 
			$kq=1;
		}else $kq=0;
		return $kq;
	}
	function language($name,$lang){		
		$sql = "SELECT $lang FROM language WHERE name = '$name'";
		$rs = mysql_query($sql)or die($sql);
		$row = mysql_fetch_assoc($rs);

		return $row[$lang];		
	}
	function getNameColor($mau_id){
		$sql = "SELECT ten_vi FROM mau WHERE mau_id = '$mau_id'";
		$row = mysql_query($sql);
		$rs = mysql_fetch_assoc($row);
		return $rs['ten_vi'];
	}
	function getNameProduct($idSP){
		$sql = "SELECT ten_sp_vi FROM sanpham WHERE sp_id = '$idSP'";
		$row = mysql_query($sql);
		$rs = mysql_fetch_assoc($row);
		return $rs['ten_sp_vi'];
	}
}
?>