<?php 
require_once "class.db.php";
class thanhpho extends db{
	
	/* QUAN LY CHUNG LOAI */
	function ThanhPho_Them(&$loi){	
	
		$thanhcong=true;
		
		$TenTP = $this->processData($_POST[TenTP]);
		$TenTP_KD = $this->processData($_POST[TenTP_KD]);
		$Title = $this->processData($_POST[Title]);
		$MetaD = $this->processData($_POST[MetaD]);
		$MetaK = $this->processData($_POST[MetaK]);
		
		$ThuTu = $this->ThuTuMax('thanhpho') + 1;
				
		$AnHien = $_POST[AnHien];settype($AnHien,"int");
		
		if($Title=="") $Title=$TenTP;
		if($MetaD=="") $MetaD=$TenTP;
		if($MetaK=="") $MetaK=$TenTP;
		if($TenTP_KD=="") $TenTP_KD = $this->changeTitle($TenTP);
		
		if($TenTP=="")
		{
			$thanhcong= false;
			$loi[TenTP]= "Chưa nhập tên thành phố";
		}
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO thanhpho 
					VALUES(NULL,'$TenTP','$TenTP_KD',$AnHien,$ThuTu,'$Title','$MetaD','$MetaK')";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function ThanhPho_Edit($idTP,&$loi){
		settype($idTP,"int");
		$thanhcong=true;
		
		$TenTP = $this->processData($_POST[TenTP]);
		$TenTP_KD = $this->processData($_POST[TenTP_KD]);
		$Title = $this->processData($_POST[Title]);
		$MetaD = $this->processData($_POST[MetaD]);
		$MetaK = $this->processData($_POST[MetaK]);
				
		$AnHien = $_POST[AnHien];settype($AnHien,"int");
		
		if($Title=="") $Title=$TenTP;
		if($MetaD=="") $MetaD=$TenTP;
		if($MetaK=="") $MetaK=$TenTP;
		if($TenTP_KD=="") $TenTP_KD = $this->changeTitle($TenTP);
		
		if($TenTP=="")
		{
			$thanhcong= false;
			$loi[TenTP]= "Chưa nhập tên thành phố";
		}
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE thanhpho 
					SET TenTP = '$TenTP',TenTP_KD = '$TenTP_KD',AnHien = $AnHien,
					Title = '$Title',MetaD = '$MetaD',MetaK = '$MetaK' 
					WHERE idTP = $idTP";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function ThanhPho_List($AnHien=-1){
		$sql = "SELECT * FROM thanhpho WHERE AnHien = $AnHien OR $AnHien = -1 ORDER BY ThuTu ASC ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function ThanhPho_ChiTiet($idTP){
		$sql = "SELECT * FROM thanhpho WHERE idTP = $idTP";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function TrangDon_List(){
		$sql = "SELECT * FROM trangdon ORDER BY idTrangDon ";		
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function TrangDon_ChiTiet($idTrangDon){
		$sql = "SELECT * FROM trangdon WHERE idTrangDon = $idTrangDon ";		
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function NoiDungTrangDon($idTrangDon){
		$sql = "SELECT * FROM trangdon WHERE idTrangDon = $idTrangDon";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function ListTrangDon(){
		$sql = "SELECT * FROM trangdon";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	
	function TrangDon_Sua($idTrangDon,&$loi){	
	
		$thanhcong=true;		
		
		$TieuDe= $this->processData($_POST[TieuDe]);
		$TieuDe_KD = $this->processData($_POST[TieuDe_KD]);
		
		$NoiDung = $_POST[NoiDung];		   
       
		$Title = $this->processData($_POST[Title]);
		$MetaD = $this->processData($_POST[MetaD]);
		$MetaK = $this->processData($_POST[MetaK]);

		
		if($Title=="") $Title=$TieuDe;
		if($MetaD=="") $MetaD=$TieuDe;
		if($MetaK=="") $MetaK=$TieuDe;
		if($TieuDe_KD=="") $TieuDe_KD = $this->changeTitle($TieuDe);
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE trangdon
					SET TieuDe = '$TieuDe',TieuDe_KD = '$TieuDe_KD',
                    NoiDung = '$NoiDung'
					,Title = '$Title',MetaD = '$MetaD',MetaK = '$MetaK' WHERE idTrangDon = $idTrangDon";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
}

?>