<?php if(!defined('_lib')) die("Error");
$config['database']['servername'] = 'localhost';

$config['database']['username'] = 'root';
$config['database']['password'] = 'root';
$config['database']['database'] = 'datviettour';
$config['database']['refix'] = 'dvt_';

?>