<?php 
require_once "class.db.php";
class trangchu extends db{	
	/* SAN PHAM */
	function getDetailSP($sp_id){
		$sql= "SELECT * 
			FROM sanpham
			WHERE sp_id = $sp_id";
		$rs= mysql_query($sql) or die(mysql_error());
		return $rs;
	}	
	function getListChatLieu($lang='vi'){
		$sql = "SELECT * FROM chatlieu ORDER BY chat_id ASC ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getListKieuDang(){
		$sql = "SELECT * FROM kieu ORDER BY kieu_id ASC  ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getListMau($lang='vi'){
		$sql = "SELECT * FROM mau ORDER BY mau_id ASC ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getListMauByProductId($sp_id){
		$sql = "SELECT mau_id FROM sp_mau where sp_id = $sp_id ORDER BY mau_id ASC  ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getDetailMau($mau_id){
		$sql = "SELECT * FROM mau WHERE mau_id =$mau_id ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getListSizeByProductId($sp_id){
		$sql = "SELECT size_id FROM sp_size where sp_id = $sp_id ORDER BY size_id ASC  ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getDetailSize($size_id){
		$sql = "SELECT * FROM size WHERE size_id =$size_id ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getTagsByProductId($sp_id,$lang='vi'){
		$sql = "SELECT tag_id FROM sp_tag WHERE sp_id = $sp_id AND lang = '$lang'";
		$rs = mysql_query($sql);
		return $rs;
	}
	function getDetailTag($tag_id){
		$sql = "SELECT * FROM tag WHERE tag_id = $tag_id";
		$rs = mysql_query($sql);
		return $rs;
	}
	function getContentDetailPage($id,$lang){
		$sql = "SELECT * FROM menu WHERE idMenu = $id";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);
		return $row['noidung_'.$lang]; 
	}
        function album_list($idLoaiAlbum = -1,$limit=-1,$offset=-1){
		$sql = "SELECT * FROM album 				";
                if($idLoaiAlbum > 0) $sql.=' WHERE idLoaiALbum = '.$idLoaiAlbum;    
		$sql.=" AND status = 1 ORDER BY idALbum ASC ";                
		if($limit >0 && $offset >=0) $sql.= " LIMIT $offset,$limit";	             
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
        function album_chitiet($idAlbum){
		$sql = "SELECT * FROM album 
				WHERE idAlbum = $idAlbum";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
         function listhinhanhbyalbum($idAlbum){
		$sql = "SELECT * FROM hinhalbum WHERE urlLon != '' AND urlNho != '' AND idAlbum = $idAlbum AND status = 1";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
        function album_chitiet_bytenkd($ten_kd){
            $sql = "SELECT * FROM album WHERE TenAlbumKD = '$ten_kd'";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
        }
        function checkalbumcohinh($idAlbum){
		$sql = "SELECT * FROM hinhalbum WHERE urlLon != '' AND urlNho != '' AND idAlbum = $idAlbum AND status = 1";
		$rs = mysql_query($sql) or die(mysql_error());
                $row = mysql_num_rows($rs);                
		return $row;
	}
}

?>