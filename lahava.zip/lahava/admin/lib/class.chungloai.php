<?php 
require_once "class.db.php";
class chungloai extends db{
	
	/* QUAN LY CHUNG LOAI */
	function ChungLoai_Them(&$loi){	
	
		$thanhcong=true;
		
		$TenCL = $this->processData($_POST[TenCL]);
		$TenCL_KD = $this->processData($_POST[TenCL_KD]);
		$Title = $this->processData($_POST[Title]);
		$MetaD = $this->processData($_POST[MetaD]);
		$MetaK = $this->processData($_POST[MetaK]);
		
		$ThuTu = $this->ThuTuMax('chungloai') + 1;
				
		$AnHien = $_POST[AnHien];settype($AnHien,"int");
		
		if($Title=="") $Title=$TenCL;
		if($MetaD=="") $MetaD=$TenCL;
		if($MetaK=="") $MetaK=$TenCL;
		if($TenCL_KD=="") $TenCL_KD = $this->changeTitle($TenCL);
		
		if($TenCL=="")
		{
			$thanhcong= false;
			$loi[TenCL]= "Chưa nhập tên chủng loại";
		}
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO chungloai 
					VALUES(NULL,'$TenCL','$TenCL_KD',$AnHien,$ThuTu,'$Title','$MetaD','$MetaK')";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function ChungLoai_Edit($idCL,&$loi){
		settype($idCL,"int");
		$thanhcong=true;
		
		$TenCL = $this->processData($_POST[TenCL]);
		$TenCL_KD = $this->processData($_POST[TenCL_KD]);
		$Title = $this->processData($_POST[Title]);
		$MetaD = $this->processData($_POST[MetaD]);
		$MetaK = $this->processData($_POST[MetaK]);
				
		$AnHien = $_POST[AnHien];settype($AnHien,"int");
		
		if($Title=="") $Title=$TenCL;
		if($MetaD=="") $MetaD=$TenCL;
		if($MetaK=="") $MetaK=$TenCL;
		if($TenCL_KD=="") $TenCL_KD = $this->changeTitle($TenCL);
		
		if($TenCL=="")
		{
			$thanhcong= false;
			$loi[TenCL]= "Chưa nhập tên chủng loại";
		}
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE chungloai 
					SET TenCL = '$TenCL',TenCL_KD = '$TenCL_KD',AnHien = $AnHien,
					Title = '$Title',MetaD = '$MetaD',MetaK = '$MetaK' 
					WHERE idCL = $idCL";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function ChungLoai_List($AnHien=-1,$limit=-1,$offset=-1){
		$sql = "SELECT * FROM chungloai WHERE AnHien = $AnHien OR $AnHien = -1 ORDER BY ThuTu ASC ";
		if($limit >0 && $offset >=0) $sql.= " LIMIT $offset,$limit";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function ChungLoai_ChiTiet($idCL){
		$sql = "SELECT * FROM chungloai WHERE idCL = $idCL";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
}

?>