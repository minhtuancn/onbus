<?php 
require_once "class.db.php";
class size extends db{
	
	function Size_Them(&$loi){	
	
		$thanhcong=true;
		$size= $this->processData($_POST[size]);		
       
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO size
					VALUES(NULL,'$size')";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	
	function Size_Edit($size_id,&$loi){
		settype($size_id,"int");
		$thanhcong=true;
		
		$thanhcong=true;
		
		$size= $this->processData($_POST[size]);
		     
		
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE size 
					SET size = '$size'
					WHERE size_id = $size_id";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}

	function Size_ChiTiet($size_id){
		$sql = "SELECT * FROM size WHERE size_id = $size_id";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getListSize(){
		$sql = "SELECT * FROM size ORDER BY size_id ASC ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getDetailSize($size_id){
		$sql = "SELECT * FROM size WHERE size_id =$size_id ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getListSizeByProductId($sp_id){
		$sql = "SELECT size_id FROM sp_size where sp_id = $sp_id ORDER BY size_id ASC  ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	
}

?>