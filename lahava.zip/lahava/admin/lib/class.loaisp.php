<?php 
require_once "class.db.php";
class loaisp extends db{
	
	/* QUAN LY LOAI SP */
	function LoaiSP_Them(&$loi){	
	
		$thanhcong=true;
		
		$TenLoai = $this->processData($_POST[TenLoai]);
		$TenLoai_KD = $this->processData($_POST[TenLoai_KD]);
		
		$idCL = $_POST[idCL];settype($idCL,"int");
		
		$Title = $this->processData($_POST[Title]);
		$MetaD = $this->processData($_POST[MetaD]);
		$MetaK = $this->processData($_POST[MetaK]);
		
		$ThuTu = $this->ThuTuMax('loaisp') + 1;
				
		$AnHien = $_POST[AnHien];settype($AnHien,"int");
		
		if($Title=="") $Title=$TenLoai;
		if($MetaD=="") $MetaD=$TenLoai;
		if($MetaK=="") $MetaK=$TenLoai;
		if($TenLoai_KD=="") $TenLoai_KD = $this->changeTitle($TenLoai);
		
		if($TenLoai=="")
		{
			$thanhcong= false;
			$loi[TenLoai]= "Chưa nhập tên loại";
		}
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO loaisp 
					VALUES(NULL,'$TenLoai','$TenLoai_KD',$AnHien,$ThuTu,$idCL,'$Title','$MetaD','$MetaK')";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function LoaiSP_Edit($idLoai,&$loi){
		settype($idLoai,"int");
		$thanhcong=true;

		
		$title_vi = $this->processData($_POST['title_vi']);
		$metad_vi = $this->processData($_POST['metad_vi']);
		$metak_vi = $this->processData($_POST['metak_vi']);
		
		$title_en = $this->processData($_POST['title_en']);
		$metad_en = $this->processData($_POST['metad_en']);
		$metak_en = $this->processData($_POST['metak_en']);
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE loaisp 
					SET title_vi = '$title_vi',metad_vi = '$metad_vi',metak_vi = '$metak_vi',title_en = '$title_en',
					metad_en = '$metad_en',metak_en = '$metak_en' 
					WHERE loai_id = $idLoai";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function getListLoaiSP($limit=-1,$offset=-1){
		$sql = "SELECT * FROM loaisp 				
				ORDER BY loai_id ASC ";
		if($limit >0 && $offset >=0) $sql.= " LIMIT $offset,$limit";		
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
        function getListLoaiAlbum($limit=-1,$offset=-1){
		$sql = "SELECT * FROM loaialbum 				
				ORDER BY idLoaiAlbum ASC ";
		if($limit >0 && $offset >=0) $sql.= " LIMIT $offset,$limit";		
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
        function album_list($idLoaiAlbum = -1,$limit=-1,$offset=-1){
		$sql = "SELECT * FROM album 				";
                if($idLoaiAlbum > 0) $sql.=' WHERE idLoaiALbum = '.$idLoaiAlbum;    
		$sql.=" ORDER BY idALbum ASC ";                
		if($limit >0 && $offset >=0) $sql.= " LIMIT $offset,$limit";	             
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function LoaiSP_ChiTiet($idLoai){
		$sql = "SELECT * FROM loaisp 
				WHERE loai_id = $idLoai";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
        function loaialbum_chitiet($idLoaiAlbum){
		$sql = "SELECT * FROM loaialbum 
				WHERE idLoaiAlbum = $idLoaiAlbum";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
        function album_chitiet($idAlbum){
		$sql = "SELECT * FROM album 
				WHERE idAlbum = $idAlbum";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
        function album_them(&$loi){	
	
		$thanhcong=true;
		
		$TenAlbum = $this->processData($_POST['TenAlbum']);
		$TenAlbum_KD = $this->processData($_POST['TenAlbum_KD']);
		
		$idLoaiAlbum = (int) $_POST['idLoaiAlbum'];		
		
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO album 
					VALUES(NULL,'$TenAlbum','$TenAlbum_KD',1,$idLoaiAlbum)";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
         function album_edit($idAlbum){	
	
		$thanhcong=true;
		
		$TenAlbum = $this->processData($_POST['TenAlbum']);
		$TenAlbum_KD = $this->processData($_POST['TenAlbum_KD']);
		
		$idLoaiAlbum = (int) $_POST['idLoaiAlbum'];		
		
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE album SET TenAlbum = '$TenAlbum', TenAlbumKD = '$TenAlbum_KD' , idLoaiAlbum = $idLoaiAlbum WHERE idAlbum = $idAlbum";					
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
        function listhinhanhbyalbum($idAlbum){
		$sql = "SELECT * FROM hinhalbum WHERE urlLon != '' AND urlNho != '' AND idAlbum = $idAlbum AND status = 1";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
}

?>