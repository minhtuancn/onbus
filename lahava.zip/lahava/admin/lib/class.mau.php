<?php 
require_once "class.db.php";
require_once "class.resize.php";

function resizeHoang($file,$width,$height,$file_name,$des){
	require_once "lib/class.resize.php";
	$re = new resizes;
	$re->load($file);
	$re->resize($width,$height);
	$re->save($des.$file_name); 
}
class mau extends db{
	

	function getListMau($lang='vi'){
		$sql = "SELECT * FROM mau ORDER BY mau_id ASC ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getDetailMau($mau_id){
		$sql = "SELECT * FROM mau WHERE mau_id =$mau_id ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function getListMauByProductId($sp_id){
		$sql = "SELECT mau_id FROM sp_mau where sp_id = $sp_id ORDER BY mau_id ASC  ";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}

	function TrangDon_List(){
		$sql = "SELECT * FROM menu ORDER BY idMenu ";		
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function TrangDon_ChiTiet($idTrangDon){
		$sql = "SELECT * FROM menu WHERE idMenu = $idTrangDon ";		
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function Lang_List(){
		$sql = "SELECT * FROM language ";		
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function Lang_ChiTiet($id){
		$sql = "SELECT * FROM language WHERE id = $id ";		
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function Lang_Sua($id,&$loi){	
	
		$thanhcong=true;		
		
		$ten_vi= $this->processData($_POST['ten_vi']);
		$ten_en = $this->processData($_POST['ten_en']);
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE language
					SET vi = '$ten_vi',en = '$ten_en'                   
					WHERE id = $id";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function NoiDungTrangDon($idTrangDon){
		$sql = "SELECT * FROM menu WHERE idMenu = $idTrangDon";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	function ListTrangDon(){
		$sql = "SELECT * FROM menu";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	
	function TrangDon_Sua($idTrangDon,&$loi){	
	
		$thanhcong=true;		
		
		$ten_vi= $this->processData($_POST['ten_vi']);
		$ten_en = $this->processData($_POST['ten_en']);
		
		$noidung_vi = $_POST['noidung_vi'];
		$noidung_en = $_POST['noidung_en'];	
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE menu
					SET ten_vi = '$ten_vi',ten_en = '$ten_en',
                    noidung_vi = '$noidung_vi',noidung_en = '$noidung_en'
					WHERE idMenu = $idTrangDon";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	
	
	function Mau_ChiTiet($mau_id){
		$sql = "SELECT * FROM mau WHERE mau_id = $mau_id";
		$rs = mysql_query($sql) or die(mysql_error());
		return $rs;
	}
	
	function Mau_Them(&$loi){	
	
		$thanhcong=true;
		
		$ten_vi= $this->processData($_POST[ten_vi]);
		$ten_en= $this->processData($_POST[ten_en]);		
        $hinh = $this->processData($_POST[hinh]);
		
		$arrTmp = explode("/",$hinh);
		$sopt = count($arrTmp);
		echo $file_name = $arrTmp[$sopt-1];
		
		
		
		$urlResize = "../".str_replace($file_name,"small/",$hinh);
		
		if(!is_dir($urlResize)){
		mkdir($urlResize,0700,true);
		}else{
			echo "da co thu muc";
		}
			
		resizeHoang(
				"../".$hinh,
				25,25,
				$file_name,
				$urlResize
			);  
		
		
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "INSERT INTO mau
					VALUES(NULL,'$ten_vi','$ten_en','$hinh')";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
	function Mau_Sua($mau_id,&$loi){	
		settype($mau_id,"int");
		$thanhcong=true;		
		
		$ten_vi= $this->processData($_POST[ten_vi]);
		$ten_en= $this->processData($_POST[ten_en]);		
        $hinh = $this->processData($_POST[hinh]);
	
	
		if($thanhcong==false){
			return $thanhcong;
		}else{
			$sql = "UPDATE mau
					SET ten_vi = '$ten_vi',ten_en = '$ten_en',hinh = '$hinh' WHERE mau_id = $mau_id";
			mysql_query($sql) or die(mysql_error().$sql);		
		}
		return $thanhcong;
	}
}

?>