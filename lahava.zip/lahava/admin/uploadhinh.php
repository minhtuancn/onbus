<?php
require_once "lib/class.db.php";
$d = new db;
$idAlbum = (int) $_POST['idAlbum'];
if(!is_dir("../upload/album/".date('Y/m/d')."/nho/"))
mkdir("../upload/album/".date('Y/m/d')."/nho/",0777,true);

if(!is_dir("../upload/album/".date('Y/m/d')."/lon/"))
mkdir("../upload/album/".date('Y/m/d')."/lon/",0777,true);

$url_nho = "../upload/album/".date('Y/m/d')."/nho/";
$url_lon = "../upload/album/".date('Y/m/d')."/lon/";

for($i=0;$i<count($_FILES['imagesnho']['name']);$i++){  
  
    if($_FILES['imagesnho']['name'][$i] != '' && $_FILES['imageslon']['name'][$i]!=''){
        if (file_exists($url_nho. $_FILES["imagesnho"]["name"][$i]) || file_exists($url_lon. $_FILES["imageslon"]["name"][$i])) {
            echo "Files already exists. ";
        } else {
            $url_luu_nho = $url_nho . $_FILES["imagesnho"]["name"][$i];
            move_uploaded_file($_FILES["imagesnho"]["tmp_name"][$i], $url_luu_nho);                      
            $url_luu_lon = $url_lon . $_FILES["imageslon"]["name"][$i];
            move_uploaded_file($_FILES["imageslon"]["tmp_name"][$i], $url_luu_lon);         
        }
        $sql = "INSERT INTO hinhalbum VALUES(NULL,'$url_luu_lon','$url_luu_nho',1,$idAlbum)";
        mysql_query($sql);
    }
}
header('location:index.php?com=hinhanh_list&idAlbum='.$idAlbum);	 
?>