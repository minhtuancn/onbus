<?php 
echo $_GET[hinh_dai_dien];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<script type="text/javascript" src="js/form.js"></script>
<script type="text/javascript" src="js/jquery-ui.custom.js"></script>
<script type="text/javascript" src="js/jquery.ui.core.js"></script>
<script type="text/javascript" src="js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="js/jquery.ui.dialog.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.base.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.theme.css"/>
<script>
	$(document).ready(function(){		
		$('#upload_images').ajaxForm({
     		beforeSend: function() {				
			},
			uploadProgress: function(event, position, total, percentComplete) {
				           
			},
			complete: function(data) {       
				var arrRes = JSON.parse(data.responseText); 
				//console.log(arrRes);
				alert(arrRes['thongbao']);
				$("#hinhanh").html(arrRes['text']);
				$( "#div_upload" ).dialog('close');
				
			}
    	}); 
		$("#btnUpload").click(function(){
			$("#div_upload" ).dialog({
				modal: true,
				title: 'Upload images',
				width: 350,
				draggable: true,
				resizable: false,
				position: "center middle"
			});
		});
		$("#add_images").click(function(){
			$( "#wrapper_input_files" ).append("<input type='file' name='images[]' /><br />");
		});
	});
	
</script>
<style>
#div_upload{font-size:13px;text-align:center}

</style>
</head>

<body>
<a id="btnUpload" href="#">Upload</a>
<div id="div_upload" style="display:none">
    <form id="upload_images" method="post" enctype="multipart/form-data" enctype="multipart/form-data" action="ajax.php">
        <div style="margin: auto;">       
            <img src="images/add.png" id="add_images" width="32" />
            <div id="wrapper_input_files">
            	<input type="file" name="images[]" /><br />
                <input type="file" name="images[]" /><br />
                <input type="file" name="images[]" /><br />
            </div>            
            <div class="clear"></div>       
            <button style="margin-top: 10px;"class="button_colour" type="submit" id="btn_upload_images">                
                <a href="#">Upload</a>
            </button>        
        </div>
        
    </form>
</div>
<form method="get">
	<div id="hinhanh">

	</div>
    <input type="submit" value="ADD" name="btnSumitForm" />
</form>

</body>
</html>