<?php	
require_once("lib/classQuanTri.php");
$qt = new quantri;	

$loai = $_GET['loai'];
$id = (int) $_GET['id'];
switch($loai){
	case "size":
		mysql_query("DELETE FROM sp_size WHERE size_id = $id");
		$qt->Xoa("size","size_id",$id);
		break;
	case "mau":
		mysql_query("DELETE FROM sp_mau WHERE mau_id = $id");
		$qt->Xoa("mau","mau_id",$id);
		break;
	case "loaisp":	
		$qt->Xoa("loaisp","idLoai",$id);	
		break;
	case "kieu" :
		mysql_query("DELETE FROM sp_kieu WHERE kieu_id = $id");
		$qt->Xoa("kieu","kieu_id",$id);	
		break;
	case "chat" :
		mysql_query("DELETE FROM sp_chat WHERE chat_id = $id");
		$qt->Xoa("chatlieu","chat_id",$id);	
		break;	
	case "sanpham" : 
		$qt->XoaSP($id);
		mysql_query("DELETE FROM sanpham WHERE sp_id = $id");
		
		break;	
	case "user" : 
		$qt->Xoa("users","idUser",$id);
		break;	
	case "thongbao" : 
		$qt->Xoa("thongbaoloi","idThongBao",$id);
		break;	
	case "donhang" : 
		$sql1 = "DELETE FROM donhangchitiet WHERE idDH = $id";
		mysql_query($sql1);
		$sql2 = "DELETE FROM donhang WHERE idDH = $id";
		mysql_query($sql2);
		break;	
	case "khachhang" : 
		$sql1 = "DELETE FROM khachhang WHERE idKH = $id";
		mysql_query($sql1);
		$sql2 = "DELETE FROM donhang WHERE idKH = $id";
		mysql_query($sql2);
		break;
        case "hinhalbum" : 
		$sql1 = "UPDATE hinhalbum SET status = 0 WHERE idHinh = $id";
		mysql_query($sql1);		
		break; 
        case "hinhalbum" : 
		$sql1 = "UPDATE album SET status = 0 WHERE idAlbum = $id";
		mysql_query($sql1);		
		break;       
}



?>