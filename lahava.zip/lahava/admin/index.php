<?php 
//require_once "authenticate.php";
ob_start();
	session_start();
	require_once "checkLogin.php";
	require_once("lib/classQuanTri.php");	
		
	require_once("lib/class.loaisp.php");
	require_once("lib/class.mau.php");
	require_once("lib/class.size.php");
	require_once("lib/class.sanpham.php");
	require_once("lib/class.kieudang.php");
	require_once("lib/class.user.php");
	require_once("lib/class.chatlieu.php");
	require_once("lib/class.donhang.php");
	require_once("lib/class.khachhang.php");
	
	$chat = new chatlieu;
	$lsp = new loaisp;
	$qt = new quantri;
	$mau = new mau;
	$kieu = new kieudang;
	$size = new size;
	$sp = new sanpham;
	$u = new users;
	$dh = new donhang;
	$kh = new khachhang;

	$com='';
    if(isset($_GET['com']))
    {
   	    $com = $_GET['com'];
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Quản trị</title>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
<link href="css/system.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/jquery.ui.all.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.datepicker.css"/>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<script type="text/javascript" src="js/jquery.ui.core.js"></script>
<script type="text/javascript" src="js/form.js"></script>
<script type="text/javascript" src="js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="js/jquery-ui.custom.js"></script>
<script type="text/javascript" src="js/jquery.ui.dialog.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.base.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.theme.css"/>
<script type="text/javascript" src="js/functions.js"></script>
<script type="text/javascript" src="js/admin.js"></script>

<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>

<script type="text/javascript">
    $(function(){     
        $(".ngay").datepicker({
            numberOfMonths: 1,  dateFormat: 'dd-mm-yy',
            monthNames: ['Một','Hai','Ba','Tư','Năm','Sáu','Bảy','Tám','Chín', 
            'Mười','Mười một','Mười hai'] ,
            monthNamesShort: ['Tháng1','Tháng2','Tháng3','Tháng4','Tháng5',
            'Tháng6','Tháng7','Tháng8','Tháng9','Tháng10','Tháng11','Tháng12'] ,
            dayNames: ['Chủ nhật', 'Thứ hai', 'Thứ ba', 'Thứ tư', 'Thứ năm',
            'Thứ sáu', 'Thứ bảy'],
            dayNamesMin: ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'] ,
            showWeek: true , showOn: 'both',
            changeMonth: true , changeYear: true,
            currentText: 'Hôm nay', weekHeader: 'Tuần',
			minDate: 1,
            
        });
        
    })
    
</script>

</head>

<body>    
<div id="wrapper" style="background-color:#FFF;min-height:600px;margin-top:20px;border-radius:  10px 10px 10px 10px;">
	<div id="header" style="clear:both;background-color:#FFF">
    	<div style="float:left;width:30%"></div>
        <div style="float:left;width:40%;"><h1 style="margin-top:20px;margin-left:50px">QUẢN TRỊ WEBSITE</h1></div>
        <div id="chao" style="width:30%;float:right;color:#F3C">
        	<span>Chào Admin <?php echo $_SESSION[kt_HoTen] ?>
            </span>
             <div id="thoat"><a href="thoat.php" style="color:#00C; ">Thoát</a> </div>
           </div>
    </div>
    <div style="clear:both"></div>
    <div id="thanhmenu" style="margin-bottom:20px"><?php include 'blocks/layout/menu.php';?></div>
    <div id="content">
     	<?php		   	
		if ($com=="") include "blocks/sanpham/sp_list.php";	
		elseif ($com=="chungloai_add") include "blocks/chungloai/chungloai_add.php";
		elseif ($com=="chungloai_edit") include "blocks/chungloai/chungloai_edit.php";
		elseif ($com=="chungloai_list") include "blocks/chungloai/chungloai_list.php";
			
		elseif ($com=="map_add") include "blocks/map/map_add.php";
		elseif ($com=="map_edit") include "blocks/map/map_edit.php";
		elseif ($com=="map_list") include "blocks/map/map_list.php";
		
		elseif ($com=="loaisp_add") include "blocks/loaisp/loaisp_add.php";
		elseif ($com=="loaisp_edit") include "blocks/loaisp/loaisp_edit.php";
		elseif ($com=="loaisp_list") include "blocks/loaisp/loaisp_list.php";
		
		elseif ($com=="tp_add") include "blocks/thanhpho/tp_add.php";
		elseif ($com=="tp_edit") include "blocks/thanhpho/tp_edit.php";
		elseif ($com=="tp_list") include "blocks/thanhpho/tp_list.php";	
		
		elseif ($com=="sp_add") include "blocks/sanpham/sp_add.php";	
		elseif ($com=="sp_edit") include "blocks/sanpham/sp_edit.php";
		elseif ($com=="sp_list") include "blocks/sanpham/sp_list.php";
		elseif ($com=="donhang_list") include "blocks/donhang/donhang_list.php";
		elseif ($com=="khachhang_list") include "blocks/khachhang/khachhang_list.php";
		elseif ($com=="donhang_chitiet") include "blocks/donhang/donhang_ct.php";
		elseif ($com=="thongbao_list") include "blocks/thongbao/thongbao_list.php";	
		
		elseif ($com=="trangdon_list") include "blocks/trangdon/trangdon_list.php";
		elseif ($com=="trangdon_edit") include "blocks/trangdon/trangdon_edit.php";	
		
		elseif ($com=="lang_list") include "blocks/language/lang_list.php";
		elseif ($com=="lang_edit") include "blocks/language/lang_edit.php";	
			
		elseif ($com=="user_list") include "blocks/user/user_list.php";
		elseif ($com=="user_edit") include "blocks/user/user_edit.php";	
		elseif ($com=="user_add") include "blocks/user/user_add.php";	
		
		elseif ($com=="mau_list") include "blocks/mau/mau_list.php";
		elseif ($com=="mau_edit") include "blocks/mau/mau_edit.php";	
		elseif ($com=="mau_add") include "blocks/mau/mau_add.php";
		
		elseif ($com=="chat_list") include "blocks/chat/chat_list.php";
		elseif ($com=="chat_edit") include "blocks/chat/chat_edit.php";	
		elseif ($com=="chat_add") include "blocks/chat/chat_add.php";	
		
		elseif ($com=="kieu_list") include "blocks/kieu/kieu_list.php";
		elseif ($com=="kieu_edit") include "blocks/kieu/kieu_edit.php";	
		elseif ($com=="kieu_add") include "blocks/kieu/kieu_add.php";
		
		elseif ($com=="size_list") include "blocks/size/size_list.php";
		elseif ($com=="size_edit") include "blocks/size/size_edit.php";	
		elseif ($com=="size_add") include "blocks/size/size_add.php";	
                
                elseif ($com=="loaialbum_list") include "blocks/loaialbum/loaialbum_list.php";
		elseif ($com=="hinhanh_add") include "blocks/hinhanh/hinhanh_add.php";	
		elseif ($com=="hinhanh_list") include "blocks/hinhanh/hinhanh_list.php";	
                
                elseif ($com=="album_list") include "blocks/album/album_list.php";
		elseif ($com=="album_edit") include "blocks/album/album_edit.php";	
		elseif ($com=="album_add") include "blocks/album/album_add.php";	
		
		elseif ($com=="footer") include "blocks/trangdon/trangdon_list.php";	
		
		?>       
    </div>
</div>
</body>
</html>