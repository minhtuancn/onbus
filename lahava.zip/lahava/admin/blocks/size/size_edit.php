<?php 
$size_id = $_GET[size_id];settype($size_id,"int");
$chitiet = $size->Size_ChiTiet($size_id);
$row= mysql_fetch_assoc($chitiet);
if(isset($_POST[btnSumit])){	
	$thanhcong = $size->Size_Edit($size_id,$loi);	
	if($thanhcong==true){
		header("location:?com=size_list");
	}
}
?>
<form action="" method="post" name="form_add_dm_tour">
<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý size : cập nhật</h3>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div id="main_left">
    	<fieldset>
        	<legend>Thông tin chi tiết</legend>
            	<table>
                	<tr>
                   	  <td class="left">Size</td>
                        <td>
                            <input type="text" name="size" id="size" class="tf"  value="<?php echo $row[size]?>"/>
                        	<span class="error"><?php echo $loi[size];?></span>                 
                        </td>                        
                    </tr>                    
                     
                     
                  
                    <tr>
                   	  <td class="left">&nbsp;</td>
                        <td>&nbsp;
                         
                        </td>                        
                    </tr>
                </table>
            
        </fieldset>
    </div>
	
  
    <div class="clr"></div>
</div>
</form>