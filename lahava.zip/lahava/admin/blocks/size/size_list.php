<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").live('click',function(){			
			var flag = confirm("Bạn có chắc chắn xóa");
			if(flag == true){
				var size_id = $(this).attr("size_id");
				$.get('xoa.php',{loai:"size",id:size_id},function(data){
					window.location.reload();			
				});	
			}
		})         
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:80%">
		<h3>Quản lý size : Xem danh sách</h3>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
        <a href="index.php?com=size_add"><input type="button" class="new" name="btnNew" value=""/></a><br />		
        <span>New</span>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div>
    	<fieldset>
        	<legend>++ Size ++</legend>
            	<div style="text-align: center">                     
                    <table id="rounded-corner" summary="2007 Major IT Companies&#39; Profit">
                        <thead>
                            <tr style="background-color:#03F;color:#FFF;height:30px">
                                <th scope="col" class="rounded-company"></th>       
                               
                                <th scope="col" class="rounded">Size</th>                             
                                <th scope="col" class="rounded">Sửa</th>
                                <th scope="col" class="rounded-q4">Xóa</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php 						
                        $listsize = $size->getListSize();
                        while($row=mysql_fetch_assoc($listsize)) {                 
                        $i++;
                        ?>	
                            <tr <?php if($i%2==0) echo "bgcolor='#CCC'" ; ?>>
                                <td><input type="checkbox" name="chon" size_id=<?php echo $row[size_id]?>></td>  
                                  
                                <td align="left"><?php echo $row[size]?></td>    
     
                              
                               
                                <td><a href="index.php?com=size_edit&amp;size_id=<?php echo $row[size_id]?>"><img src="img/icons/user_edit.png" alt="" title="" border="0"></a></td>
                                <td><img class="linkxoa" size_id=<?php echo $row[size_id]?> src="img/icons/trash.png" alt="" title="" border="0"></td>
      <?php } ?>
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
