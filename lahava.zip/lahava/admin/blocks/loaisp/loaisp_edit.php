<?php 
$idLoai = $_GET['idLoai'];settype($idLoai,"int");
$chitiet = $lsp->LoaiSP_ChiTiet($idLoai);
$row= mysql_fetch_assoc($chitiet);
if(isset($_POST[btnSumit])){
	$thanhcong = $lsp->LoaiSP_Edit($idLoai,$loi);	
	if($thanhcong==true){
		header("location:?com=loaisp_list");
	}
}
?>
<script type="text/javascript">
	$(document).ready(function(){
		$("input[name=TenLoai]").blur(function(){
			var TenLoai= $(this).val();
			$.post("blocks/ajax.php",{str:TenLoai},function(data){				
				$("input[name=TenLoai_KD]").val(data);
			})
		})		
	})
</script>
<form action="" method="post" name="form_add_dm_tour">
<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý loại sản phẩm : cập nhật</h3>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div id="main_left" style="clear:both">
    	<fieldset>
        	<legend>Thông tin chi tiết</legend>
            	<table>                	             
                    <tr class="left">
                    	<td>Tên loại</td>
                        <td>
                        <input type="text" name="TenLoai" id="TenLoai" class="tf" value="<?php echo $row['loai_vi'];?>" disabled="disabled" />                        	
                        </td>                        
                    </tr>                   
                    <tr>
                   	  <td class="left">&nbsp;</td>
                        <td>&nbsp;
                         
                        </td>                        
                    </tr>
                </table>
            
        </fieldset>
    </div>
    <div style="clear:both;margin-bottom:10px"></div>
	<div id="main_right">
    	<fieldset class="details_form">
        	<legend>Metadata VI</legend>
            <table>
                <tr>
                    <td>Title VI</td>
                    <td><input type="text" name="title_vi" id="title_vi" class="tf" value="<?php echo $row['title_vi'];?>" /></td>                        
                </tr>
                <tr>
                    <td>Meta Description VI</td>
                    <td><textarea class="meta" name="metad_vi"><?php echo $row['metad_vi'];?></textarea></td>                        
                </tr>
                <tr>
                    <td>Meta Keyword VI</td>
                    <td><textarea class="meta" name="metak_vi"><?php echo $row['metak_vi'];?></textarea></td>                        
                </tr>                    
            </table>
        </fieldset>
    </div>
    <div id="main_right">
    	<fieldset class="details_form">
        	<legend>Metadata EN</legend>
            <table>
                <tr>
                    <td>Title EN</td>
                    <td><input type="text" name="title_en" id="title_en" class="tf" value="<?php echo $row['title_en'];?>" /></td>                        
                </tr>
                <tr>
                    <td>Meta Description EN</td>
                    <td><textarea class="meta" name="metad_en"><?php echo $row['metad_en'];?></textarea></td>                        
                </tr>
                <tr>
                    <td>Meta Keyword EN</td>
                    <td><textarea class="meta" name="metak_en"><?php echo $row['metak_en'];?></textarea></td>                        
                </tr>                    
            </table>
        </fieldset>
    </div>
  
    <div class="clr"></div>
</div>
</form>