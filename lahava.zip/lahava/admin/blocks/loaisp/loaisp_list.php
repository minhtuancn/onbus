<?php 
$loai = $lsp->getListLoaiSP();
?>
<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").live('click',function(){			
			var flag = confirm("Bạn có chắc chắn xóa");
			if(flag == true){
				var idLoai = $(this).attr("idLoai");
				$.get('xoa.php',{loai:"loaisp",id:idLoai},function(data){
					window.location.reload();			
				});	
			}
		})
         $(".tang").live('click',function(){
            var ThuTu = $(this).attr("ThuTu");			
            $.post('tang.php',{loai:'loaisp',ThuTu:ThuTu},function(data){
				window.location.reload();
            })
        })
		$(".giam").live('click',function(){
            var ThuTu = $(this).attr("ThuTu");
            $.post('giam.php',{loai:'loaisp',ThuTu : ThuTu},function(data){
				window.location.reload();
            })
        })
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:80%">
		<h3>Quản lý loại SP : Xem danh sách</h3>
    </div>    
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div>
    	<fieldset>
        	<legend>++ Loại SP ++</legend>
            	<div style="text-align: center">                                     
                    <table id="rounded-corners" summary="2007 Major IT Companies&#39; Profit">
                        <thead>                        
                            <tr style="background-color:#03F;color:#FFF;height:30px">
                                <th scope="col" class="rounded-company"></th>                                       
                                <th scope="col" class="rounded">Tên loại</th>
                                <th scope="col" class="rounded">Sửa</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php 
				
                        while($row=mysql_fetch_assoc($loai)) {                 
						$i++;
                        ?>	
                            <tr <?php if($i%2==0) echo "bgcolor='#CCC'" ; ?>>
                                <td><input type="checkbox" name="chon" idLoai=<?php echo $row['loai_id']?>></td>                                  
                                <td align="left"><?php echo $row['loai_vi']; ?></td>
                               
                                <td><a href="index.php?com=loaisp_edit&amp;idLoai=<?php echo $row['loai_id']?>"><img src="img/icons/user_edit.png" alt="" title="" border="0"></a></td>                               
      <?php } ?>
      				
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
