<?php 
$link = "index.php?com=khachhang_list";

$limit =10;

$sanphams = $kh->KhachHang_List(-1,-1);

$total_record = mysql_num_rows($sanphams);

$total_page = ceil($total_record/$limit);

if(isset($_GET['page'])==false){
	$page = 1;
}
else{ 
	$page=$_GET['page'];
	settype($page,"int");
}

$offset = $limit * ($page - 1);
$listsp = $kh->KhachHang_List($limit,$offset);
$page_show=10;
?>
<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").click(function(){
			var obj = $(this);
			var flag = confirm('Bạn có chắc chắn xóa ?');
			if(flag==true){			
				var idKH = $(this).attr("idKH");
				$.get('xoa.php',{loai:"linkxoa",id:idKH},function(data){
					obj.parent().parent().remove();//window.location.reload();			
				});	
			}else{
				return false;
			}
		})
		$(".changestatus").click(function(){
			var obj = $(this);
			var flag = confirm('Thay đổi trạng thái đơn hàng ?');
			if(flag==true){			
				var idDH = obj.attr("idDH");
				var status = obj.attr("status");
				$.post('ajax/updatedonhang.php',{idDH:idDH,status:status},function(data){
					if(obj.attr('src')=='img/dagiao.png'){
						obj.attr('src','img/chuagiao.png');
						obj.attr('status',1);		
					}else{
						obj.attr('src','img/dagiao.png');
						obj.attr('status',0);
					}
				});	
			}else{
				return false;
			}
		})
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý khách hàng : Danh sách</h3>
    </div>
	
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div>
    	<fieldset>
        	<legend>++ Danh sách khách hàng ++</legend>
            	<div style="text-align: center">                     
                    <table id="rounded-corners" summary="2007 Major IT Companies&#39; Profit">
                        <thead>
                            <tr>
                                <td colspan="10">                                
									<?php echo $kh->phantrang($page,$page_show,$total_page,$link);?>                                   
                                </td>
                            </tr>
                            <tr style="background-color:#06F;height:30px;color:#FFF">
                                <th scope="col" class="rounded-company"></th>       
                                <th scope="col" class="rounded" align="left">Họ Tên</th>
                                <th scope="col" class="rounded" align="left">Email</th>
                                <th scope="col" class="rounded" align="left">Điện thoại</th>
                                <th scope="col" class="rounded" align="left">Địa chỉ</th> 
                                <th scope="col" class="rounded" width="1%" align="right" style="white-space:nowrap;padding:5px">Số lần mua</th> 
                                <th scope="col" class="rounded" width="1%" style="white-space:nowrap;padding:5px">Tổng tiền mua</th>
                                <th scope="col" class="rounded" width="1%" style="white-space:nowrap;padding:5px">Lần mua cuối</th>
                                <th scope="col" class="rounded" width="1%" style="white-space:nowrap;padding:5px">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php 
						$i=0;     
						if(mysql_num_rows($listsp) > 0){                   
                          while($row = mysql_fetch_assoc($listsp))     {  
						  $i++;              
						  $arrDetailCustommer = $kh->getDetailCustommer($row['idKH']);
                        ?>	
                            <tr <?php if($i%2==0) echo "bgcolor='#FFFF99'" ; ?> >
                                <td><input type="checkbox" name="chon" idDH=<?php echo $row['idKH']; ?>></td>
                                <td align="left"><?php echo $arrDetailCustommer['hoten']; ?></td>  
                                <td align="left"><?php echo $arrDetailCustommer['email'];?></td>    
                                <td align="left"><?php echo $arrDetailCustommer['dienthoai'];?></td>                                 
                                <td align="left"><?php echo $arrDetailCustommer['diachi'];?></td>
                                <td align="right"><?php echo $row['solanmua']; ?></td>
                                <td align="right"><?php echo number_format($row['tongtien']); ?></td>
                                <td align="right"><?php echo date('d-m-Y H:i',$row['lanmuacuoi']); ?></td>
                                                           
                                <td style="white-space:nowrap;padding:5px">                                
                                <img class="linkxoa" idKH="<?php echo $row['idKH']; ?>" src="img/icons/trash.png" alt="" title="" border="0"></td>
                            </tr>
                        <?php  } }else{?>
                        <tr><td colspan="9">Không có khách hàng nào !</td></tr>
                        <?php } ?>
                        <tr>
                                <td colspan="10"><?php echo $kh->phantrang($page,$page_show,$total_page,$link);?></td>
                            </tr>
                        
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
