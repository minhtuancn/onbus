<?php 
if(isset($_POST[btnSumit])){	
	$thanhcong = $kieu->Kieu_Them($loi);	
	if($thanhcong==true){
		header("location:?com=kieu_list");
	}
}
?>
<form action="" method="post" name="form_add_dm_tour">
<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý kiểu : Thêm mới</h3>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div id="main_left">
    	<fieldset>
        	<legend>Thông tin chi tiết</legend>
            	<table>
                	<tr>
                   	  <td class="left">Kiểu- VI</td>
                        <td>
                            <input type="text" name="kieu_vi" id="kieu_vi" class="tf" />
                        	<span class="error"><?php echo $loi[kieu_vi];?></span>                 
                        </td>                        
                    </tr>                    
                    <tr class="left">
                    	<td>Kiểu - EN</td>
                        <td><input type="text" name="kieu_en" id="kieu_en" class="tf" />
                        	<span class="error"><?php echo $loi[kieu_en];?></span>
                        </td>                        
                    </tr>     
                     
                  
                    <tr>
                   	  <td class="left">&nbsp;</td>
                        <td>&nbsp;
                         
                        </td>                        
                    </tr>
                </table>
            
        </fieldset>
    </div>
	
  
    <div class="clr"></div>
</div>
</form>