<?php 
$sp_id = (int) $_GET['sp_id'];

$chitiet = $sp->getDetailSP($sp_id);
$row_chitiet = mysql_fetch_assoc($chitiet);

$arrLoai =  $sp->getLoaiIdByProductId($sp_id);
$arrKieu =  $sp->getKieuIdByProductId($sp_id);
$arrSize = $sp->getSizeIdByProductId($sp_id);
$arrMau = $sp->getMauIdByProductId($sp_id);
$arrChat = $sp->getChatIdByProductId($sp_id);

$arrTagVi = $sp->getTagsOfProductId($sp_id,"vi");
$arrTagEn = $sp->getTagsOfProductId($sp_id,"en");

if(!empty($arrTagVi)){
	$strTagVi = "";
	foreach($arrTagVi as $tag_id){
		$rs_tag = $sp->getDetailTag($tag_id);
		$row_tag = mysql_fetch_assoc($rs_tag);
		$strTagVi.=$row_tag["tag_name"]."; ";
	}	
}
if(!empty($arrTagEn)){
	$strTagEn = "";
	foreach($arrTagEn as $tag_id){
		$rs_tag = $sp->getDetailTag($tag_id);
		$row_tag = mysql_fetch_assoc($rs_tag);
		$strTagEn.=$row_tag["tag_name"]."; ";
	}	
}


if($row_chitiet['hinh_anh']!="") 
$arrImg = $sp->getArrImages($row_chitiet['hinh_anh']);

$loai = $lsp->getListLoaiSP();
$listKieu = $kieu->getListKieuDang();
$listchat = $chat->getListChatLieu();

if(isset($_POST[btnSumit])){			
	$thanhcong = $sp->SanPham_Sua($sp_id,$loi);	
	if($thanhcong==true){		
		header("location:?com=sp_list");
	}
}
?>
<script>
	$(document).ready(function(){
		// ten kd
		$("input[name=ten_sp_vi]").blur(function(){
			var ten_sp_vi= $(this).val();
			$.post("blocks/ajax.php",{str:ten_sp_vi},function(data){				
				$("input[name=ten_sp_vi_kd]").val(data);
			})
		})
		$("input[name=ten_sp_en]").blur(function(){
			var ten_sp_en= $(this).val();
			$.post("blocks/ajax.php",{str:ten_sp_en},function(data){				
				$("input[name=ten_sp_en_kd]").val(data);
			})
		})
		//check all
		$('#tags_vi').on("keydown", function (event) {
				if (event.keyCode === $.ui.keyCode.TAB && $(this).data("autocomplete").menu.active) {
					event.preventDefault();
				}
			}).autocomplete({
				source: function (request, response) {
					$.getJSON("ajax_tag.php", {
						term: extractLast(request.term)
					}, response);
				},
				search: function () {
					// custom minLength
					var term = extractLast(this.value);
					if (term.length < 2) {
						return false;
					}
				},
				focus: function () {
					// prevent value inserted on focus
					return false;
				},
				select: function (event, ui) {
					var terms = split(this.value);
					// remove the current input
					terms.pop();
					// add the selected item
					terms.push(ui.item.value);
					// add placeholder to get the comma-and-space at the end
					terms.push("");
					this.value = terms.join("; ");
					return false;
				}
			});
		$('#tags_en').on("keydown", function (event) {
				if (event.keyCode === $.ui.keyCode.TAB && $(this).data("autocomplete").menu.active) {
					event.preventDefault();
				}
			}).autocomplete({
				source: function (request, response) {
					$.getJSON("ajax_tag_en.php", {
						term: extractLast(request.term)
					}, response);
				},
				search: function () {
					// custom minLength
					var term = extractLast(this.value);
					if (term.length < 2) {
						return false;
					}
				},
				focus: function () {
					// prevent value inserted on focus
					return false;
				},
				select: function (event, ui) {
					var terms = split(this.value);
					// remove the current input
					terms.pop();
					// add the selected item
					terms.push(ui.item.value);
					// add placeholder to get the comma-and-space at the end
					terms.push("");
					this.value = terms.join("; ");
					return false;
				}
			});	
		$("#color_all").click(function() 
		  { 
		   var checked_status = this.checked; 
		   $("input.mau").each(function() 
		   { 
			this.checked = checked_status; 
		   }); 
		 }); 
		 $("#size_all").click(function() 
		  { 
		   var checked_status = this.checked; 
		   $("input.size").each(function() 
		   { 
			this.checked = checked_status; 
		   }); 
		 }); 		
				
		$('#upload_images').ajaxForm({
     		beforeSend: function() {				
			},
			uploadProgress: function(event, position, total, percentComplete) {
				           
			},
			complete: function(data) {       
				var arrRes = JSON.parse(data.responseText); 
				alert(arrRes['thongbao']);
				$("#hinhanh").html(arrRes['text'] + arrRes['str_hinhanh']);
				$( "#div_upload" ).dialog('close');				
			}
    	}); 
		$("#btnUpload").click(function(){
			$("#div_upload" ).dialog({
				modal: true,
				title: 'Upload images',
				width: 350,
				draggable: true,
				resizable: false,
				position: "center middle"
			});
		});
		$("#add_images").click(function(){
			$( "#wrapper_input_files" ).append("<input type='file' name='images[]' /><br />");
		});
	});
function split(val) {
	return val.split(/;\s*/);
}

function extractLast(term) {
	return split(term).pop();
}	
</script>
<style>
#div_upload{font-size:13px;text-align:center}

</style>
<form action="" method="post" name="form_add_dm_ks">
<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý sản phẩm: Thêm mới</h3>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div id="main_left" style="width:70%">
    	<fieldset>
        	<legend>Thông tin chung</legend>
            	<table>                	
                   	<tr>
                    	<td>Loại SP</td>
                        <td colspan="3">
                         <table style="width:300px" cellpadding="0" cellspacing="0">
                   		 <tr>
                                <?php                              
                                while($row_loai = mysql_fetch_assoc($loai)){
                                ?>
                                <td style="width:20px;padding:0px;text-align:center">
                                	<input class="size" type="checkbox" name="loai_id[]" value="<?php echo $row_loai['loai_id'];?>" <?php if(in_array($row_loai['loai_id'],$arrLoai)==true) echo "checked"; ?> /><br /> 
									<?php echo $row_loai['loai_vi'];?></td>                               
                                <?php } ?>
                            </tr>
                            </table>
                        </td>   
                    </tr> 
                    <tr>
                    	<td>Chất liệu</td>
                        <td colspan="3">
                         <table style="width:300px" cellpadding="0" cellspacing="0">
                   		 <tr>
                                <?php                              
                                while($row_chat = mysql_fetch_assoc($listchat)){
                                ?>
                                <td style="width:20px;padding:0px;text-align:center"><input class="size" type="checkbox" name="chat_id[]" value="<?php echo $row_chat['chat_id'];?>" 
                                <?php if(in_array($row_chat['chat_id'],$arrChat)==true) echo "checked"; ?>
                                /><br /> <?php echo $row_chat['chat_vi'];?></td>                               
                                <?php } ?>
                            </tr>
                            </table>
                        </td>   
                    </tr>    
                    <tr>
                    	<td>Kiểu dáng</td>
                        <td colspan="3">                       
                            <table style="width:300px" cellpadding="0" cellspacing="0">
                   		 		<tr>
                                <?php                              
                                while($row_kieu = mysql_fetch_assoc($listKieu)){
                                ?>
                                <td style="width:20px;padding:0px;text-align:center"><input class="size" type="checkbox" name="kieu_id[]" value="<?php echo $row_kieu['kieu_id'];?>" 
                                <?php if(in_array($row_kieu['kieu_id'],$arrKieu)==true) echo "checked"; ?>
                                /><br /><?php echo $row_kieu['kieu_vi'];?></td>                         
                                <?php } ?>
                                </tr>
                                </table>
                        </td>   
                    </tr>      
                     <tr>
                    <td>Mã SP</td>
                    <td><input type="text" name="ma_sp" id="ma_sp" class="tf" value="<?php echo $row_chitiet[ma_sp]?>" /></td>                        
                </tr>                                   
                    <tr class="left">
                    	<td>Tên SP VI</td>
                        <td><input type="text" name="ten_sp_vi" id="ten_sp_vi" class="tf" value="<?php echo $row_chitiet[ten_sp_vi]?>" />
                        	<span class="error"><?php echo $loi[ten_sp_vi];?></span>
                        </td>                
                        <td>Tên SP KD VI</td>
                        <td>
                        	<input type="text" name="ten_sp_vi_kd" id="ten_sp_vi_kd" class="tf" value="<?php echo $row_chitiet[ten_sp_vi_kd]?>"/>				                        </td>            
                    </tr>
                    <tr class="left">
                    	   <td>Tên SP EN</td>
                        <td><input type="text" name="ten_sp_en" id="ten_sp_en" class="tf" value="<?php echo $row_chitiet[ten_sp_en]?>" />
                        	<span class="error"><?php echo $loi[ten_sp_en];?></span>
                        </td>                
                        <td>Tên SP KD EN</td>
                        <td>
                        	<input type="text" name="ten_sp_en_kd" id="ten_sp_en_kd" class="tf" value="<?php echo $row_chitiet[ten_sp_en_kd]?>"/>		                 
                            
                            </td>
                    </tr>
                              
                </table>            
        </fieldset>
    </div>
	<div id="main_right" style="width:30%">
    	<fieldset class="details_form">
        	<legend>Tags</legend>
            <table>
           
                <tr>                   
                    <td colspan="2">VI :<textarea id="tags_vi" style="width:300px;height:100px" class="meta" name="tags_vi" rows="10" ><?php echo $strTagVi; ?></textarea></td>                        
                </tr>  
                <tr>                   
                    <td colspan="2">EN :<textarea id="tags_en" style="width:300px;height:100px" class="meta" name="tags_en" rows="10" ><?php echo $strTagEn; ?></textarea></td>                        
                </tr>                    
            </table>
        </fieldset>
    </div>
    <div id="main_details" style="clear:both;padding-top: 20px">
        <fieldset class="details_form">
        	<legend>Thông tin chi tiết</legend>
            <table border="1" cellspacing="0">
                <tr>
                    <td width="15%">Giá</td>
                    <td><input type="text" name="gia" id="gia" class="tf" value="<?php echo $row_chitiet[gia]?>" />
                        <span class="error"><?php echo $loi[gia];?></span>
                    </td>                        
                </tr>  
                 <tr>
                    <td width="15%">Khuyến mãi</td>
                    <td>
                    <select name="khuyen_mai">
                    	<option value="0">--Chọn--</option>
                        <?php for($i=5;$i<100;$i=$i+5){?>
                        <option value="<?php echo $i; ?>"
                         <?php if($row_chitiet['khuyen_mai'] == $i) echo "selected"; ?>
                        ><?php echo $i; ?></option>
                        <?php } ?>
                    </select> %               
                    </td>                        
                </tr>                                
                <tr>
                    <td width="15%">Ngày hết hạn</td>
                    <td><input type="text" name="ngay" id="ngay" class="tf ngay" 
                    value="<?php echo date('d-m-Y',strtotime($row_chitiet[ngay]));?>" />
                        <span class="error"><?php echo $loi[ngay];?></span>
                    </td>                        
            	</tr>               
                <tr>
                    <td>Upload hình</td>
                    <td>
                     <input type="hidden" name="hinh_anh_cu" value="<?php echo $row_chitiet['hinh_anh']; ?>" />
                    <div style="width:100%;height:200px">
                    <?php 
					if(!empty($arrImg)){
					foreach ($arrImg as $img){			
					?>
                    	<div style="width:100px;float:left;height:230px;margin-right:10px;text-align:center">
                        	<img src="../<?php echo $img; ?>" width="100px" height="150px" /><br /><br />
                           
                           
							<input type='radio' name='hinh_dai_dien' value='../<?php echo $img; ?>' 
                            <?php if($row_chitiet['hinh_dai_dien']=='../'.$img) echo "checked"; ?>
                            
                            />
                            <br /><br />
                            <span class="xoa_img" style="cursor:pointer">Xóa hình</span>
                        </div>
                        <?php }}?> 
                    </div>
                    <div style="clear:both"></div>
                    <div id="hinhanh">
                    
                    </div>
                    <div style="clear:both"></div>
                    <input type="button" id="btnUpload" value="Thêm hình" />
                    
                    </td>                        
                </tr>  
                 <tr>
                    <td>Size</td>
                    <td>
                    <input type="checkbox" id="size_all" name="size_all" value="all" /> All size<br /><br />
                    <table style="width:500px" cellpadding="0" cellspacing="0">
                    <tr>
                    <?php 
					$list_size = $size->getListSize();
					while($row_size = mysql_fetch_assoc($list_size)){
					?>
					<td style="width:10px;padding:0px">
                    <input class="size" type="checkbox" name="size[]" value="<?php echo $row_size['size_id'];?>" <?php if(in_array($row_size['size_id'],$arrSize)==true) echo "checked"; ?> /><br />
                    <?php echo $row_size['size']; ?></td>
                    <?php } ?>
                    </tr>
                    </table>
                    </td>                        
                </tr>      
                <tr>
                    <td>Color</td>
                    <td>
                    <input type="checkbox" id="color_all" name="color_all" value="all" /> All color<br /><br />
                    <table style="width:800px" cellpadding="0" cellspacing="0">
                    <tr>
                    <?php 
					$list_mau = $mau->getListMau();
					while($row_mau = mysql_fetch_assoc($list_mau)){
					?>
					<td style="width:20px;padding:0px;"><input class="mau" type="checkbox" name="mau[]" value="<?php echo $row_mau['mau_id'];?>" <?php if(in_array($row_mau['mau_id'],$arrMau)==true) echo "checked"; ?> /><br />
                   <img  src="<?php echo "../".str_replace('mausac','mausac/small',$row_mau['hinh']); ?>" />
                   
                    </td>
                    <?php } ?>
                    
                    </tr>
                    </table>
                    </td>                        
                </tr>                    
            </table>
        </fieldset>
        
    </div>
    <div id="main_details" style="clear:both;padding-top: 20px">
        <fieldset class="details_form">
        	<legend>++ Nội dung bài viết ++</legend>
            <table>                          
                <tr>
                    <td>Mô tả VI</td>
                    <td>
                        <textarea style="height:100px;width:500px" class="meta" name="mo_ta_vi" id="mo_ta_vi" rows="10"><?php echo $row_chitiet[mo_ta_vi]?></textarea>                       
                    </td>                        
                </tr>
                 <tr>
                    <td>Mô tả EN</td>
                    <td>
                        <textarea style="height:100px;width:500px" class="meta" name="mo_ta_en" id="mo_ta_en" rows="10"><?php echo $row_chitiet[mo_ta_en]?></textarea>                       
                    </td>                        
                </tr>
                                         
            </table>
        </fieldset>
        
    </div>
   
    <div class="clr"></div>
</div>
</form>
<div id="div_upload" style="display:none">
    <form id="upload_images" method="post" enctype="multipart/form-data" enctype="multipart/form-data" action="ajax.php">
        <div style="margin: auto;">       
            <img src="../images/add.png" id="add_images" width="32" />
            <div id="wrapper_input_files">
            	<input type="file" name="images[]" /><br />
                <input type="file" name="images[]" /><br />
                <input type="file" name="images[]" /><br />
            </div>            
            <div class="clear"></div>       
            <button style="margin-top: 10px;"class="button_colour" type="submit" id="btn_upload_images">                
                <a href="#">Upload</a>
            </button>        
        </div>
        
    </form>
</div>