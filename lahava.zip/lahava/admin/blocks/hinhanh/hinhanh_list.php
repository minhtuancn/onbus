<?php
$idAlbum = (int) $_GET['idAlbum'];
$hinhanhs = $lsp->listhinhanhbyalbum($idAlbum);
$album = $lsp -> album_chitiet($idAlbum);
$row_chitiet = mysql_fetch_assoc($album);
?>
<script type="text/javascript">
    $(document).ready(function(){		
        $(".linkxoa").live('click',function(){			
            var flag = confirm("Bạn có chắc chắn xóa");
            if(flag == true){
                var idHinh = $(this).attr("idHinh");
                $.get('xoa.php',{loai:"hinhalbum",id:idHinh},function(data){
                    window.location.reload();			
                });	
            }
        })
        
    })
</script>

<div id="admin_navigation">
    <div style="float:left;width:80%">
        <h3>Quản lý hình ảnh album : <span style="font-size: 18px;color:red"><?php echo $row_chitiet['TenAlbum'];?></span></h3>
    </div>

    <div style="float:left;width:5%;padding-top:5px">
        <a href="index.php?com=hinhanh_add&idAlbum=<?php echo $idAlbum; ?>"><input type="button" class="new" name="btnNew" value=""/></a><br />		
        <span>New</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
        <input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
        <input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
    <div style="clear:both"></div>
</div>
<div style="clear:both"></div>
<div id="main_admin">

    <div>
        <fieldset>
            <legend>++ Hình Ảnh ++</legend>
            <div style="text-align: center">                                    
                <?php while($row= mysql_fetch_assoc($hinhanhs)){?>
                <div class="photo" style="float:left;margin: 10px;border: 1px solid #CCC;padding: 5px">
                    <img src="<?php echo $row['urlNho']; ?>" width="120" height="150" /><br />
                    <p idHinh="<?php echo $row['idHinh']; ?>">
                        <img class="linkxoa" idHinh="<?php echo $row['idHinh']; ?>" src="img/icons/trash.png" alt="Xóa" title="Xóa" border="0">
                    </p>
                </div>
                <?php } ?>               
            </div>
        </fieldset>
    </div>


    <div class="clr"></div>
</div>
