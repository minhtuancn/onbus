<?php 
$idAlbum = (int) $_GET['idAlbum'];
$album = $lsp->album_chitiet($idAlbum);
$row_album = mysql_fetch_assoc($album);
if(isset($_POST['btnSumit'])){			
    $thanhcong = $sp->SanPham_Them($loi);	
    if($thanhcong==true){		
            header("location:?com=sp_list");
    }
}
?>
<script>
	$(document).ready(function(){
			
		$('#upload_images').ajaxForm({
     		beforeSend: function() {				
			},
			uploadProgress: function(event, position, total, percentComplete) {
				           
			},
			complete: function(data) {       
				var arrRes = JSON.parse(data.responseText); 
				alert(arrRes['thongbao']);
				$("#hinhanh").html(arrRes['text'] + arrRes['str_hinhanh']);
				$( "#div_upload" ).dialog('close');				
			}
    	}); 
		
		$("#add_images").click(function(){
			$( "#table_hinh" ).append('<tr><td><input type="file" name="imagesnho[]" /></td><td><input type="file" name="imageslon[]" /></td></tr> ');
		});
	});	
</script>
<style>
#div_upload{font-size:13px;text-align:center}

</style>

<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Thêm hình ảnh album : <span style="color:red;font-size:18px"><?php echo $row_album['TenAlbum']; ?></span></h3>
    </div>
	
    <div class="clr"></div>
</div>
<div id="main_admin">
    
    <div id="main_details" style="clear:both;padding-top: 20px;width:600px;margin: auto">
        <form action="uploadhinh.php" method="post" enctype="multipart/form-data" enctype="multipart/form-data">
        <fieldset class="details_form">
        	<legend>Upload</legend>
                <input type="hidden" name="idAlbum" id="idAlbum" value="<?php echo $idAlbum; ?>" />
                <p style="text-align: right"><img src="../shop/images/add.png" id="add_images" width="32" /></p>
            <table border="1" cellspacing="0" width="80%" id="table_hinh">
                <tr style="height:30px;color:blue;background-color: #999">
                    <th width="50%" align="center">Hình nhỏ</th>
                    <th width="50%" align="center">Hình lớn</th>                                          
                </tr>  
                <tr>
                    <td>
                        <input type="file" name="imagesnho[]" />
                    </td>
                    <td>
                        <input type="file" name="imageslon[]" />
                    </td>                        
                </tr>                                
                <tr>
                    <td>
                        <input type="file" name="imagesnho[]" />
                    </td>
                    <td>
                        <input type="file" name="imageslon[]" />
                    </td>                        
                </tr>                                
                <tr>
                    <td>
                        <input type="file" name="imagesnho[]" />
                    </td>
                    <td>
                        <input type="file" name="imageslon[]" />
                    </td>                        
                </tr> 
                <tr>
                    <td>
                        <input type="file" name="imagesnho[]" />
                    </td>
                    <td>
                        <input type="file" name="imageslon[]" />
                    </td>                        
                </tr>                                
                <tr>
                    <td>
                        <input type="file" name="imagesnho[]" />
                    </td>
                    <td>
                        <input type="file" name="imageslon[]" />
                    </td>                        
                </tr> 
                             
            </table>
                <div style="margin-top: 10px;text-align: center"><input type="submit" value="Save" name="btnSubmit" /></div>
        </fieldset>
        </form>
    </div> 
   
    <div class="clr"></div>
</div>

