<?php
$chungloai = $lsp->getListLoaiAlbum();
$link = "index.php?com=album_list";
$limit = 10;
$page_show = 5;
if (isset($_GET['idLoaiAlbum']) && $_GET['idLoaiAlbum'] > 0) {
    $idLoaiAlbum = (int) ($_GET['idLoaiAlbum']);
    $link.="&idLoaiAlbum=idLoaiAlbum";
} else {
    $idLoaiAlbum = -1;
}

$danhmucs = $lsp->album_list($idLoaiAlbum, -1, -1);
$total_record = mysql_num_rows($danhmucs);

$total_page = ceil($total_record / $limit);

if (isset($_GET['page']) == false) {
    $page = 1;
} else {
    $page = (int) $_GET['page'];
}

$offset = $limit * ($page - 1);
$loai = $lsp->album_list($idLoaiAlbum, $limit, $offset);
?>
<script type="text/javascript">
    $(document).ready(function(){		
        $(".linkxoa").live('click',function(){			
            var flag = confirm("Bạn có chắc chắn xóa");
            if(flag == true){
                var idAlbum = $(this).attr("idAlbum");
                $.get('xoa.php',{loai:"album",id:idAlbum},function(data){
                    window.location.reload();			
                });	
            }
        })
        
    })
</script>

<div id="admin_navigation">
    <div style="float:left;width:80%">
        <h3>Quản lý album : Xem danh sách</h3>
    </div>

    <div style="float:left;width:5%;padding-top:5px">
        <a href="index.php?com=album_add"><input type="button" class="new" name="btnNew" value=""/></a><br />		
        <span>New</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
        <input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
        <input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
    <div style="clear:both"></div>
</div>
<div style="clear:both"></div>
<div id="main_admin">

    <div>
        <fieldset>
            <legend>++ Album ++</legend>
            <div style="text-align: center"> 
                <form method="get">
                    <input type="hidden"  name="com" value="album_list"/>
                    <b>Loại Album</b>
                    <select id="idLoaiAlbum" name="idLoaiAlbum">
                        <option value="-1">--Tất cả--</option> 
                        <?php while ($row_cl = mysql_fetch_assoc($chungloai)) { ?>
                            <option 
                            <?php echo ($_GET['idLoaiAlbum'] == $row_cl['idLoaiAlbum']) ? "selected" : ""; ?>
                                value="<?php echo $row_cl['idLoaiAlbum']; ?>"><?php echo $row_cl['TenLoaiAlbum']; ?></option>
                        <?php } ?>
                    </select> 
                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value=" Tìm " name="btnTim" class="nut" />

                </form>                      
                <table id="rounded-corners" summary="2007 Major IT Companies&#39; Profit">
                    <thead>
                        <tr>
                            <td colspan="5"><?php echo $lsp->phantrang($page, $page_show, $total_page, $link); ?></td>
                        </tr>
                        <tr style="background-color:#03F;color:#FFF;height:30px">
                            <th scope="col" class="rounded-company"></th> 
                            <th scope="col" class="rounded" align="left">Loại Album</th>                                       
                            <th scope="col" class="rounded" align="left">Tên Album</th>                                
                            <th scope="col" class="rounded" width="150px">Action</th>                            
                        </tr>
                    </thead>

                    <tbody>
<?php
$i = 0;
while ($row = mysql_fetch_assoc($loai)) {
    $loaialbum = $lsp->loaialbum_chitiet($row['idLoaiAlbum']);
    $row_loaialbum = mysql_fetch_assoc($loaialbum);
    $i++;
    ?>	
                            <tr <?php if ($i % 2 == 0) echo "bgcolor='#CCC'"; ?>>
                                <td><input type="checkbox" name="chon" idAlbum=<?php echo $row['idAlbum'] ?>></td>                                 
                                <td align="left"><?php echo $row_loaialbum['TenLoaiAlbum'] ?></td>   
                                <td align="left"><?php echo $row['TenAlbum'] ?></td>                                   
                                <td>
                                    <a href="index.php?com=hinhanh_list&amp;idAlbum=<?php echo $row['idAlbum'] ?>"><img src="img/icons/pic.png" alt="Danh sách hình ảnh" title="Danh sách hình ảnh" border="0"></a>
                                    &nbsp;&nbsp;
                                    <a href="index.php?com=album_edit&amp;idAlbum=<?php echo $row['idAlbum'] ?>"><img src="img/icons/user_edit.png" alt="Chỉnh sửa" title="Chỉnh sửa" border="0"></a>
                                    &nbsp;&nbsp;
                                    <img class="linkxoa" idAlbum="<?php echo $row['idAlbum']; ?>" src="img/icons/trash.png" alt="Xóa" title="Xóa" border="0">
                                </td></tr>
<?php } ?>
                        <tr>
                            <td colspan="5"><?php echo $lsp->phantrang($page, $page_show, $total_page, $link); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </fieldset>
    </div>


    <div class="clr"></div>
</div>
