<?php
$chungloai = $lsp->getListLoaiAlbum();
if (isset($_POST['btnSumit'])) {
    $thanhcong = $lsp->album_them($loi);
    if ($thanhcong == true) {
        header("location:?com=album_list");
    }
}
?>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("input[name=TenAlbum]").blur(function(){
            var TenLT= $(this).val();
            $.post("blocks/ajax.php",{str:TenLT},function(data){				
                $("input[name=TenAlbum_KD]").val(data);
            })
        })		
    })
</script>
<form action="" method="post" name="form_add_dm_tour">
    <div id="admin_navigation">
        <div style="float:left;width:90%">
            <h3>Quản lý album : Thêm mới</h3>
        </div>    
        <div style="float:left;width:5%;padding-top:5px">
            <input type="submit" class="save" name="btnSumit" value=""/><br />		
            <span>Save</span>
        </div>
        <div style="float:left;width:5%;padding-top:5px">
            <input type="reset" class="cancel" name="btnCancel" value=""/><br />		
            <span>Reset</span>
        </div>
        <div class="clr"></div>
        <div style="clear:both"></div>
    </div>
    <div style="clear:both"></div>
    <div id="main_admin">
        <div style="clear:both"></div>
        <div id="main_left">
            <fieldset>
                <legend>Thông tin chi tiết</legend>
                <table>
                    <tr class="left">
                        <td>Loại Album</td>
                        <td>
                            <select id="idLoaiAlbum" name="idLoaiAlbum">
                                <option value="-1">--Tất cả--</option> 
                                <?php while ($row_cl = mysql_fetch_assoc($chungloai)) { ?>
                                    <option 
                                    <?php echo ($_GET['idLoaiAlbum'] == $row_cl['idLoaiAlbum']) ? "selected" : ""; ?>
                                        value="<?php echo $row_cl['idLoaiAlbum']; ?>"><?php echo $row_cl['TenLoaiAlbum']; ?></option>
                                    <?php } ?>
                            </select> 

                        </td>                        
                    </tr>               
                    <tr class="left">
                        <td>Tên album </td>
                        <td><input type="text" name="TenAlbum" id="TenAlbum" class="tf" />
                            <span class="error"><?php echo $loi['TenAlbum']; ?></span>
                        </td>                        
                    </tr>
                    <tr class="left">
                        <td>Tên album KD</td>
                        <td><input type="text" name="TenAlbum_KD" id="TenAlbum_KD" class="tf"/></td>                        
                    </tr>                                        
                    <tr>
                        <td class="left">&nbsp;</td>
                        <td>&nbsp;

                        </td>                        
                    </tr>
                </table>

            </fieldset>
        </div>
        <div id="main_right">
            
        </div>

        <div class="clr"></div>
        <div style="clear:both"></div>
    </div>
    <div style="clear:both"></div>
</form>