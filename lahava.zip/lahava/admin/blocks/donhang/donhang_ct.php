<?php 
$idDH = (int) $_GET['idDH'];
$arrList = $dh->getDetailDonHang($idDH);
?>
<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").live("click",function(){			
			var idSP = $(this).attr("idSP");
			$.get('xoa.php',{loai:"sanpham",id:idSP},function(data){
				window.location.reload();			
			});	
		})
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Chi tiết đơn hàng : <?php echo $idDH; ?></h3>
    </div>
	
    <div class="clr"></div>
</div>
<div id="main_admin">

    
	<div>
    	<fieldset>
        	<legend>++ Đơn hàng chi tiết ++</legend>
            	<div style="text-align: center">                     
                    <table id="rounded-corners" summary="2007 Major IT Companies&#39; Profit">
                        <thead>                           
                            <tr style="background-color:#06F;height:30px;color:#FFF">
                                <th scope="col" class="rounded-company" width="1%"></th>
                                <th scope="col" class="rounded" width="30%">Tên SP</th>
                                <th scope="col" class="rounded">Số lượng</th> 
                                <th scope="col" class="rounded" align="right">Thành tiền</th>
                                <th scope="col" class="rounded">Màu sắc</th>
                                <th scope="col" class="rounded">Size</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
						$i=0;     
						if($arrList){                   
                         foreach($arrList as $row){  					
						  $i++;              
                        ?>	
                            <tr <?php if($i%2==0) echo "bgcolor='#CCC'" ; ?> >
                                <td><input type="checkbox" name="chon" idChiTiet=<?php echo $row['idDHCT']; ?> /></td>                                <td align="left"><?php echo $sp->getNameProduct($row['sp_id']); ?></td>
                                <td align="center"><?php echo $row['soluong'] ?></td>     
                                <td align="right"><?php echo number_format($row['tiensp']);?></td>   
                                <td align="center"><?php echo $mau->getNameColor($row['mausac']); ?></td>     
                                <td align="center"><?php echo $row['size'];?></td>                          
                            </tr>
                        <?php  } }else{?>
                        <tr><td colspan="9">Không có đơn hàng nào !</td></tr>
                        <?php } ?>
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
