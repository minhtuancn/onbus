<?php 
$link = "index.php?com=donhang_list";

if(isset($_GET['status']) && $_GET['status'] > 0 ){
    $status =$_GET['status'];
   $link.="&status=$status";
 }else {
    $status = 0;
}


$limit =10;

$sanphams = $dh->DonHang_List($status,-1,-1);

$total_record = mysql_num_rows($sanphams);

$total_page = ceil($total_record/$limit);

if(isset($_GET['page'])==false){
	$page = 1;
}
else{ 
	$page=$_GET['page'];
	settype($page,"int");
}

$offset = $limit * ($page - 1);
$listsp = $dh->DonHang_List($status,$limit,$offset);
$page_show=10;
?>
<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").click(function(){
			var obj = $(this);
			var flag = confirm('Bạn có chắc chắn xóa ?');
			if(flag==true){			
				var idDH = $(this).attr("idDH");
				$.get('xoa.php',{loai:"donhang",id:idDH},function(data){
					obj.parent().parent().remove();//window.location.reload();			
				});	
			}else{
				return false;
			}
		})
		$(".changestatus").click(function(){
			var obj = $(this);
			var flag = confirm('Thay đổi trạng thái đơn hàng ?');
			if(flag==true){			
				var idDH = obj.attr("idDH");
				var status = obj.attr("status");
				$.post('ajax/updatedonhang.php',{idDH:idDH,status:status},function(data){
					if(obj.attr('src')=='img/dagiao.png'){
						obj.attr('src','img/chuagiao.png');
						obj.attr('status',1);		
					}else{
						obj.attr('src','img/dagiao.png');
						obj.attr('status',0);
					}
				});	
			}else{
				return false;
			}
		})
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý đơn hàng : Danh sách</h3>
    </div>
	
    <div class="clr"></div>
</div>
<div id="main_admin">

	<div style="margin-bottom:20px">
    	<form method="get">
        	<input type="hidden"  name="com" value="donhang_list"/>
    	<fieldset>
        	<legend>++ Tìm kiếm ++</legend>
            	<div style="text-align: left">                              
                 &nbsp;&nbsp;&nbsp;&nbsp;<b>Trạng thái</b>
                 <select id="status" name="status">
                          	<option value="-1">--Tất cả--</option> 
                           
                            <option value="0" <?php if($_GET['status']==0) echo "selected"; ?>>Chưa xử lý</option>
                            <option value="1" <?php if($_GET['status']==1) echo "selected"; ?>>Đã xử lý</option>
                           
                          </select> 
                &nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value=" Tìm " name="btnTim" class="nut" />
                </div>
        </fieldset>
        </form>
    </div><!---tim kiem -->
	<div>
    	<fieldset>
        	<legend>++ Danh sách đơn hàng ++</legend>
            	<div style="text-align: center">                     
                    <table id="rounded-corners" summary="2007 Major IT Companies&#39; Profit">
                        <thead>
                            <tr>
                                <td colspan="10">
                                <div style="float:left;width:50%;color:red;text-align:left">
                                	Click vào icon <img src="img/dagiao.png" width="20" /> hoặc <img src="img/chuagiao.png" width="20" />
                                    để thay đổi trạng thái đơn hàng.
                                </div>
                                <div style="float:left;width:50%">
									<?php echo $dh->phantrang($page,$page_show,$total_page,$link);?>
                                </div>    
                                </td>
                            </tr>
                            <tr style="background-color:#06F;height:30px;color:#FFF">
                                <th scope="col" class="rounded-company"></th>       
                                <th scope="col" class="rounded" align="center">idDH</th>
                                <th scope="col" class="rounded" align="left">Khách hàng</th>
                                <th scope="col" class="rounded">Email</th>
                                <th scope="col" class="rounded">Điện thoại</th>
                                <th scope="col" class="rounded">Địa chỉ</th> 
                                <th scope="col" class="rounded" width="1%" style="white-space:nowrap;padding:5px">Tổng tiền</th> 
                                <th scope="col" class="rounded" width="1%" style="white-space:nowrap;padding:5px">Tổng SP</th>
                                <th scope="col" class="rounded" width="1%" style="white-space:nowrap;padding:5px">Thời gian đặt</th>
                                <th scope="col" class="rounded" width="1%" style="white-space:nowrap;padding:5px">Trạng thái</th>
                                <th scope="col" class="rounded" width="1%" style="white-space:nowrap;padding:5px">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php 
						$i=0;     
						if(mysql_num_rows($listsp) > 0){                   
                          while($row = mysql_fetch_assoc($listsp))     {  
						  $i++;              
						  $arrDetailCustommer = $kh->getDetailCustommer($row['idKH']);
                        ?>	
                            <tr <?php if($row['status']==0) echo "bgcolor='#FFFF99'" ; ?> >
                                <td><input type="checkbox" name="chon" idDH=<?php echo $row['idKH']; ?>></td>                                <td align="center"><?php echo $row['idDH']; ?></td>   
                                <td align="left"><?php echo $arrDetailCustommer['hoten']; ?></td>  
                                <td align="left"><?php echo $arrDetailCustommer['email'];?></td>    
                                <td align="left"><?php echo $arrDetailCustommer['dienthoai'];?></td>                                 
                                <td align="left"><?php echo $arrDetailCustommer['diachi'];?></td>
                                <td align="right"><?php echo number_format($row['tongtiendh']); ?></td>
                                <td align="center"><?php echo $row['tongsp']; ?></td>
                                <td align="center"><?php echo date('d-m-Y H:i',$row['ngaymua']); ?></td>
                                <td align="center">
                                <?php if($row['status']==0){ ?>
                                	<img onclick="return confirm('Thay đổi trạng thái đơn hàng ?');" class="changestatus" idDH=<?php echo $row['idDH']?> src="img/chuagiao.png" border="0" width="20" status="1" />
								<?php }else{ ?>
                                	<img onclick="return confirm('Thay đổi trạng thái đơn hàng ?');" class="changestatus" idDH=<?php echo $row['idDH']?> src="img/dagiao.png" border="0" width="20" status="0" />
                                <?php } ?>
                                </td>                                 
                                <td style="white-space:nowrap;padding:5px">
                                <a href="index.php?com=donhang_chitiet&idDH=<?php echo $row['idDH']; ?>" style="text-decoration:none">
                                <img src="img/detail.png" alt="Xem chi tiết" title="Xem chi tiết" border="0" width="16">
                                </a>
                                <img class="linkxoa" idDH=<?php echo $row['idDH']?> src="img/icons/trash.png" alt="" title="" border="0"></td>
                            </tr>
                        <?php  } }else{?>
                        <tr><td colspan="9">Không có đơn hàng nào !</td></tr>
                        <?php } ?>
                        <tr>
                                <td colspan="10"><?php echo $dh->phantrang($page,$page_show,$total_page,$link);?></td>
                            </tr>
                        
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
