<div id="menu">
<ul>
<li><a href="mainquantri.php">Trang chủ</a>
	<div class="hidden" >	   
        <a href="mainquantri.php?p=footer">Footer</a>        
        <a href="mainquantri.php?p=nickyahoo">Nick hỗ trợ</a>                      
    </div>
</li>
<li><a href="#">Chất liệu</a> 
    <div class="hidden" >
	    <a href="?com=chat_add">Thêm mới</a>
        <a href="?com=chat_list">Xem danh sách</a>              
    </div>
</li>
<li><a href="#">Loại Sản Phẩm</a>
    <div class="hidden" >
	    <a href="?com=loaisp_add">Thêm mới</a>
        <a href="?com=loaisp_list">Xem danh sách</a>       
    </div>
</li>
<li><a href="#">Sản phẩm</a> 
    <div class="hidden" >
       	<a href="?com=sp_add">Thêm mới SP</a>
        <a href="?com=sp_list">Danh sách SP</a>        
        <a href="?com=mau_list">Màu sắc</a>
        <a href="?com=size_list">Size</a> 
        <a href="?com=kieu_list">Kiểu dáng</a>  
    </div>
</li>
<li><a href="?com=khachhang_list">Khách hàng</a>    
</li>
<li><a href="?com=donhang_list">Đơn hàng</a> 
</li>
</li>
<li><a href="#">User</a> 
    <div class="hidden" >   
        <a href="?com=user_list" >Xem danh sách</a> 
        
    </div>
</li>  
<li><a href="?com=footer">Menu Footer</a>    
</li>
<li><a href="#">Hình ảnh</a>    
    <div class="hidden" >   
        <a href="?com=loaialbum_list" >Loại Album</a> 
        <a href="?com=album_list" >Album</a> 
    </div>
</li>
<li><a href="?com=lang_list">Ngôn ngữ</a></li> 

<li><a target="_blank" href="http://trangmuasam.com.vn/testmail1">Gửi DEAL</a></li>      
</ul>
</div>
<div id="submenu"></div>