<?php 
$loai = $lsp->getListLoaiSP();
$link = "index.php?com=sp_list";

if(isset($_GET[loai_id]) && $_GET[loai_id] > 0 ) 
    { $loai_id =$_GET[loai_id];
    $link.="&loai_id=$loai_id";
}else { $loai_id = -1;}
if(isset($_GET[tukhoa]) && $_GET[tukhoa] != "" ) { $tukhoa =($_GET[tukhoa]);
$link.="&tukhoa=$tukhoa";
}else{ $tukhoa = "";}

$limit = 100;

$sanphams = $sp->SanPham_List($loai_id,$tukhoa);

$total_record = mysql_num_rows($sanphams);

$total_page = ceil($total_record/$limit);

if(isset($_GET[page])==false){
	$page = 1;
}
else{ 
	$page=$_GET[page];
	settype($page,"int");
}

$offset = $limit * ($page - 1);
$listsp = $sp->SanPham_List($loai_id,$tukhoa,$limit,$offset);
$page_show=5;
?>
<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").live("click",function(){			
			var idSP = $(this).attr("sp_id");
			$.get('xoa.php',{loai:"sanpham",id:idSP},function(data){
				window.location.reload();			
			});	
		})
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý sản phẩm : Danh sách</h3>
    </div>
	
    <div class="clr"></div>
</div>
<div id="main_admin">

	<div style="margin-bottom:20px">
    	<form method="get">
        	<input type="hidden"  name="com" value="sp_list"/>
    	<fieldset>
        	<legend>++ Tìm kiếm ++</legend>
            	<div style="text-align: left">                
                 &nbsp;&nbsp;&nbsp;&nbsp;<b>Loại sản phẩm</b>
                <select name="loai_id" id="loai_id">
                    <option value="-1">--Tất cả--</option>
                    <?php                              
                    while($row_loai = mysql_fetch_assoc($loai)){
                    ?>
                    <option value="<?php echo $row_loai[loai_id]?>"
                    <?php if($_GET[loai_id]==$row_loai[loai_id]) echo "selected"; ?>
                    >
                        <?php echo $row_loai[loai_vi];?>
                    </option>
                    <?php } ?>
                </select>
                &nbsp;&nbsp;&nbsp;&nbsp;<b>Từ khóa</b>
                <input type="text" name="tukhoa" value="<?php echo $_GET[tukhoa]?>"  />
                &nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value=" Tìm " name="btnTim" class="nut" />
                </div>
        </fieldset>
        </form>
    </div><!---tim kiem -->

    
    
    
    
	<div>
    	<fieldset>
        	<legend>++ Danh sách sản phẩm ++</legend>
            	<div style="text-align: center">                     
                    <table id="rounded-corners" summary="2007 Major IT Companies&#39; Profit">
                        <thead>
                            <tr>
                                <td colspan="6"><?php echo $lsp->phantrang($page,$page_show,$total_page,$link);?></td>
                            </tr>
                            <tr style="background-color:#06F;height:30px;color:#FFF">
                                <th scope="col" class="rounded-company"></th>       
                               
                                <th scope="col" class="rounded" align="left">Tên sản phẩm</th>
                                <th scope="col" class="rounded">Hình</th> 
                                <th scope="col" class="rounded">Sửa</th>
                                <th scope="col" class="rounded-q4">Xóa</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php 
						$i=0;     
						if(mysql_num_rows($listsp) > 0){                   
                          while($row = mysql_fetch_assoc($listsp))     {  
						  $i++;              
                        ?>	
                            <tr <?php if($i%2==0) echo "bgcolor='#CCC'" ; ?>>
                                <td><input type="checkbox" name="chon" idSP=<?php echo $row[sp_id]?>></td>                                 
                                <td align="left"><?php echo $row['ten_sp_vi']?> </td>    
                                <td><img src="<? if(strpos($row['hinh_dai_dien'],":")<=1) echo "../"; ?><?php echo $row['hinh_dai_dien']?>" alt="<?php echo $row['ten_sp_vi']?>" title="" border="0" width="100" height="100"></td>
                               
                                <td><a href="index.php?com=sp_edit&sp_id=<?php echo $row[sp_id]?>"><img src="img/icons/user_edit.png" alt="" title="" border="0"></a></td>
                                <td><img onclick="return confirm('Bạn có chắc chắn xóa ?');" class="linkxoa" sp_id=<?php echo $row[sp_id]?> src="img/icons/trash.png" alt="" title="" border="0"></td>
                            </tr>
                        <?php  } }else{?>
                        <tr><td colspan="6">Không có sản phẩm nào !</td></tr>
                        <?php } ?>
                        <tr>
                                <td colspan="6"><?php echo $lsp->phantrang($page,$page_show,$total_page,$link);?></td>
                            </tr>
                        
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
