<?php	
	require_once("../lib/class.db.php");
	$d = new db;
?>
<?php
	$idCL = $_POST['idCL'];  settype($idCL, "int");	
	$idSP = $_POST['idSP'];  settype($idSP, "int");	
	$layidLoai=mysql_query("select idLoai from sanpham where idSP=$idSP");
	$row_layidLoai=mysql_fetch_array($layidLoai);	
	$idLoai=$row_layidLoai['idLoai'];
	$sql = "SELECT idLoai, TenLoai FROM loaisp WHERE idCL=$idCL";
	$loaisp = mysql_query($sql) or die(mysql_error());

?>


<option value="0">Chọn loại</option>



<?php while ($row_loaisp = mysql_fetch_assoc($loaisp)) { ?>


	<option <? if($idLoai==$row_loaisp['idLoai']) echo "selected=selected";?> value="<?php echo $row_loaisp['idLoai'];?>">
    
	<?php echo $row_loaisp['TenLoai'];?> 
    
	</option>
    
    
    
<?php } ?>
