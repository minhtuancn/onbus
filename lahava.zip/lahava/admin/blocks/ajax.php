<?php 
require_once "../lib/class.db.php";
$d = new db;
$str = $d->processData($_POST[str]);
echo $d->changeTitle($str);
?>