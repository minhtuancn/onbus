<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").live('click',function(){			
			var flag = confirm("Bạn có chắc chắn xóa");
			if(flag == true){
				var chat_id = $(this).attr("chat_id");
				$.get('xoa.php',{loai:"chat",id:chat_id},function(data){
					window.location.reload();			
				});	
			}
		})         
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:80%">
		<h3>Quản lý chất liệu : Xem danh sách</h3>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
        <a href="index.php?com=chat_add"><input type="button" class="new" name="btnNew" value=""/></a><br />		
        <span>New</span>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div>
    	<fieldset>
        	<legend>++ Chất liệu ++</legend>
            	<div style="text-align: center">                     
                    <table id="rounded-corner" summary="2007 Major IT Companies&#39; Profit">
                        <thead>
                            <tr style="background-color:#03F;color:#FFF;height:30px">
                                <th scope="col" class="rounded-company"></th>       
                               
                                <th scope="col" class="rounded">Tên VI</th> 
                                <th scope="col" class="rounded">Tên EN</th>                                
                                <th scope="col" class="rounded">Sửa</th>
                                <th scope="col" class="rounded-q4">Xóa</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php 						
                        $chat = $chat->getListChatLieu();
                        while($row=mysql_fetch_assoc($chat)) {                 
                        $i++;
                        ?>	
                            <tr <?php if($i%2==0) echo "bgcolor='#CCC'" ; ?>>
                                <td><input type="checkbox" name="chon" chat_id=<?php echo $row[chat_id]?>></td>  
                                  
                                <td align="left"><?php echo $row[chat_vi]?></td>    
                               	<td align="left"><?php echo $row[chat_en]?></td>     
                                                         
                             
                               
                                <td><a href="index.php?com=chat_edit&amp;chat_id=<?php echo $row[chat_id]?>"><img src="img/icons/user_edit.png" alt="" title="" border="0"></a></td>
                                <td><img class="linkxoa" chat_id=<?php echo $row[chat_id]?> src="img/icons/trash.png" alt="" title="" border="0"></td>
      <?php } ?>
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
