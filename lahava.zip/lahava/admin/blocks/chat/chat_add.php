<?php 
if(isset($_POST[btnSumit])){	
	$thanhcong = $chat->Chat_Them($loi);	
	if($thanhcong==true){
		header("location:?com=chat_list");
	}
}
?>
<form action="" method="post" name="form_add_dm_tour">
<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý chất liệu : Thêm mới</h3>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div id="main_left">
    	<fieldset>
        	<legend>Thông tin chi tiết</legend>
            	<table>
                	<tr>
                   	  <td class="left">Tên - VI</td>
                        <td>
                            <input type="text" name="chat_vi" id="chat_vi" class="tf" />
                        	<span class="error"><?php echo $loi[chat_vi];?></span>                 
                        </td>                        
                    </tr>                    
                    <tr class="left">
                    	<td>Tên - EN</td>
                        <td><input type="text" name="chat_en" id="chat_en" class="tf" />
                        	<span class="error"><?php echo $loi[chat_en];?></span>
                        </td>                        
                    </tr>
                                      
                  
                    <tr>
                   	  <td class="left">&nbsp;</td>
                        <td>&nbsp;
                         
                        </td>                        
                    </tr>
                </table>
            
        </fieldset>
    </div>
	
  
    <div class="clr"></div>
</div>
</form>