<?php 
$link = "index.php?com=chungloai_list";
$limit = 10;
$page_show=5;
$danhmucs = $cl->ChungLoai_List(-1,-1,-1);
$total_record = mysql_num_rows($danhmucs);

$total_page = ceil($total_record/$limit);

if(isset($_GET[page])==false){
	$page = 1;
}
else{ 
	$page=$_GET[page];
	settype($page,"int");
}

$offset = $limit * ($page - 1);
$chungloai = $cl->ChungLoai_List(-1,$limit,$offset);

?>
<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").live('click',function(){			
			var flag = confirm("Bạn có chắc chắn xóa");
			if(flag == true){
				var idCL = $(this).attr("idCL");
				$.get('xoa.php',{loai:"chungloai",id:idCL},function(data){
					window.location.reload();			
				});	
			}
		})
         $(".tang").live('click',function(){
            var ThuTu = $(this).attr("ThuTu");			
            $.post('tang.php',{loai:'chungloai',ThuTu:ThuTu},function(data){
				window.location.reload();
            })
        })
		$(".giam").live('click',function(){
            var ThuTu = $(this).attr("ThuTu");
            $.post('giam.php',{loai:'chungloai',ThuTu : ThuTu},function(data){
				window.location.reload();
            })
        })
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:80%">
		<h3>Quản lý chủng loại : Xem danh sách</h3>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
        <a href="index.php?com=chungloai_add"><input type="button" class="new" name="btnNew" value=""/></a><br />		
        <span>New</span>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div>
    	<fieldset>
        	<legend>++ Chủng loại ++</legend>
            	<div style="text-align: center">                     
                    <table id="rounded-corners" summary="2007 Major IT Companies&#39; Profit">
                        <thead>
                        	<tr>
                                <td colspan="5"><?php echo $cl->phantrang($page,$page_show,$total_page,$link);?></td>
                            </tr>
                            <tr style="background-color:#03F;color:#FFF;height:30px">
                                <th scope="col" class="rounded-companys"></th>       
                               
                                <th scope="col" class="rounded">Tên chủng loại</th> 
                                <th scope="col" class="rounded">Thứ tự</th>
                                <th scope="col" class="rounded">Sửa</th>
                                <th scope="col" class="rounded-q4">Xóa</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php 
						$ThuTuMax = $cl->ThuTuMax('chungloai');
						$ThuTuMin = $cl->ThuTuMin('chungloai');      
						$i=0;                  
                        while($row=mysql_fetch_assoc($chungloai)) {                 
						$i++;
                        ?>	
                            <tr <?php if($i%2==0) echo "bgcolor='#CCC'" ; ?>>
                                <td><input type="checkbox" name="chon" idCL=<?php echo $row[idCL]?>></td>  
                                  
                                <td align="left"><?php echo $row[TenCL]?></td>    
                                    
                                                         
                               <td align="center">
								<?php if($row[ThuTu]>$ThuTuMin){?>
                               <img src="img/up.jpg" width="16" alt="" title="" border="0" 
                               class="tang" ThuTu="<?php echo $row[ThuTu]?>" >
                               <?php } ?>
                               <?php if($row[ThuTu]<$ThuTuMax){?>    
                                   <img src="img/down.png" width="20" alt="" title="" border="0"
                                   class="giam" ThuTu="<?php echo $row[ThuTu]?>">
                               <?php } ?> 
                               </td>  
                               
                                <td><a href="index.php?com=chungloai_edit&amp;idCL=<?php echo $row[idCL]?>"><img src="../img/icons/user_edit.png" alt="" title="" border="0"></a></td>
                                <td>
                                	<img class="linkxoa" idCL=<?php echo $row[idCL]?> src="../img/icons/trash.png" alt="" title="" border="0">
                                </td>
      <?php } ?>
      						<tr>
                                <td colspan="5"><?php echo $cl->phantrang($page,$page_show,$total_page,$link);?></td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
