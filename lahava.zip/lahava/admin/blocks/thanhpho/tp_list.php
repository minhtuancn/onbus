<script type="text/javascript">
	$(document).ready(function(){		
		$(".linkxoa").live('click',function(){			
			var flag = confirm("Bạn có chắc chắn xóa");
			if(flag == true){
				var idTP = $(this).attr("idTP");
				$.get('xoa.php',{loai:"thanhpho",id:idTP},function(data){
					window.location.reload();			
				});	
			}
		})
         $(".tang").live('click',function(){
            var ThuTu = $(this).attr("ThuTu");			
            $.post('tang.php',{loai:'thanhpho',ThuTu:ThuTu},function(data){
				window.location.reload();
            })
        })
		$(".giam").live('click',function(){
            var ThuTu = $(this).attr("ThuTu");
            $.post('giam.php',{loai:'thanhpho',ThuTu : ThuTu},function(data){
				window.location.reload();
            })
        })
	})
</script>

<div id="admin_navigation">
	<div style="float:left;width:80%">
		<h3>Quản lý thành phố : Xem danh sách</h3>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
        <a href="index.php?com=tp_add"><input type="button" class="new" name="btnNew" value=""/></a><br />		
        <span>New</span>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div>
    	<fieldset>
        	<legend>++ Thành phố ++</legend>
            	<div style="text-align: center">                     
                    <table id="rounded-corner" summary="2007 Major IT Companies&#39; Profit">
                        <thead>
                            <tr>
                                <th scope="col" class="rounded-company"></th>       
                               
                                <th scope="col" class="rounded" align="left">Tên TP</th> 
                                <th scope="col" class="rounded">Thứ tự</th>
                                <th scope="col" class="rounded">Sửa</th>
                                <th scope="col" class="rounded-q4">Xóa</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php 
						$ThuTuMax = $tp->ThuTuMax('thanhpho');
						$ThuTuMin = $tp->ThuTuMin('thanhpho');
                        $chungloai = $tp->ThanhPho_List();
                        while($row=mysql_fetch_assoc($chungloai)) {                 
                        ?>	
                            <tr>
                                <td><input type="checkbox" name="chon" idTP=<?php echo $row[idTP]?>></td>  
                                  
                                <td align="left"><?php echo $row[TenTP]?></td>    
                                    
                                                         
                               <td align="center">
								<?php if($row[ThuTu]>$ThuTuMin){?>
                               <img src="img/up.jpg" width="16" alt="" title="" border="0" 
                               class="tang" ThuTu="<?php echo $row[ThuTu]?>" >
                               <?php } ?>
                               <?php if($row[ThuTu]<$ThuTuMax){?>    
                                   <img src="img/down.png" width="20" alt="" title="" border="0"
                                   class="giam" ThuTu="<?php echo $row[ThuTu]?>">
                               <?php } ?> 
                               </td>  
                               
                                <td><a href="index.php?com=tp_edit&amp;idTP=<?php echo $row[idTP]?>"><img src="../img/icons/user_edit.png" alt="" title="" border="0"></a></td>
                                <td>
                                	<img class="linkxoa" idTP=<?php echo $row[idTP]?> src="../img/icons/trash.png" alt="" title="" border="0">
                                </td>
      <?php } ?>
                        </tbody>
                    </table>
                    </div>
        </fieldset>
    </div>

   
    <div class="clr"></div>
</div>
