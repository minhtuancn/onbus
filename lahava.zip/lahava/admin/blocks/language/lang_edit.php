<?php
$id= $_GET['id'];
settype($id,"int");
$chitiet = $mau->Lang_ChiTiet($id);
$row = mysql_fetch_assoc($chitiet);

if(isset($_POST['btnSumit'])){
	$thanhcong = $mau->Lang_Sua($id,$loi);	
	if($thanhcong==true){
		header("location:?com=lang_list");
	}
}
?>
<script type="text/javascript">

	$(document).ready(function(){
		$("input[name=TieuDe]").blur(function(){
			var TieuDeKS= $(this).val();
			$.post("blocks/ajax.php",{str:TieuDeKS},function(data){				
				$("input[name=TieuDe_KD]").val(data);
			})
		})
       
		
	})
</script>
<form action="" method="post" name="form_add_dm_ks">
<div id="admin_navigation">
	<div style="float:left;width:90%">
		<h3>Quản lý ngôn ngữ : cập nhật</h3>
    </div>
	<div style="float:left;width:5%;padding-top:5px">
    	<input type="submit" class="save" name="btnSumit" value=""/><br />		
        <span>Save</span>
    </div>
    <div style="float:left;width:5%;padding-top:5px">
    	<input type="reset" class="cancel" name="btnCancel" value=""/><br />		
        <span>Reset</span>
    </div>
    <div class="clr"></div>
</div>
<div id="main_admin">
	
	<div id="main_left">
    	<fieldset>
        	<legend>Thông tin chính</legend>
            	<table>
                    <tr class="left">
                    	<td>Tên KD</td>
                        <td><?php echo $row['name'];?>
                        </td>                        
                    </tr>
                    <tr class="left">
                    	<td>Tiêu đề VI</td>
                        <td><input type="text" name="ten_vi" id="ten_vi" class="tf" value="<?php echo $row['vi']?>" />
                        </td>                        
                    </tr>
                    <tr class="left">
                    	<td>Tiêu đề EN</td>
                        <td><input type="text" name="ten_en" id="ten_en" class="tf" value="<?php echo $row['en']?>"/></td>                        
                    </tr>
                  
                </table>
            
        </fieldset>
    </div>	
   
    <div class="clr"></div>
</div>
</form>