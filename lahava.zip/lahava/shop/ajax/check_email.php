<?php 
require_once("../../admin/lib/class.db.php");
$d = new db;
$email = $d->processData($_POST['email']);
echo  $d ->checkEmail($email);
?>