<?php 
require_once('../../admin/lib/class.db.php'); 
$d = new db;
$arrReturn = array();
session_start();
if (isset($_SESSION['daySoLuong'])==false) $_SESSION['daySoLuong']=array();
if (isset($_SESSION['dayMaSP'])==false) $_SESSION['dayMaSP']=array();
if (isset($_SESSION['daySize'])==false) $_SESSION['daySize']=array();
if (isset($_SESSION['dayMau'])==false) $_SESSION['dayMau']=array();
if (isset($_SESSION['dayDonGia'])==false) $_SESSION['dayDonGia']=array();
if (isset($_SESSION['dayUrlHinh'])==false) $_SESSION['dayUrlHinh']=array();


$action = $_POST['action'];
$idSP = "-1";
if (isset($_POST['sp_id'])) $idSP =  (int) $_POST['sp_id'];
$soluong =(isset($_POST['soluong'])==true)? (int) $_POST['soluong']:1;

if ($soluong>100) $soluong=100;
$act=array("update", "add","remove","removeAll");
if (in_array($action , $act)==false) exit();	
//
if ($action=="add") {
    $sql ="SELECT * FROM sanpham WHERE sp_id=$idSP";
    $sanpham = mysql_query($sql) or die (mysql_error());	
    $row_sanpham = mysql_fetch_assoc($sanpham);		

    $_SESSION['daySoLuong'][$idSP] += $soluong;
    $_SESSION['dayMaSP'][$idSP] = $row_sanpham['ma_sp']; 
	$_SESSION['dayDonGia'][$idSP]=$row_sanpham['gia']-($row_sanpham['khuyen_mai']*$row_sanpham['gia'])/100;
	$_SESSION['dayUrlHinh'][$idSP]=$row_sanpham['hinh_dai_dien'];
	$url = str_replace("../","",$row_sanpham['hinh_dai_dien']);
	$_SESSION['dayHinh'][$idSP] = "http://lahava.vn/".$url;
	$_SESSION['dayMau'][$idSP]=$_POST['mau_id'];
	$_SESSION['daySize'][$idSP]=$_POST['size'];	
	
	$_SESSION['tien_sp'][$idSP] = $_SESSION['daySoLuong'][$idSP] * $_SESSION['dayDonGia'][$idSP];
	
}
if ($action=="remove") {
    unset($_SESSION['daySoLuong'][$idSP]);
	unset($_SESSION['dayMaSP'][$idSP]);
	unset($_SESSION['dayDonGia'][$idSP]);
	unset($_SESSION['dayUrlHinh'][$idSP]);
	unset($_SESSION['dayMau'][$idSP]);
	unset($_SESSION['daySize'][$idSP]);		
	unset($_SESSION['tien_sp'][$idSP]);
}
if ($action=="update") {
    $sql="SELECT * FROM sanpham WHERE sp_id=$idSP";
    $sanpham=mysql_query($sql) or die (mysql_error());
    $row_sanpham=mysql_fetch_assoc($sanpham);
	if($soluong>0){
		$_SESSION['dayDonGia'][$idSP]=$row_sanpham['gia']-($row_sanpham['khuyen_mai']*$row_sanpham['gia'])/100;
		$_SESSION['daySoLuong'][$idSP] = $soluong;	
		$_SESSION['dayMaSP'][$idSP] = $row_sanpham['dayMaSP'];	
		$_SESSION['dayUrlHinh'][$idSP] = $row_sanpham['hinh_dai_dien'];
		$arrReturn['tien_sp']=$_SESSION['tien_sp'][$idSP] =  $_SESSION['daySoLuong'][$idSP] * $_SESSION['dayDonGia'][$idSP];
	}
	if($soluong==0){
		unset($_SESSION['daySoLuong'][$idSP]);
		unset($_SESSION['dayMaSP'][$idSP]);
		unset($_SESSION['dayDonGia'][$idSP]);
		unset($_SESSION['dayUrlHinh'][$idSP]);
		unset($_SESSION['dayMau'][$idSP]);
		unset($_SESSION['daySize'][$idSP]);		
		unset($_SESSION['tien_sp'][$idSP]); 			
	}
}
	// tinh tong so luong + tong tien
	$sosp = count( $_SESSION['daySoLuong'] );
	reset( $_SESSION['daySoLuong'] );  
	reset( $_SESSION['dayDonGia'] );	
	$tongtien = $tongsoluong = 0;
	for ($i = 0; $i<$sosp ; $i++) {
		$idSP = key( $_SESSION['daySoLuong'] );				
		$soluong_t = current( $_SESSION['daySoLuong'] );
		$dongia_t = current( $_SESSION['dayDonGia'] );		
		$tien_t = $dongia_t*$soluong_t; 
		$tongtien += $tien_t;  
		$tongsoluong += $soluong_t;
		next( $_SESSION['daySoLuong'] );  
		next( $_SESSION['dayDonGia'] );	
	}
	
	$arrReturn['tong_so_sp'] = $tongsoluong ." sp";
	$_SESSION['tong_so_sp'] = $tongsoluong;
	$_SESSION['tong_tien'] = $tongtien;
	$arrReturn['tong_tien']  = $tongtien;

	echo json_encode($arrReturn); 
	
?>
