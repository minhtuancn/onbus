<?php
require_once('../../admin/lib/class.db.php'); 
$d = new db;
$idMenu = (int) $_POST['idMenu'];
$rs = mysql_query("SELECT * FROM menu WHERE idMenu = $idMenu");
$row = mysql_fetch_assoc($rs);
echo json_encode($row);
?>