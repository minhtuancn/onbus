<?php 
session_start();
require_once  "../../admin/lib/class.db.php";
$d = new db;
if(isset($_SESSION['idUser'])){
	$idUser = $_SESSION['idUser'];
	$sp_id = (int) $_POST['sp_id'];
	if($sp_id > 0){
		$sql = "SELECT sp_id FROM sp_luu WHERE sp_id = $sp_id AND idUser = $idUser";
		$rs = mysql_query($sql);
		if(mysql_num_rows($rs)==0){
			$sql = "INSERT INTO sp_luu VALUES($idUser,$sp_id)";
			mysql_query($sql) or die(mysql_error());	
			echo "Lưu thành công !";
		}else{
			echo "Bạn đã lưu sản phẩm này trước đó !";
		}
	}
}
?>