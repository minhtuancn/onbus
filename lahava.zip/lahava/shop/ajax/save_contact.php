<?php 
session_start();
require_once('../../admin/lib/class.db.php'); 
$d = new db;

$ho_ten = $d->processData($_POST['ho_ten']);
$noi_dung = $d->processData($_POST['noi_dung']);
$dien_thoai = $d->processData($_POST['dien_thoai']);
$dia_chi = '';
$email = $d->processData($_POST['email']);

if($d->checkEmailExist($email)==false){
	$d -> insertCustomer($email,$dien_thoai,$dia_chi,$ho_ten);
}
if($ho_ten !='' && $ho_ten !='' && $noi_dung !='' && $dien_thoai !='' && $email !='' ){
	
	/* goi mail */
	$tieudethu="LAHAVA.VN:: Khách hàng gởi liên hệ";
	$noidungthu = '
	<table width="700" border="1" cellspacing="0" cellpadding="4">
	  <tr>
		<td width="20%">Họ tên </td>
		<td>'.$ho_ten.'</td>
	  </tr>
	  <tr>
		<td>Email</td>
		<td>'.$email.'</td>
	  </tr>
	  <tr>
		<td>Điện thoại</td>
		<td>'.$dien_thoai.'</td>
	  </tr>
	  <tr>
		<td>Nội dung</td>
		<td>'.$noi_dung.'</td>
	  </tr>
	</table>';			          
	
	$d->smtpmailer('webphp_hoangnguyen@yahoo.com.vn', 'lahavafashion2013@gmail.com', 'Thời trang LAHAVA',$tieudethu,$noidungthu);	
	

}
?>