<?php
	session_start();
	ob_start();
	require_once  "../admin/lib/class.db.php";
	$d = new db;
	$thongbao="";
	if(isset($_POST['dangnhap']))
	{
		$username=$_POST['username'];
		$password=md5($_POST['password']);
		$user=mysql_query("select * from users where Email='$username' and password='$password' and Active=1");
		if(mysql_num_rows($user)==1)
		{
			 if (isset($_POST['nho'])== true){
		     setcookie("un", $_POST['username'], time() + 60*60*24*7 );
			 setcookie("pw", $_POST['password'], time() + 60*60*24*7 );
		 } else {
			 setcookie("un", $_POST['username'], time() -1);
			 setcookie("pw", $_POST['password'], time() -1);
		 } 
			$row_user=mysql_fetch_array($user);
			$_SESSION['GioiTinh']=$row_user['GioiTinh'];
			$_SESSION['Username']=$row_user['Username'];
			$_SESSION['idUser']=$row_user['idUser'];
			$_SESSION['HoTen']=$row_user['HoTen'];			
		}
		else
		{
			$thongbao="Đăng nhập không thành công !";	
		}
	}
	echo $thongbao;
?>