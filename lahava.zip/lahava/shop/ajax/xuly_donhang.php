<?php 
session_start();
require_once('../../admin/lib/class.db.php'); 
$d = new db;

$ho_ten = $d->processData($_POST['ho_ten']);
$dia_chi = $d->processData($_POST['dia_chi']);
$dien_thoai = $d->processData($_POST['dien_thoai']);
$email = $d->processData($_POST['email']);

if($d->checkEmailExist($email)==false){
	$d -> insertCustomer($email,$dien_thoai,$dia_chi,$ho_ten);
	$idKH = mysql_insert_id();
	$idDH = $d->insertDonHang($idKH);	
}else{
	$idKH = $d->getIDKH($email);
	$d->updateInfoCustomer($idKH,$email);
	$idDH = $d->insertDonHang($idKH);
}

if($idDH){
	while( key($_SESSION['daySoLuong'])!= null){
		$idSP=key($_SESSION['daySoLuong']);	
		$soluong=current($_SESSION['daySoLuong']);
		$size=current($_SESSION['daySize']);
		$mau_id=current($_SESSION['dayMau']);
		$tiensp = $_SESSION['tien_sp'][$idSP];				
						
		$d->insertDonHangChiTiet($idDH,$idSP,$soluong,$tiensp,$mau_id,$size);		
	
		
		next($_SESSION['daySoLuong']);
		next($_SESSION['dayMau']);			
		next($_SESSION['daySize']);					
	}
	/* goi mail */
	$tieudethu="LAHAVA.VN:: Thông tin đơn hàng";
	$noidungthu = '<table align="center" bgcolor="#f6f6f6" border="0" cellpadding="0" cellspacing="0">
            <tbody>
              <tr>
                <td width="750"><table align="center" width="100%">
                  <tbody>
                    <tr>
                      <td bgcolor="#4c4847" style="color:#FFF;padding:10px;" width="100%">Để đảm bảo thư từ chúng tôi được gửi đến hộp thư của quý khách, xin vui lòng thêm <a href="mailto:customer@lahava.vn" target="_blank" style="color:orange">customer@lahava.vn</a> vào danh sách liên lạc.</td>
                    </tr>
                    <tr>
                      <td width="100%"></td>
                    </tr>
                    <tr>
                      <td><table width="100%">
                        <tbody>
                          <tr>
                            <td><h1>Xác nhận đơn đặt hàng thành công!</h1>
                              <p> Xin chào '.$ho_ten.',<br />
                                <br />
                                Cảm ơn quý khách đã mua   hàng ở LAHAVA. Mã số xác nhận đơn hàng của quý khách là: </p>
                              <p><strong>2000'.$idDH.'.</strong> <br />
                                <br />
                              </p>
                              <table cellpadding="7" cellspacing="0" width="100%" border="1">
                                <thead>
                                  <tr style="background-color:#00BFFF;color:#FFF;font-weight:bold;height:40px">
                                    <th align="left">Sản phẩm</th>
                                    <th align="left">Mã sản phẩm</th>
                                    <th>Màu sắc</th>
                                    <th>Size</th>
                                    <th>Số lượng</th>
                                    <th align="right">Tổng cộng</th>
                                  </tr>
                                </thead>
                                <tbody>';
  
   	reset( $_SESSION['daySoLuong'] );  
	reset( $_SESSION['dayMaSP'] );	
	reset( $_SESSION['dayDonGia'] );  
	reset( $_SESSION['dayUrlHinh'] );
	reset( $_SESSION['dayHinh'] );  
	reset( $_SESSION['daySize'] );  
	reset( $_SESSION['dayMau'] );
	
	if (isset($_SESSION['daySoLuong']))
	 while( key($_SESSION['daySoLuong'])!= null){
		$idSP=key($_SESSION['daySoLuong']);
		$tensp = $d->getNameProduct($idSP);
		$mota=current($_SESSION['dayMaSP']);
		$soluong=current($_SESSION['daySoLuong']);
		$dongia=current($_SESSION['dayDonGia']);
		$urlhinh=current($_SESSION['dayUrlHinh']);
		$size=current($_SESSION['daySize']);
		$mau_id=current($_SESSION['dayMau']);
		$mau = $d->getNameColor($mau_id);
		
		if($soluong>0){		
$noidungthu.='<tr>
    <td align="left">'.$tensp.'</td>
    <td align="left">'.strtoupper($mota).'</td>
    <td align="center">'.$mau.'</td>
    <td align="center">'.$size.'</td>
    <td align="center">'.$soluong.'</td>
    <td  align="right">'.number_format($_SESSION['tien_sp'][$idSP]).'</td>
  </tr>';
 } 
	next($_SESSION['daySoLuong']);
	next($_SESSION['dayDonGia']);
	next($_SESSION['dayMaSP']);	
	next($_SESSION['dayUrlHinh']);
	next($_SESSION['dayHinh']);	
	next($_SESSION['dayMau']);			
	next($_SESSION['daySize']);					
 } 
$noidungthu.='<tr style="height:60px">
    <td colspan="5" align="right" style="font-weight:bold">TỔNG TIỀN</td>   
    <td  style="font-weight:bold;text-align:right">'.number_format($_SESSION['tong_tien']).'</td>
  </tr>
 </table>
                              <br /><br />
                              <p><strong>PHƯƠNG THỨC THANH TOÁN</strong></p><br />
                              <p><strong>+ Trực tiếp tại cửa hàng</strong><br />
                                Khách hàng vui lòng đến trực tiếp tại cửa hàng của chúng tôi tại địa chỉ 113 Trần Huy Liệu, Phường 12, Quận Phú nhuận, TPHCM<br />
                                Giờ làm việc: 9:00 - 21:00 (kể cả ngày lễ và chủ nhật)<br />
                                <br />
                                <strong>+ Chuyển khoản ngân hàng</strong><br />
                                Khách hàng vui lòng chọn một trong các ngân hàng sau để thanh toán:</p>
                              <p>Số tiền của quý khách phải thanh toán là<strong> '.number_format($_SESSION['tong_tien']).'</strong> VND </p><br /><br />
                              <p>Ngân hàng: <strong>VietcomBank</strong> <br />
                                Số tài khoản: 007 100 4634 717<br />
                                Chủ tài khoản: Nguyễn Lan Anh<br />
                                PGD Quang Trung - Chi nhánh TP.HCM</p><br />
                              <p>Ngân hàng: <strong>VietinBank</strong><br />
                                Số tài khoản: 711A 211 33 234<br />
                                Chủ tài khoản: Nguyễn Lan Anh<br />
                                Chi nhánh 1, TP.HCM</p><br />
                              <p>Ngân hàng: <strong>Agribank</strong><br />
                                Số tài khoản: 6320 2050 12847<br />
                                Chủ tài khoản: Nguyễn Lan Anh<br />
                                Chi nhánh Tây Sài Gòn, TP.HCM<br />
                              </p><br />
                              <p>Ngân hàng: <strong>DongABank</strong><br />
                                Số tài khoản: 010 333 5115<br />
                                Chủ tài khoản: Nguyễn Lan Anh<br />
                                Chi nhánh Quang Trung - Gò vấp - TP.HCM<br />
                              </p><br />
                              <p>Ngân hàng: <strong>ACB</strong><br />
                                Số tài khoản: 4214 9456 0025 7646<br />
                                Chủ tài khoản: Nguyễn Lan Anh<br />
                                PGD Lê Văn Khương, Quận 12, TP.HCM</p><br />
                              <p>Ngân hàng: <strong>SacomBank</strong><br />
                                Số tài khoản: 0600 5762 6499<br />
                                Chủ tài khoản: Nguyễn Lan Anh<br />
                                Chi nhánh Hóc Môn, TP.HCM<br />
                              </p><br />
                              <p>Lưu ý!<br />
                                Xin quý khách vui lòng ghi rõ <strong>Tên người mua hàng</strong> kèm theo <strong>mã số xác nhận đơn hàng</strong> khi chuyển khoản để chúng tôi có thể xác thực việc thanh toán. Sản phẩm   của quý khách sẽ không được chuyển nếu việc thanh toán chưa hoàn tất.   Nếu chúng tôi không nhận được thanh toán trong vòng 48 giờ thì đơn hàng   sẽ bị hủy.</p><br />
                              <p>Hãy liên hệ với bộ phận Chăm Sóc Khách Hàng của chúng tôi qua email <a href="mailto:customer@lahava.vn" target="_blank">customer@lahava.vn</a> hoặc Hotline 0975.993.678 để được giúp đỡ thêm.</p><br />
                              <p><br />
                              </p>
                              <p>Trân trọng,<br />
                                Ban quản trị LAHAVA</p></td>
                          </tr>
                        </tbody>
                      </table></td>
                    </tr>
                    <tr>
                      <td width="100%"><table align="center">
                        <tbody>
                          <tr>
                            <td align="center"><a href="http://www.facebook.com/lahava.vn" target="_blank"><img alt="" />Like us on Facebook</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://#" target="_blank"><img alt="" />Follow us on Twitter</a><img alt="" /></td>
                          </tr>
                          <tr>
                            <td align="center">© 2013 LAHAVA</td>
                          </tr>
                          <tr>
                            <td align="center">Số 113 đường Trần Huy Liệu, Phường 12, Quận Phú nhuận <br />
                              TP. Hồ Chí Minh, Việt Nam | Hotline: 0975.997.567</td>
                          </tr>
                        </tbody>
                      </table></td>
                    </tr>
                  </tbody>
                </table></td>
              </tr>
            </tbody>
          </table> 
';			          
	
	$d->smtpmailer($email, 'lahavafashion2013@gmail.com', 'Thời trang LAHAVA',$tieudethu,$noidungthu);	
	
	session_destroy();
}
?>