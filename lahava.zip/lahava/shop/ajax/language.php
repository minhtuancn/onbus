<?php 
session_start();
$arrLang = array('en','vi');
if(in_array($_POST['lang'],$arrLang)){
	$_SESSION['lang']=$_POST['lang'];
	setcookie("lang", $_POST['lang'], time()+3600);
}else{
	$_SESSION['lang']='vi';
	setcookie("lang", 'vi', time()+3600);
}
?>