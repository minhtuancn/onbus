<?php 
ob_start();
session_start();
require_once "../admin/lib/class.trangchu.php";
require_once("blocks/seo.php");
$tc = new trangchu;
define ('USD',21000);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title; ?></title>  
<meta name="description" content="<?php echo $metaD ;?>" />
<meta name="keywords" content="<?php echo $metaK ;?>" />
<base href="http://<?php echo $_SERVER['SERVER_NAME'];?>/shop/" />
<link rel="icon" type="image/vnd.microsoft.icon" href="http://www.lahava.vn/images/favicon.ico" />
<link rel="shortcut icon" type="image/x-icon" href="http://www.lahava.vn/images/favicon.ico" />
<link href="css/home.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/style_menu.css" type="text/css" media="screen">
<link href="css/home.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.9.1.custom.js"></script>
<script type="text/javascript" src="js/cookie.js"></script>
<script type="text/javascript" src="js/form.js"></script>
<script type="text/javascript" src="js/jquery.ui.core.js"></script>
<script type="text/javascript" src="js/jquery.ui.slider.js"></script>
<script type="text/javascript" src="js/lazy.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.slider.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.all.css"/>
<script type="text/javascript" src="js/function.js"></script>
<script type="text/javascript" src="js/javascriptlahava.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    var s = $("#leftmenu");
    var pos = s.position();                    
    $(window).scroll(function() {
        var windowpos = $(window).scrollTop();
        if (windowpos >= pos.top) {
            s.addClass("stick");
        } else {
            s.removeClass("stick"); 
        }
    });
});
</script>
<script type="text/javascript">
$(function() {
	$(window).scroll(function() {
		if($(this).scrollTop() != 0) {
			$('#toTop').fadeIn();	
		} else {
			$('#toTop').fadeOut();
		}
	});
 
	$('#toTop').click(function() {
		$('body,html').animate({scrollTop:0},800);
	});	
});
</script>
<script>
jQuery(function($) {
    function fixDiv() {
      var $cache = $('#profilter'); 
      if ($(window).scrollTop() > 100) 
        $cache.css({'position': 'fixed', 'left': '343px', 'z-index': '999','height':'45px','padding-top':'10px','width':'817px'}); 
      else
        $cache.css({'position': 'relative', 'top': '-8px', 'left': '-5px',});
    }
    $(window).scroll(fixDiv);
    fixDiv();
});
</script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-18743263-14']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>
<body>
<div id="toTop">^ Top</div>
<div id="container">
	<div id="header">
    <div id="logo"><a href="http://lahava.vn/shop" title="Home L A H A V A"><img src="images/lahava-san.png" width="284" height="50" border="0" /></a></div>
  </div>
  <?php include "blocks/layout/header.php";?>
  
  		<?php
		switch($mod){
			case "loaisp" : include "blocks/page/cat.php";break;
			case "detail" : include "blocks/page/detail.php";break;
			case "sp_luu" : include "blocks/page/sp_luu.php";break;
			case "gio-hang" : include "blocks/page/cart.php";break;
			case "tag" : include "blocks/page/tag.php";break;
			default        : include "blocks/layout/trangchu.php";break;
		}
		?>
  
</div>
 <div id="che"></div>
</body>
</html>