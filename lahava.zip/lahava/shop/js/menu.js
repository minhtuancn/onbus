jQuery(window).load(function() {
	var loai_id = $.cookie('loai_id');
	if(loai_id > 0) loai_id = loai_id ; else loai_id = 0;
    $("#nav > li > a").click(function () { // binding onclick
        if ($(this).parent().hasClass('selected')) {
			$(this).parent().find('.icon_up_down').attr('src','images/arrow_down.png');
            $("#nav .selected div div").slideUp(100); // hiding popups
            $("#nav .selected").removeClass("selected");
        } else {
			$(this).parent().find('.icon_up_down').attr('src','images/arrow_down.png');
            $("#nav .selected div div").slideUp(100); // hiding popups
            $("#nav .selected").removeClass("selected");

            if ($(this).next(".subs").length) {
				$(this).parent().find('.icon_up_down').attr('src','images/arrow_up.png');
                $(this).parent().addClass("selected"); // display popup
                $(this).next(".subs").children().slideDown(200);
				$("#slider-vertical").show();
            }
        }
    }); 
	$('li.check_kieu').click(function(){
		if($(this).hasClass('check_kieu_off')){
			$(this).removeClass('check_kieu_off').addClass('check_kieu_on');
		}else{
			$(this).removeClass('check_kieu_on').addClass('check_kieu_off');
		}
		
		var strKieuId = "";
		var strChatId = "";
		var strMauId = "";
		var gia = $("#rating-result").html();
		gia = gia.replace(",","");
		gia = gia.replace(",","");					
		$('li.check_kieu_on').each(function() {				
			
				strKieuId += $(this).attr('kieu_id') + ",";
			
		});				
		$('li.check_mau_on').each(function() {			
			
				strMauId += $(this).attr('mau_id') + ",";
			
		});		
		$('li.check_chat_on').each(function() {			
			
				strChatId += $(this).attr('chat_id') + ",";
			
		});	
		$.post('blocks/search.php',{mau:strMauId,kieu:strKieuId,chat:strChatId,gia:gia,loai_id:loai_id},function(data){
			$('#mainpage').html(data).stop(true, true).fadeOut(500).fadeIn(1000);
		});			
	});
	$('li.check_chat').click(function(){
		if($(this).hasClass('check_chat_off')){
			$(this).removeClass('check_chat_off').addClass('check_chat_on');
		}else{
			$(this).removeClass('check_chat_on').addClass('check_chat_off');
		}
		
		var strKieuId = "";
		var strChatId = "";
		var strMauId = "";
		var gia = $("#rating-result").html();
		gia = gia.replace(",","");
		gia = gia.replace(",","");					
		$('li.check_kieu_on').each(function() {				
			
				strKieuId += $(this).attr('kieu_id') + ",";
			
		});				
		$('li.check_mau_on').each(function() {			
			
				strMauId += $(this).attr('mau_id') + ",";
			
		});		
		$('li.check_chat_on').each(function() {			
			
				strChatId += $(this).attr('chat_id') + ",";
			
		});	
		$.post('blocks/search.php',{mau:strMauId,kieu:strKieuId,chat:strChatId,gia:gia,loai_id:loai_id},function(data){
			$('#mainpage').html(data).stop(true, true).fadeOut(500).fadeIn(1000);
		});			
	});
	$('li.check_mau').click(function(){	
		if($(this).hasClass('check_mau_off')){
			$(this).removeClass('check_mau_off').addClass('check_mau_on');
		}else{
			$(this).removeClass('check_mau_on').addClass('check_mau_off');
		}
			var gia = $("#rating-result" ).html();
			gia = gia.replace(",","");	
			gia = gia.replace(",","");		
			var strMauId = "";	
			var strKieuId = "";	
			var strChatId = "";
			$('li.check_kieu_on').each(function() {				
				
					strKieuId += $(this).attr('kieu_id') + ",";
				
			});				
			$('li.check_mau_on').each(function() {			
				
					strMauId += $(this).attr('mau_id') + ",";
				
			});		
			$('li.check_chat_on').each(function() {			
			
				strChatId += $(this).attr('chat_id') + ",";
			
		});	
			$.post('blocks/search.php',{mau:strMauId,kieu:strKieuId,chat:strChatId,gia:gia,loai_id:loai_id},function(data){
				$('#mainpage').html(data).stop(true, true).fadeOut(500).fadeIn(1000);
			});
										
	});

});
$(function() {
	var loai_id = $.cookie('loai_id');
	if(loai_id > 0) loai_id = loai_id ; else loai_id = 0;
	$( "#slider-vertical" ).slider({
		orientation: "vertical",
		range: "max",
		min: 100000,
		max:3000000,			
		value: 1600000,
		step:200000,
		slide: function( event, ui ) {	
			if(ui.value==3000000){
				$("#rating-result" ).html('MAX');
			}else{
				$("#rating-result" ).html( addcommas(ui.value ));
			}
			var gia = ui.value;
			
			var strMauId = "";	
			var strKieuId = "";	
			var strChatId = "";
			$('li.check_kieu_on').each(function() {				
			
					strKieuId += $(this).attr('kieu_id') + ",";
				
			});				
			$('li.check_mau_on').each(function() {			
				
					strMauId += $(this).attr('mau_id') + ",";
				
			});		
			$('li.check_chat_on').each(function() {			
			
				strChatId += $(this).attr('chat_id') + ",";
			
		});	
			$.post('blocks/search.php',{mau:strMauId,kieu:strKieuId,chat:strChatId,gia:gia,loai_id:loai_id},function(data){
				$('#mainpage').html(data).stop(true, true).fadeOut(500).fadeIn(1000);
			});
		}
	});
	$("#rating-result" ).html(addcommas(1600000));
});