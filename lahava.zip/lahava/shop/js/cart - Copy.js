$(function() {
	var lang = $.cookie('lang');
	$('.nut_cong').click(function(){
		var idSP = $(this).attr('idSP');
		var soluong =  $(this).attr('soluong');
		if(parseInt(soluong)<11){
			$.post('ajax/process_cart.php',{sp_id:idSP,update:'update',soluong:soluong,action:'update'},function(data){		
				var arrRes = JSON.parse(data);		
				$('#tien_'+ idSP).html(addcommas(arrRes.tien_sp));
				$('#total_price').html(addcommas(arrRes.tong_tien));	
				$('#so_sp_gio_hang').html(arrRes.tong_so_sp);
				$('#soluong_' + idSP).html(soluong);				
				$('img.nut_cong[idSP=' + idSP + ']').attr('soluong',parseInt(soluong) + 1);
				$('img.nut_tru[idSP=' + idSP + ']').attr('soluong',parseInt(soluong) - 1);
				if(arrRes.tong_tien==0) $('#thanh_toan').hide();				
			});
		}
	});
	$('.nut_tru').click(function(){
		var idSP = $(this).attr('idSP');
		var soluong =  $(this).attr('soluong');
		if(parseInt(soluong)>-1){
			$.post('ajax/process_cart.php',{sp_id:idSP,update:'update',soluong:soluong,action:'update'},function(data){					
				var arrRes = JSON.parse(data);		
				$('#tien_'+ idSP).html(addcommas(arrRes.tien_sp));
				$('#total_price').html(addcommas(arrRes.tong_tien));	
				$('#so_sp_gio_hang').html(arrRes.tong_so_sp);
				if(soluong==0){
					$('tr#dong_'+ idSP).hide();
				}else{
					$('#soluong_' + idSP).html(soluong);				
					$('img.nut_cong[idSP=' + idSP + ']').attr('soluong',parseInt(soluong) + 1);
					$('img.nut_tru[idSP=' + idSP + ']').attr('soluong',parseInt(soluong) - 1);	
				}						
				if(arrRes.tong_tien==0) $('#thanh_toan').fadeOut(1000);					
			});
		}
	});
	$('img.xoa_sp').click(function(){
		var idSP = $(this).attr('idSP');		
		
		$.post('ajax/process_cart.php',{sp_id:idSP,action:'remove'},function(data){					
			var arrRes = JSON.parse(data);		
			$('#tien_'+ idSP).html(addcommas(arrRes.tien_sp));
			$('#total_price').html(addcommas(arrRes.tong_tien));	
			$('#so_sp_gio_hang').html(arrRes.tong_so_sp);				
			$('tr#dong_'+ idSP).hide();									
			if(arrRes.tong_tien==0) $('#thanh_toan').fadeOut(1000);					
		});
		
	});
	$("#thanh_toan").click(function(){       
        $.post('blocks/page/thanhtoan_' + lang + '.php',null,function(data){            
            $('#pupPanel').html(data).fadeIn(1000);            
        });
		$("#che").fadeIn(500);
		$("#che").fadeTo(0,0.8);				
		var top = ($(window).height()-490)/2 - 25;
		var width = ($(window).width()-600);
		var left = ($(window).width() - width)/2 - 25;
		$("#pupPanel").css({'top':top + 'px','left' :left + "px" ,"width" : width + "px"});
		$("#pupPanel").fadeIn(1000);	
		return false;	
	});
});