$(function(){
	var link_cart = '';
	var lang = $.cookie('lang');
	if(lang == 'vi') {
		link_cart = "gio-hang";		
	}else{
		link_cart = "shopping-cart";	
	}		 
	$("#res_email").click(function(){       
		$.post('blocks/page/res_email_'+lang+'.php',null,function(data){            
			$('#pupPanel').html(data).fadeIn(1000);            
		});
		$("#che").fadeIn(500);
		$("#che").fadeTo(0,0.8);				
		var top = ($(window).height()-390)/2 - 25;
		var width = ($(window).width()-700);
		var left = ($(window).width() - width)/2 - 25;
		$("#pupPanel").css({'top':top + 'px','left' :left + "px" ,"width" : width + "px","height" : '200px'});
		$("#pupPanel").fadeIn(1000);	
		return false;
		
	});
	$("#contact").click(function(){       
		$.post('blocks/page/contact.php',{lang:lang},function(data){            
			$('#pupPanel').html(data).fadeIn(1000);            
		});
		$("#che").fadeIn(500);
		$("#che").fadeTo(0,0.8);				
		var top = ($(window).height()-500)/2 - 25;
		var width = ($(window).width()-700);
		var left = ($(window).width() - width)/2 - 25;
		$("#pupPanel").css({'top':top + 'px','left' :left + "px" ,"width" : width + "px","height" : '200px'});
		$("#pupPanel").fadeIn(1000);	
		return false;
		
	});
	 $('.show_gio_hang').click(function(){
        window.location.href=link_cart + '.html';
    });
})