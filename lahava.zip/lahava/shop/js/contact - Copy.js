$(document).ready(function() { 
	 var lang = $.cookie('lang');
	 $("#btnFinish").click(function(){ 
		var obj = $("input.required , textarea.required");
		var ho_ten = $('#ho_ten').val(); 		
		var dien_thoai =  $('#dien_thoai').val(); 
		var email =  $('#email').val(); 
		var noi_dung =  $('#noi_dung').val();
		for(i=0 ; i <= obj.length;i++) 
		{                 
			if($.trim($(obj[i]).val())=='') 
			{ 
				$(obj[i]).css('border','1px solid red');				
			}
		} 
		
		if(ho_ten != '' && noi_dung != '' && dien_thoai != '' && email != ''){
			$.post("ajax/check_email.php",{email:email},function(data){
				
				if(data==1) { 
					$('#email').css('border','1px solid red');	
					return false;
				}else{
					$('.modalInfo').load('blocks/page/thanks.php?chk=contact&age='+lang);	
					$.post('ajax/save_contact.php',{ho_ten:ho_ten,noi_dung:noi_dung,dien_thoai:dien_thoai,email:email},function(data){					
							
						//setTimeout(function(){window.location.href='http://lahava.vn/gio-hang.html';},3000)		
					});
				}
			})				
			
		}else{
			return false;
		}
	}) 
	$("input.required , textarea.required").blur(function(){	
		if($.trim($(this).val())){
			$(this).css('border','1px solid #666');
		}else{
		 	$(this).css('border','1px solid red');
		}
			
	});
	$("#email").blur(function(){	
		var email =  $('#email').val(); 
		$.post("ajax/check_email.php",{email:email},function(data){			
			if(data==1) { 
				$('#email').css('border','1px solid red');	
				return false;
			}else{
				$('#email').css('border','1px solid #666');
			}
		})
			
	});
	
}); 