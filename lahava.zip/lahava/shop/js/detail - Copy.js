$(function() {
	var tb_size,tb_mau  = '';
	var lang = $.cookie('lang');
	if(lang == 'vi') {
		tb_mau = "Vui lòng chọn màu!";
		tb_size = "Vui lòng chọn size!";
	}else{
		tb_mau = "Please select color!";
		tb_size = "Please select size!";
	}
	$('#add_sp').click(function(){
		if($('.mau_da_chon').length==0){
			alert(tb_mau);
			return false;
		}
		if($('#chon_size').val()=='null'){
			alert(tb_size);
			return false;
		}
		if($('.mau_da_chon').length==1 && $('#chon_size').val() !='null')
		{
			var mau_id = $('.mau_da_chon').find('img.icon_color').attr('mau_id');			
			$.post('ajax/process_cart.php',{action:'add',sp_id:$(this).attr('idSP'),mau_id:mau_id,size:$('#chon_size').val()},function(data){			
				var arrRes = JSON.parse(data);		
				$('#so_sp_gio_hang').html(arrRes.tong_so_sp);
				$('#hien_gio_hang').fadeIn(2000);
			});
		}
	});
	
	$(".small_img" ).click(function(){
		var src = $(this).attr("src");
		src = src.replace("54/","330/");
		
		$("#hinh_dai_dien").hide().attr("src",src);
		$("#hinh_dai_dien").fadeIn(1000);				
	});
	$(".icon_color").click(function(){	
		$(".icon_color").parent().css('border',"none");	
		$('.bao_color').removeClass('mau_da_chon');
		$(this).parent().addClass('mau_da_chon').css('border',"1px solid black");;
	});
	$('#nut_luu').click(function(){
		$.post('ajax/luu_sp.php',{sp_id:$(this).attr('idSP')},function(data){
			$('#thongbao_detail').html(data);		
		});
		setTimeout('dongthongbao()',2000);
	});
	$('#hien_gio_hang').click(function(){
		window.location.href='gio-hang.html';
	});
	
	
});
function dongthongbao(){
	$('#thongbao_detail').html('');
}