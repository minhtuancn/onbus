<?php 
session_start();
require_once "../admin/lib/class.sanpham.php";
$sp = new sanpham;
$mod  = isset($_GET['mod']) ?  $_GET['mod'] : "";
if($_SESSION['lang']){
	$lang=$_SESSION['lang'];
}else{
	$lang = 'vi';
}
setcookie("lang", $lang, time()+3600);
function checkCat($uri){
    $pattern_detail = '#[a-z0-9\-]+\-\d+.html#'; 
	$pattern_tag = '#/tag/[a-z\-]+.html#';
    $pattern_cat = '#[a-z\-]+.html#';		
  
	$pattern_cart = '#gio-hang+.html#';
	
    $mod = "";		
	if(preg_match($pattern_cart,$uri)){
        $mod = "gio-hang";
    }	
    if(preg_match($pattern_detail,$uri)){
        $mod = "detail";
    }	
    if(preg_match($pattern_cat,$uri)){
        $mod = "loaisp";
		$uri = str_replace(".html","",$uri);
		$tmp_uri = explode("/",$uri);
		if($tmp_uri[1]=='tag') $mod = 'tag';
		if($tmp_uri[1]=='gio-hang' || $tmp_uri[1]=='shopping-cart') $mod = 'gio-hang';
		
    }
    return $mod;    
}

$uri = str_replace("/shop","",$_SERVER['REQUEST_URI']);

$mod = checkCat($uri);
$uri = str_replace(".html","",$uri);
$tmp_uri = explode("/",$uri);

switch($mod){
	 case "tag":        
	 	$tag_name_kd = $tmp_uri[2];
		$sql = "SELECT tag_name FROM tag WHERE tag_name_kd = '$tag_name_kd' AND lang= '$lang'";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);
        $title = $row['tag_name'];
        $metaD = $row['tag_name'];
        $metaK = $row['tag_name'];       
        break;			
    case "loaisp":
        $ten_kd = $tmp_uri[1];
		if($ten_kd=="wedding-dresses" || $ten_kd == 'dam-cuoi') $loai_id = 1;
		if($ten_kd=="evening-dresses" || $ten_kd == 'dam-da-hoi') $loai_id = 2;
		if($ten_kd=="cocktail-dresses" || $ten_kd == 'dam-ngan') $loai_id = 3;	
		setcookie("loai_id", $loai_id, time()+3600);			
        $sql_lang_loaisp = "SELECT * FROM loaisp WHERE loai_id = $loai_id";
		$rs_lang_loaisp = mysql_query($sql_lang_loaisp);
		$row_lang_loaisp = mysql_fetch_assoc($rs_lang_loaisp);		
        $title = $row_lang_loaisp["title_".$lang];
        $metaD = $row_lang_loaisp["metad_".$lang];
        $metaK = $row_lang_loaisp["metad_".$lang];       
        break;   
	case "gio-hang":
        
		if($lang=='vi'){
			$title = "Giỏ hàng";
			$metaD = "Giỏ hàng";
        	$metaK = "Giỏ hàng";    
		}else{
			$title = "Shopping Cart";
			$metaD = "Shopping Cart";
        	$metaK = "Shopping Cart";
		}
          
        break;	   
    case "detail":
		$tieude_id = $tmp_uri[1];
		$arr = explode("-",$tieude_id);
        $sp_id = (int) end($arr) ;      
        $arr_sp_vuaxem = array();
		
		$_SESSION['vua_xem'][$sp_id] = $sp_id;
		$rs = $sp->getDetailSP($sp_id);
		$strLoai_id = $sp->getLoaiId($sp_id);
		
		$tmp = explode(',',$strLoai_id);
		$loai_id = $tmp[0];
		$row_sp = mysql_fetch_assoc($rs);
		$arr_sp_next = $sp->getSPNext($sp_id,$strLoai_id);
		$arr_sp_prev = $sp->getSPPrev($sp_id,$strLoai_id);
		
		if($row_sp['hinh_anh']!="") 
		$arrImg = $sp->getArrImages($row_sp['hinh_anh']);
		$sql = "SELECT * FROM sanpham WHERE sp_id = $sp_id";
		$rs = mysql_query($sql);
		$row = mysql_fetch_assoc($rs);       
        $title = $row["ten_sp_".$lang];
        $metaD = $row["mo_ta_".$lang];
        $metaK = $row["mo_ta_".$lang];         
        break;
   
    default :
		if($lang=='vi'){
			$title ="Áo cưới LAHAVA ● Vietnam Wedding dress"; 
			$metaD ="Áo cưới cao cấp 2013, chuyên thiết kế váy cưới đẹp theo form dáng của mỗi cô dâu chuyên nghiệp nhất - LAHAVA Vietnam Wedding dress"; 
			$metaK ="Áo cưới,váy cưới, đầm cưới đẹp, áo cưới lahava, lahava vietnam, lahava dress";  
		}else{
			$title = "LAHAVA Wedding";
			$metaD = "LAHAVA FASHION";
        	$metaK = "LAHAVA FASHION";
		}
		
        break;
        
}

?>