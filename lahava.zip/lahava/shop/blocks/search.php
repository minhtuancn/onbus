<?php 
require_once "../../admin/lib/class.sanpham.php";
$sp = new sanpham;
require_once "../../admin/lib/class.trangchu.php";
$tc = new trangchu;
define ('USD',21000);
if(!isset($_POST['keyword'])){
$arrID = $arrMau = $arrKieu = $arrGia = $arrLoai = $arrChat = array();
$mau = substr($sp->processData($_POST['mau']),0,-1);
$kieu = substr($sp->processData($_POST['kieu']),0,-1);
$chat = substr($sp->processData($_POST['chat']),0,-1);
$gia = (int) $sp->processData($_POST['gia']);
$loai_id = (int) $sp->processData($_POST['loai_id']);

if($loai_id > 0){
	$sql = "SELECT sp_id FROM sp_loai WHERE loai_id = $loai_id ORDER BY sp_id DESC";	
	$rs = mysql_query($sql);
	while($row = mysql_fetch_assoc($rs)){
		$arrLoai[$row['sp_id']]= $row['sp_id'];
	}
}
if($mau!=""){
	$sql = "SELECT sp_id FROM sp_mau WHERE mau_id IN (".$mau.") ORDER BY sp_id DESC";	
	$rs = mysql_query($sql);
	while($row = mysql_fetch_assoc($rs)){
		$arrMau[$row['sp_id']]= $row['sp_id'];
	}	
}
if($kieu!=""){
	$sql = "SELECT sp_id FROM sp_kieu WHERE kieu_id IN (".$kieu.") ORDER BY sp_id DESC";	
	$rs = mysql_query($sql) or die(mysql_error());
	while($row = mysql_fetch_assoc($rs)){
		$arrKieu[$row['sp_id']]= $row['sp_id'];
	}
}
if($chat!=""){
	$sql = "SELECT sp_id FROM sp_chat WHERE chat_id IN (".$chat.") ORDER BY sp_id DESC";	
	$rs = mysql_query($sql) or die(mysql_error());
	while($row = mysql_fetch_assoc($rs)){
		$arrChat[$row['sp_id']]= $row['sp_id'];
	}
}
/// gia 
if($gia == 1600000) $gia=3000000;
	if($gia < 3000000){
		$sql = "SELECT sp_id FROM sanpham WHERE gia <= $gia";	
		$rs = mysql_query($sql);
		while($row = mysql_fetch_assoc($rs)){
			$arrGia[$row['sp_id']]= $row['sp_id'];
		}
	}
	if($gia == 	3000000){
		$sql = "SELECT sp_id FROM sanpham";	
		$rs = mysql_query($sql);
		while($row = mysql_fetch_assoc($rs)){
			$arrGia[$row['sp_id']]= $row['sp_id'];
		}

	}

if($kieu !="" && $mau != "" && $chat != '') $arrID = array_intersect($arrMau, $arrKieu,$arrGia,$arrLoai,$arrChat);
if($kieu != "" && $mau == "" && $chat !='' ) $arrID = array_intersect($arrKieu,$arrGia,$arrLoai,$arrChat);
if($kieu != "" && $mau != "" && $chat =='') $arrID = array_intersect($arrKieu,$arrMau,$arrGia,$arrLoai);
if($kieu == "" && $mau != "" && $chat !='') $arrID = array_intersect($arrChat,$arrMau,$arrGia,$arrLoai);
if($kieu != "" && $mau == "" && $chat == '') $arrID = array_intersect($arrKieu,$arrGia,$arrLoai);
if($kieu == "" && $mau != "" && $chat == '') $arrID = array_intersect($arrMau,$arrGia,$arrLoai);
if($kieu == "" && $mau == "" && $chat != '') $arrID = array_intersect($arrChat,$arrGia,$arrLoai);
if($kieu == "" && $mau == "" && $chat == '') $arrID = $arrLoai;

$str_sp_id = implode(",",$arrID);
if(!empty($arrID)){
	foreach($arrID as $sp_id){
		$rs = $sp->getDetailSP($sp_id);
		$row_sp = mysql_fetch_assoc($rs);
	?>
    <div id="item">
        <a href="<?php echo $row_sp['ten_sp_vi_kd']?>-<?php echo $row_sp['sp_id']; ?>.html">
        	<img src="../<?php echo $sp->getImageSizeHoang($row_sp['hinh_dai_dien'],255); ?>" width="255" height="360" />
            
        </a>
        <br />
        <a href="<?php echo $row_sp['ten_sp_vi_kd']?>-<?php echo $row_sp['sp_id']; ?>.html">
			<?php echo $row_sp['ten_sp_vi']; ?>
        </a>    
        <br />
       <strong>	  
	   <?php  if($row_sp['khuyen_mai'] > 0) echo number_format($row_sp['gia']-($row_sp['khuyen_mai']*$row_sp['gia'])/100);else echo  number_format($row_sp['gia'])?> đ</strong>
    </div>  
	<?php
    }
}
}else{
	$keyword = $sp->processData($_POST['keyword']);
	$lang =  $sp->processData($_POST['lang']);
	if($keyword!=""){
		$sql = "SELECT * FROM sanpham WHERE ten_sp_".$lang." like '%$keyword%' OR ma_sp like '%$keyword%' ";		
		$rs = mysql_query($sql);
		$so_sp = mysql_num_rows($rs);
		if($so_sp> 0){
		while($row_sp = mysql_fetch_assoc($rs)){
			$giaviet = $row_sp['gia']-($row_sp['khuyen_mai']*$row_sp['gia'])/100;
		?>
        	<div id="item">
                <a href="<?php echo $row_sp['ten_sp_'.$lang.'_kd']?>-<?php echo $row_sp['sp_id']; ?>.html">
                <img src="../<?php echo $sp->getImageSizeHoang($row_sp['hinh_dai_dien'],255); ?>" width="255" height="360" /></a><br />
                <a href="<?php echo $row_sp['ten_sp_'.$lang.'_kd']?>-<?php echo $row_sp['sp_id']; ?>.html">
				<?php echo $row_sp['ten_sp_'.$lang]; ?>
                </a>
                <br />
                <strong><?php echo ($lang=='vi') ? number_format($giaviet) : round($giaviet/USD,0); ?> <?php echo $tc->language('tien',$lang); ?></strong>
            </div> 
        <?
		}}else{
			echo ($lang=='vi') ? "<h4>Không tìm thấy sản phẩm nào !</h4>" : "<h4>Not found product !</h4>";
		}
		
	}
}


?>
        