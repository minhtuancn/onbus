<?php 
$chk = $_GET['chk'];
$lang = $_GET['age'];
?>
<?php if($chk == 'thanhtoan') {?>
	<?php if($lang=='vi') {?>
        <p>Cảm ơn quý khách đã mua hàng.</p>
        <p>Quý khách vui lòng check mail về thông tin đơn hàng của quý khách.</p>
    <?php }else{ ?>
    	<p>Thanks.</p>	
    <?php } ?>       
<?php }else{ ?>
	<?php if($lang=='vi') {?>
        <p>Cảm ơn quý khách đã liên hệ.</p>
        <p>Chúng tôi sẽ hoi am trong thời gian sớm nhất.</p>
    <?php }else{ ?>
    	<p>Thanks.</p>	
    <?php } ?>
<?php } ?>