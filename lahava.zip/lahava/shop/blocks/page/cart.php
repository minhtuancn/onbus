<div id="leftmenu">
		<?php include "blocks/page/menu_left.php"; ?>
</div>
	<div id="mainpage">
    <table width="100%" id="table_cart" cellpadding="10" cellspacing="0">
    	<thead>
        	<tr><td colspan="7"><h3 class="upper"><?php echo $tc->language('gio-hang',$lang); ?></h3></td></tr>
        </thead>
        <tbody>
        	<tr class="header">
            	<td width="1"><h4><?php echo $tc->language('san-pham',$lang); ?></h4></td>
                <td width="30%"><h4><?php echo $tc->language('ma-san-pham',$lang); ?></h4></td>
                <td><h4><?php echo $tc->language('mau-sac',$lang); ?></h4></td>
                <td><h4>Size</h4></td>
                <td><h4><?php echo $tc->language('so-luong',$lang); ?></h4></td>
                <td><h4><?php echo $tc->language('gia',$lang); ?></h4></td>
                <td align="center"><h4><?php echo $tc->language('xoa',$lang); ?></h4></td>
            </tr>
               <?php 
			   	if (isset($_SESSION['daySoLuong']))
				 while( key($_SESSION['daySoLuong'])!= null){
					$idSP=key($_SESSION['daySoLuong']);
					$mota=current($_SESSION['dayMaSP']);
					$soluong=current($_SESSION['daySoLuong']);
					$dongia=current($_SESSION['dayDonGia']);
					$urlhinh=current($_SESSION['dayUrlHinh']);
					$size=current($_SESSION['daySize']);
					$mau_id=current($_SESSION['dayMau']);
					if($soluong>0){		
					$giaviet = number_format($_SESSION['tien_sp'][$idSP]);
					$giausd = round($giaviet/USD,0);
			 ?>
            <tr class="product_cart" id="dong_<?php echo $idSP; ?>">
            	<td><img src="../<?php echo $tc->getImageSizeHoang($urlhinh,65); ?>"  width="65" height="83" /></td>
                <td style="text-transform:uppercase"><?php echo $mota;?></td>
                <td> 
                <?php 
					$chitietmau = $tc->getDetailMau($mau_id);
					$row_mau = mysql_fetch_assoc($chitietmau);
					$_SESSION['dayMauHinh'][$idSP] = "http://lahava.vn/".$row_mau['hinh']; 
				?>
                       
                <img  src="<?php echo $_SESSION['dayMauHinh'][$idSP];?>" width="25" height="25" />
                
                </td>
                <td><?php echo $size;?></td>
                <td>
				<div style="float:left;width:48%;padding-top:13px;text-align:right;">
					<span id="soluong_<?php echo $idSP; ?>"><?php echo $soluong;?></span> &nbsp;&nbsp;&nbsp;
                </div>
                <div style="float:left;width:50%">
                    <table border="0" width="1" cellpadding="5" class="tbl_soluong">                    	
                        <tr><td><img src="images/cong.png" idSP="<?php echo $idSP; ?>" class="nut_cong" soluong="<?php echo ($soluong + 1);?>"  /></td></tr>
                        <tr><td><img src="images/tru.png" idSP="<?php echo $idSP; ?>" class="nut_tru" soluong="<?php echo ($soluong - 1);?>" /></td></tr>
                    </table>
                </div>
                </td>
                <td><span id="tien_<?php echo $idSP; ?>"><?php echo ($lang=='vi') ? number_format($_SESSION['tien_sp'][$idSP]) : round($_SESSION['tien_sp'][$idSP]/USD,0) ;?></span> <?php echo $tc->language('tien',$lang); ?></td>
                <td align="center"><img idSP="<?php echo $idSP; ?>" src="images/remove-icon.gif" class="xoa_sp" style="cursor:pointer" /></td>
            </tr>
             <?php 	} 
			 		next($_SESSION['daySoLuong']);
					next($_SESSION['dayDonGia']);
					next($_SESSION['dayMaSP']);	
					next($_SESSION['dayUrlHinh']);	
					next($_SESSION['dayMau']);			
					next($_SESSION['daySize']);					
					
			 ?>
 <?php } ?>
            <tr class="total_cart">
            	<td colspan="6">
                	<span><?php echo $tc->language('tong-cong',$lang); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    <span id="total_price"><?php echo ($lang=='vi') ? number_format($_SESSION['tong_tien']) : round($_SESSION['tong_tien']/USD,0);?></span><span> VNĐ</span>
                </td>
                <td>&nbsp;</td>
            </tr>            
        </tbody>
        <tfoot>
        	<tr class="mua_hang">
            	<td colspan="2" class="left">
                	<span id="tiep_tuc_mua"><a href="http://lahava.vn/shop/dam-cuoi.html"><?php echo $tc->language('tip-tuc-mua-hang',$lang); ?></span>
                </td>
                <td colspan="7" class="right">
                <?php if($_SESSION['tong_tien']>0){?>
                	<span id="thanh_toan"><?php echo $tc->language('thanh-toan',$lang); ?></span>
                <?php } ?>    
                </td>
            </tr>
        </tfoot>
    </table>
    <div id="newfooter"><?php include "blocks/page/newfooter.php"; ?></div>
  </div>
  <!--<?php include "blocks/page/footer.php"; ?>-->
</div>	
<script type="text/javascript">
$(function() {
	$('.nut_cong').click(function(){
		var idSP = $(this).attr('idSP');
		var soluong =  $(this).attr('soluong');
		if(parseInt(soluong)<11){
			$.post('ajax/process_cart.php',{sp_id:idSP,update:'update',soluong:soluong,action:'update'},function(data){		
				var arrRes = JSON.parse(data);		
				$('#tien_'+ idSP).html(addcommas(arrRes.tien_sp));
				$('#total_price').html(addcommas(arrRes.tong_tien));	
				$('#so_sp_gio_hang').html(arrRes.tong_so_sp);
				$('#soluong_' + idSP).html(soluong);				
				$('img.nut_cong[idSP=' + idSP + ']').attr('soluong',parseInt(soluong) + 1);
				$('img.nut_tru[idSP=' + idSP + ']').attr('soluong',parseInt(soluong) - 1);
				if(arrRes.tong_tien==0) $('#thanh_toan').hide();				
			});
		}
	});
	$('.nut_tru').click(function(){
		var idSP = $(this).attr('idSP');
		var soluong =  $(this).attr('soluong');
		if(parseInt(soluong)>-1){
			$.post('ajax/process_cart.php',{sp_id:idSP,update:'update',soluong:soluong,action:'update'},function(data){					
				var arrRes = JSON.parse(data);		
				$('#tien_'+ idSP).html(addcommas(arrRes.tien_sp));
				$('#total_price').html(addcommas(arrRes.tong_tien));	
				$('#so_sp_gio_hang').html(arrRes.tong_so_sp);
				if(soluong==0){
					$('tr#dong_'+ idSP).hide();
				}else{
					$('#soluong_' + idSP).html(soluong);				
					$('img.nut_cong[idSP=' + idSP + ']').attr('soluong',parseInt(soluong) + 1);
					$('img.nut_tru[idSP=' + idSP + ']').attr('soluong',parseInt(soluong) - 1);	
				}						
				if(arrRes.tong_tien==0) $('#thanh_toan').fadeOut(1000);					
			});
		}
	});
	$('img.xoa_sp').click(function(){
		var idSP = $(this).attr('idSP');		
		
		$.post('ajax/process_cart.php',{sp_id:idSP,action:'remove'},function(data){					
			var arrRes = JSON.parse(data);		
			$('#tien_'+ idSP).html(addcommas(arrRes.tien_sp));
			$('#total_price').html(addcommas(arrRes.tong_tien));	
			$('#so_sp_gio_hang').html(arrRes.tong_so_sp);				
			$('tr#dong_'+ idSP).hide();									
			if(arrRes.tong_tien==0) $('#thanh_toan').fadeOut(1000);					
		});
		
	});
	$("#thanh_toan").click(function(){       
        $.post('blocks/page/thanhtoan_<?php echo $lang; ?>.php',null,function(data){            
            $('#pupPanel').html(data).fadeIn(1000);            
        })
		$("#che").fadeIn(500);
		$("#che").fadeTo(0,0.8);				
		var top = ($(window).height()-490)/2 - 25;
		var width = ($(window).width()-600);
		var left = ($(window).width() - width)/2 - 25;
		$("#pupPanel").css({'top':top + 'px','left' :left + "px" ,"width" : width + "px"});
		$("#pupPanel").fadeIn(1000);	
		return false;	
	});
});
</script>