<?php 
if($loai_id > 0) {
	$sql = "SELECT sp_id FROM sp_loai WHERE loai_id = $loai_id ORDER BY sp_id DESC";
	$listSP = mysql_query($sql) or die(mysql_error());
}
?>
  	<div id="leftmenu">
		<?php include "blocks/page/menu_left.php"; ?>

  </div>
  <div id="profilter">
  <?php include "blocks/page/menu.php"; ?>
  </div>
<div>	
	<div id="mainpage">
    	<?php
		if(!empty($listSP)){
		while($row_sp = mysql_fetch_assoc($listSP)){			
		$chitiet = $tc->getDetailSP($row_sp['sp_id']);
		$row_chitiet= mysql_fetch_assoc($chitiet);	
		$giaviet = $row_chitiet['gia']-($row_chitiet['khuyen_mai']*$row_chitiet['gia'])/100;
		$giausd =round($giaviet/USD);
		?>
    	<div id="item">
            <a href="<?php echo $row_chitiet['ten_sp_'.$lang.'_kd']?>-<?php echo $row_chitiet['sp_id']; ?>.html">
            	<img class="lazy" src="img/grey.jpg" data-original="../<?php echo $tc->getImageSizeHoang($row_chitiet['hinh_dai_dien'],255); ?>" width="255" height="360" /></a><br />
            <a href="<?php echo $row_chitiet['ten_sp_'.$lang.'_kd']?>-<?php echo $row_chitiet['sp_id']; ?>.html"><?php echo $row_chitiet['ten_sp_'.$lang]; ?></a><br />
            <strong><?php echo ($lang=='vi') ? number_format($giaviet) : $giausd ;?>  <?php echo $tc->language('tien',$lang);?></strong>
        </div>       
        <?php } } ?>
        <div id="newfooter"><?php include "blocks/page/newfooter.php"; ?></div>
    </div>
</div>	