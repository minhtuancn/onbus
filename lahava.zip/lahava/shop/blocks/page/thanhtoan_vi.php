<?php $lang = 'en';
require_once "../../admin/lib/class.trangchu.php";
$tc= new trangchu;
 ?>
<div class="lt ieSh"></div><div class="rt ieSh"></div><div class="lb ieSh"></div><div class="rb ieSh"></div><div class="modalClose">
        <a id="closegiohang" href="javascript:void(0)" title="Cerrar ventana">Cerrar</a></div><div class="modalContent"><div class="modalTitle">
                <h2 id="title_fmenu">
	Thanh tOán
</h2></div><div class="modalInfo" style="height: 320px;"><div>	
	<div>
		<div data-ga-props="{logic:'Identificate/Registrate'}" class="infoLogin registerUserPanel gaTrack gaPanel" id="registerUserPanel" style="visibility: visible; opacity: 1;">
	<div class="infoSubtitle">
		<p>			
			Fill out the following form in order to register with <strong>lahava.vn</strong>.<br>
			We will save the details you provide in order to facilitate your purchases on our website.
		</p>
	</div>
	
		<div class="controls">
			<h3><?php echo $tc->language('thong-tin-cua-ban',$lang); ?></h3>
			<ul class="formControls">
				<li class="formControl">
					<label class="labelLeft" for="email1">
						Họ và Tên<em class="required">*</em>
					</label>
					<input type="text" class="inputText required validate-email" id="ho_ten" name="ho_ten" maxlength="100">					
					<span class="inputTip tipOk">
						<img alt="ok" src="https://static.zara.net/wcsstore/ZaraStorefrontAssetStore/images/tip_ok.png">
					</span>
					<span id="msgPos1" class="inputTip tipWarn">
						<img alt="warning" src="https://static.zara.net/wcsstore/ZaraStorefrontAssetStore/images/tip_warn.png">
					</span>					
				</li>
				<li class="formControl">
					<label id="newPasswordLabel" class="labelLeft" for="logonPassword">
						Email <em class="required">*</em>
					</label>
					<input type="text" class="inputText required" id="email" name="email" maxlength="60">
					<span id="msgPos2" class="inputTip tipWarn">
						<img alt="warning" src="https://static.zara.net/wcsstore/ZaraStorefrontAssetStore/images/tip_warn.png">
					</span>
					<span class="inputTip tipOk">
						<img alt="ok" src="https://static.zara.net/wcsstore/ZaraStorefrontAssetStore/images/tip_ok.png">
					</span>
				</li>
				<li class="formControl">
					<label class="labelLeft" for="logonPasswordVerify">
						Địa chỉ <em class="required">*</em>
					</label>
					<textarea class="required" name="dia_chi" id="dia_chi" style="width:183px;border:1px solid #666"></textarea>
					<span id="msgPos3" class="inputTip tipWarn">
						<img alt="warning" src="https://static.zara.net/wcsstore/ZaraStorefrontAssetStore/images/tip_warn.png">
					</span>
					<span class="inputTip tipOk">
						<img alt="ok" src="https://static.zara.net/wcsstore/ZaraStorefrontAssetStore/images/tip_ok.png">
					</span>
				</li>
                <li class="formControl">
					<label class="labelLeft" for="logonPasswordVerify">
						Số điện thoại <em class="required">*</em>
					</label>
					<input type="dien_thoai" class="inputText required " id="dien_thoai" name="dien_thoai" maxlength="60">
					<span id="msgPos3" class="inputTip tipWarn">
						<img alt="warning" src="https://static.zara.net/wcsstore/ZaraStorefrontAssetStore/images/tip_warn.png">
					</span>
					<span class="inputTip tipOk">
						<img alt="ok" src="https://static.zara.net/wcsstore/ZaraStorefrontAssetStore/images/tip_ok.png">
					</span>
				</li>
                <li class="formControl">
					<label class="labelLeft" for="logonPasswordVerify">
						Hình thức thanh toán <em class="required">*</em>
					</label>
                    <input type="radio" name="hinh_thuc" value="0" id="hinh_thuc_1" checked="checked" /> <strong>Trực tiếp tại cửa hàng</strong>
                    <input type="radio" name="hinh_thuc" value="1" id="hinh_thuc_2" /> <strong>Chuyển khoản</strong>					
				</li>
			</ul>
			</ul>
		
		</div>
		<div class="actions actionsControls">
			<button id="btnFinish" type="button" value="Registrar" class="button butBlack actionButton">
				<span>Hoàn tất</span>
			</button>
		</div>	
</div>
		
		
	</div>
</div></div></div>
<script type="text/javascript">
$(document).ready(function() { 
	 $("#btnFinish").click(function(){ 
		var obj = $("input.required , textarea.required");
		var ho_ten = $('#ho_ten').val(); 		
		var dien_thoai =  $('#dien_thoai').val(); 
		var email =  $('#email').val(); 
		var dia_chi =  $('#dia_chi').val();
		for(i=0 ; i <= obj.length;i++) 
		{                 
			if($.trim($(obj[i]).val())=='') 
			{ 
				$(obj[i]).css('border','1px solid red');				
			}
		} 
		
		if(ho_ten != '' && dia_chi != '' && dien_thoai != '' && email != ''){
			$.post("ajax/check_email.php",{email:email},function(data){
				
				if(data==1) { 
					$('#email').css('border','1px solid red');	
					return false;
				}else{
					$('.modalInfo').load('blocks/page/thanks.php?chk=thanhtoan&age=<?php echo $lang; ?>');	
					$.post('ajax/xuly_donhang.php',{ho_ten:ho_ten,dia_chi:dia_chi,dien_thoai:dien_thoai,email:email},function(data){												
						//setTimeout(function(){window.location.href='http://lahava.vn/gio-hang.html';},3000)		
					});
				}
			})				
			
		}else{
			return false;
		}
	}) 
	$("input.required , textarea.required").blur(function(){	
		if($.trim($(this).val())){
			$(this).css('border','1px solid #666');
		}else{
		 	$(this).css('border','1px solid red');
		}
			
	});
	$("#email").blur(function(){	
		var email =  $('#email').val(); 
		$.post("ajax/check_email.php",{email:email},function(data){			
			if(data==1) { 
				$('#email').css('border','1px solid red');	
				return false;
			}else{
				$('#email').css('border','1px solid #666');
			}
		})
			
	});
	
}); 
</script>