<?php 
ob_start();
session_start();
require_once "admin/lib/class.trangchu.php";
require_once("blocks/seo.php");
$tc = new trangchu;
define ('USD',21000);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title; ?></title>  
<meta name="description" content="<?php echo $metaD ;?>" />
<meta name="keywords" content="<?php echo $metaK ;?>" />
<base href="http://<?php echo $_SERVER['SERVER_NAME'];?>/" />
<link href="css/home.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/style_menu.css" type="text/css" media="screen">
<link href="css/home.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.9.1.custom.js"></script>
<script type="text/javascript" src="js/cookie.js"></script>
<script type="text/javascript" src="js/form.js"></script>
<script type="text/javascript" src="js/jquery.ui.core.js"></script>
<script type="text/javascript" src="js/jquery.ui.slider.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.slider.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.all.css"/>
<script type="text/javascript" src="js/function.js"></script>
</head>
<body>
<div id="container">
	<div id="header">
    <div id="logo"><a href="http://lahava.vn/" title="Home L A H A V A"><img src="images/lahava-san.png" width="264" height="50" border="0" /></a></div>
  </div>
  <?php include "blocks/layout/header.php";?>
  
  		<?php
		switch($mod){
			case "loaisp" : include "blocks/page/cat.php";break;
			case "detail" : include "blocks/page/detail.php";break;
			case "sp_luu" : include "blocks/page/sp_luu.php";break;
			case "gio-hang" : include "blocks/page/cart.php";break;
			case "tag" : include "blocks/page/tag.php";break;
			default        : include "blocks/layout/trangchu.php";break;
		}
		?>
  
</div>
 <div id="che"></div>
</body>
</html>