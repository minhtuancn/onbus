		<ul class="sf-menu" id="example">
			<li class="current">
				<a href="javascript:;"><?php echo $tc->language('bao-quan',$lang);?></a>
				<ul>
					
					<li class="current">
                       <?php echo $tc->getContentDetailPage(10,$lang);?>						
					</li>
					
					
				</ul>
			</li>
			
			<li>
				<a href="javascript:;"><?php echo $tc->language('giao-nhan',$lang);?></a>
				<ul>
					<li>
						<?php echo $tc->getContentDetailPage(11,$lang);?>						
					</li>	
					
				</ul>
			</li>
            
            <li>
				<a href="javascript:;"><?php echo $tc->language('doi-tra',$lang);?></a>
				<ul>
					<li>
						<?php echo $tc->getContentDetailPage(12,$lang);?>					
					</li>	
					
				</ul>
			</li>
				
		</ul>	
		