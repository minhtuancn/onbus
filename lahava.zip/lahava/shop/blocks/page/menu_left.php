<?php 
function _menu($id){
	$id = (int) $id;
	switch($id){
		case 1 :
	}
}
?>
<div id="search"><input name="search" id="keyword" type="text" placeholder="<?php echo $sp->language('tim-san-pham',$lang); ?>..." />
  <img src="images/search_button.png" width="18" height="20" id="search_button" /></div>  
  
  
  	<div id="menufilter">
     <?php if($loai_id==1){?>
    <img src="images/dots.png" width="6" height="6" />
    <a href="<?php echo $lang=='vi' ? "dam-cuoi" : "wedding-dresses"; ?>.html" ><?php echo $sp->language('ao-cuoi',$lang); ?></a>
    <?php }else { ?>
   <a href="<?php echo $lang=='vi' ? "dam-cuoi" : "wedding-dresses"; ?>.html" class="deactive"><?php echo $sp->language('ao-cuoi',$lang); ?></a>
    <?php } ?><br />
    <?php if($loai_id==2){?>
    <img src="images/dots.png" width="6" height="6" />
    <a href="<?php echo $lang=='vi' ? "dam-da-hoi" : "evening-dresses"; ?>.html" ><?php echo $sp->language('dam-da-hoi',$lang); ?></a>
	<?php }else { ?>
  	<a href="<?php echo $lang=='vi' ? "dam-da-hoi" : "evening-dresses"; ?>.html" class="deactive"><?php echo $sp->language('dam-da-hoi',$lang); ?></a>
    <?php } ?>
    <br />
  	  <?php if($loai_id==3){?>
    <img src="images/dots.png" width="6" height="6" />
    <a href="<?php echo $lang=='vi' ? "dam-ngan" : "cocktail-dresses"; ?>.html" ><?php echo $sp->language('dam-ngan',$lang); ?></a>
    <?php }else { ?>
   	<a href="<?php echo $lang=='vi' ? "dam-ngan" : "cocktail-dresses"; ?>.html" class="deactive"><?php echo $sp->language('dam-ngan',$lang); ?></a>
    <?php } ?> <br />



<br />+&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)" id="ho_tro" idM="8" class="upper"><?php echo $sp->language('ho-tro',$lang); ?></a>
 <p>&nbsp;</p>
  	  <p>-&nbsp;&nbsp;&nbsp;<a target="_blank" href="http://damrendep.com" class="upper"><?php echo $sp->language('su-kien',$lang); ?></a></p></div>
<script type="text/javascript">
$(function(){
	$('#search_button').click(function(){	
        var keyword = $("#keyword" ).val();
        if(keyword==''){
            $("#keyword" ).css('border','1px solid red');
            return false;
        }else{
            $.post('blocks/search.php',{keyword:keyword,lang:'<?php echo $lang; ?>'},function(data){
                $('#mainpage').html(data).stop(true, true).fadeOut(500).fadeIn(1000);
            });

        }						
    })	
	$("#keyword").keypress(function(e) {		
		var code = (e.keyCode ? e.keyCode : e.which);
		if (code==13) {
			var keyword = $("#keyword" ).val();
			if(keyword==''){
				$("#keyword" ).css('border','1px solid red');
				return false;
			}else{
				$.post('blocks/search.php',{keyword:keyword,lang:'<?php echo $lang; ?>'},function(data){
					$('#mainpage').html(data).stop(true, true).fadeOut(500).fadeIn(1000);
				});
	
			}
		}
	});
})
</script>      