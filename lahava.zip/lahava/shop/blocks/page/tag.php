<?php 
$tag_name_kd = trim(strip_tags($tag_name_kd));
if($tag_name_kd) {
	$str_tag_id='';
	$sql = "SELECT tag_id FROM tag WHERE BINARY tag_name_kd = '$tag_name_kd'";
	$listTagId = mysql_query($sql);
	while($row_listTagId = mysql_fetch_assoc($listTagId)){
		$str_tag_id .= $row_listTagId['tag_id'].",";
	}

	if($str_tag_id!=""){
		$str_tag_id = rtrim($str_tag_id,",");
		$sql_1 = "SELECT sp_id FROM sp_tag WHERE tag_id IN(".$str_tag_id.") GROUP BY sp_id ORDER BY sp_id DESC";
		$listSP= mysql_query($sql_1) or die(mysql_error());	
	}
	
	
}

?>
  	<div id="leftmenu">
		<?php include "blocks/page/menu_left.php"; ?>

  </div>
  <div id="profilter"
  <?php include "blocks/page/menu.php"; ?>
  
	<div id="mainpage">
    	<?php
		if(!empty($listSP)){
		while($row_sp = mysql_fetch_assoc($listSP)){
			$chitiet = $tc->getDetailSP($row_sp['sp_id']);
			$row_chitiet= mysql_fetch_assoc($chitiet);		
			$giaviet = $row_chitiet['gia']-($row_chitiet['khuyen_mai']*$row_chitiet['gia'])/100;			
		?>
    	<div id="item">
            <a href="<?php echo $row_chitiet['ten_sp_'.$lang.'_kd']?>-<?php echo $row_chitiet['sp_id']; ?>.html"><img src="../<?php echo $sp->getImageSizeHoang($row_chitiet['hinh_dai_dien'],255); ?>" width="255" height="360" /></a><br />
            <a href="<?php echo $row_chitiet['ten_sp_'.$lang.'_kd']?>-<?php echo $row_chitiet['sp_id']; ?>.html"><?php echo $row_chitiet['ten_sp_'.$lang]; ?></a><br />
            <strong><?php echo ($lang=='vi') ? number_format($giaviet) : round($giaviet/USD,0); ?> <?php echo $tc->language('tien',$lang); ?></strong>
        </div>       
        <?php } } ?>
       <div id="newfooter"><?php include "blocks/page/newfooter.php"; ?></div> 
    </div>
</div>	