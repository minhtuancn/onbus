<?php 
$giaviet = number_format($row_sp['gia']-($row_sp['khuyen_mai']*$row_sp['gia'])/100);
$giausd = round(($row_sp['gia']-($row_sp['khuyen_mai']*$row_sp['gia'])/100)/USD,0);
$giavietold = number_format($row_sp['gia']); 
$giausdold  =  round($row_sp['gia']/USD,0);
?>
<div id="leftmenu">
  <?php include "blocks/page/menu_left.php"; ?>
</div>
<div id="pronav">
  <div id="navpro">
    <?php if(!empty($arr_sp_prev)){?>
    <a href="<?php echo $arr_sp_prev['ten_sp_'.$lang.'_kd']?>-<?php echo $arr_sp_prev['sp_id'];?>.html"><img src="images/arrow_pre.png" width="16" height="12" /></a>&nbsp;&nbsp;
    <?php } ?>
    <?php if(!empty($arr_sp_next)){?>
    <a href="<?php echo $arr_sp_next['ten_sp_'.$lang.'_kd']?>-<?php echo $arr_sp_next['sp_id'];?>.html"><img src="images/arrow_next.png" width="16" height="12" /></a>
    <?php } ?>
  </div>
</div>
<div id="mainpage">
  <div id="imgszoom">
  		
        <div class="zoom-section">    	  
			<div class="zoom-small-image">
				<a href='<?php echo str_replace('../','',$row_sp['hinh_dai_dien']); ?>' class = 'cloud-zoom' id='zoom1' rel="adjustX: 10, adjustY:-4">
					<img src="../<?php echo $tc->getImageSizeHoang($row_sp['hinh_dai_dien'],330); ?>" alt='<?php echo $row_sp['ten_sp_'.$lang]; ?>' />
				</a>
			</div>		
		</div>   
           
  </div>
  <div id="detailinfo">
    <div id="title"><?php echo $row_sp['ten_sp_'.$lang]; ?></div>
    <div id="price"><?php echo ($lang=='vi') ? $giaviet : $giausd; ?> <?php echo $tc->language('tien',$lang);?></div>
    <?php if($giausd != $giausdold) { ?><div id="oldprice"><?php echo ($lang=='vi') ? $giavietold : $giausdold;?> <?php echo $tc->language('tien',$lang);?></div><?php } ?>
    <div id="description"><?php include "blocks/page/description.php"; ?></div>
    <div id="code"><?php echo $row_sp['ma_sp']; ?></div>
    <div id="imgsnav">
   		
      	<div class="zoom-desc">      
        	<p>
        	 <?php foreach ($arrImg as $img){
			
			?>
            <a href='../<?php echo $img; ?>' class='cloud-zoom-gallery' title='Red' rel="useZoom: 'zoom1', smallImage: '../<?php echo $tc->getImageSizeHoang($img,330); ?>' "><img class="zoom-tiny-image" src="../<?php echo $tc->getImageSizeHoang($img,54); ?>" alt = "<?php echo $row_sp['ten_sp_'.$lang]; ?>"/></a>
        <?php } ?>
       		</p>
		</div>
   		
    </div>
    <div id="color">
      <ul id="color_full">
        <?php 
			$list_mau = $tc->getListMauByProductId($sp_id);
			while($row_m = mysql_fetch_assoc($list_mau)){
				$chitiet_m = $tc->getDetailMau($row_m['mau_id']);
				$row_mau = mysql_fetch_assoc($chitiet_m);
			?>
        <li>
          <div class="bao_color"> <img class="icon_color" mau_id='<?php echo $row_mau['mau_id'];?>' src="../<?php echo str_replace('mausac','mausac/small',$row_mau['hinh']); ?>" alt="<?php echo $row_mau['ten_vi']; ?>" /> </div>
        </li>
        <?php } ?>
      </ul>
    </div>
    <div style="clear:both">
      <select id="chon_size" style="border:1px solid black;height:22px;text-align:center;float:left;margin-top:25px">
        <option value="null">Size&nbsp;</option>
        <?php 
			$list_size = $tc->getListSizeByProductId($sp_id);
			while($row_s = mysql_fetch_assoc($list_size)){
				$chitiet_s = $tc -> getDetailSize($row_s['size_id']);
				$row_size = mysql_fetch_assoc($chitiet_s);
			?>
        <option value="<?php echo $row_size['size'];?>"><?php echo $row_size['size'];?>&nbsp;</option>
        <?php } ?>
      </select>
      <div id="sizeguide" style="float:left"><a href="javascript:void(0)" idM="2" id="choose_size"><?php echo $tc->language('cach-chon-size',$lang); ?></a></div>
      <div style="clear:both"></div>
    </div>
    <div class="clickbutton"><a style="margin-right:20px" href="javascript:void(0)" id="add_sp" idSP="<?php echo $row_sp['sp_id'];?>"> <?php echo $tc->language('them-vao-gio',$lang); ?></a> <a href="javascript:void(0)" id="hien_gio_hang" ><?php echo $tc->language('thanh-toan',$lang); ?></a></div>
  </div>
  <div id="wrapper">
  	<?php echo $tc->language('re-chuot-vao-hinh',$lang); ?>
    <div style="margin-top:10px"></div>
    <span id="thongbao_detail" style="color:red;font-size:11px;margin-top:10px;display:block;padding-top:10px;clear:both"></span> </div>
  <?php if(!empty($_SESSION['vua_xem'])){?>
  <div id="recentlyviewed">
    <div id="viewedtitle" class="upper"><?php echo $tc->language('san-pham-vua-xem',$lang); ?></div>
    <div id="viewedpro">
      <ul id="viewed">
        <?php 
			$count=0;
			$arrVuaXem = array_reverse($_SESSION['vua_xem']);
			foreach($arrVuaXem as $sp_id_vuaxem ){				
			    $count++;
				if($count <= 5){
				$tc_vua = $tc->getDetailSP($sp_id_vuaxem);
				$row_vua_xem = mysql_fetch_assoc($tc_vua);
			?>
        <li class="item"> <a href="<?php echo $row_vua_xem['ten_sp_'.$lang.'_kd']?>-<?php echo $row_vua_xem['sp_id'];?>.html"> <img src="../<?php echo $tc->getImageSizeHoang($row_vua_xem['hinh_dai_dien'],54); ?>" width="54" height="80" /> </a> </li>
        <?php 
			 }	else{ 
			 break; 
			 }}  ?>
      </ul>
    </div>
  </div>
  <?php } ?>
  <div id="tagstitle" class="upper"><?php echo $tc->language('xem-them',$lang); ?></div>
  <div id="tags">
    <?php $listTag = $tc->getTagsByProductId($sp_id,$lang);
	  if(!empty($listTag)){
		  $sotag = mysql_num_rows($listTag);
		  $count = 0;
	  while($row_tag = mysql_fetch_assoc($listTag)){
		  $count++;
		  $chitietTag = $tc->getDetailTag($row_tag['tag_id']);
		  $row_chitietTag = mysql_fetch_assoc($chitietTag);
	  ?>
    <a href="tag/<?php echo $row_chitietTag['tag_name_kd']; ?>.html"><?php echo $row_chitietTag['tag_name']; ?></a>
    <?php if($count < $sotag){?>
    ,
    <?php } ?>
    <?php }} ?>
  </div>
  <div id="newfooter"><?php include "blocks/page/newfooter.php"; ?></div>
</div>
</div>
<script src="js/hoverIntent.js" type="text/javascript"></script>
<script type="text/javascript" src="js/superfish.js"></script>
<script type="text/javascript" src="js/detail.js"></script>
<link href="images/cloud-zoom.css" rel="stylesheet" type="text/css" />
<link href="css/superfish.css" rel="stylesheet" type="text/css" />
<script>

// initialise plugins
jQuery(function(){
	jQuery('#example').superfish({
		//useClick: true
	});
});

</script>
<script type="text/javascript" src="images/cloud-zoom.1.0.2.js"></script>