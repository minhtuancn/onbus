<?php
if ($_GET['randomId'] != "5PEgZBbzfpaqSaFA12_J59EWffFkL9VCKzrnEh9n19_qxXkPPqYfngZKBvXrSlhV") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
