<?php 
$idUser =(int) $_SESSION['idUser'];
if($idUser > 0) {
	$sql = "SELECT * FROM sp_luu WHERE idUser = $idUser";
	$listSP = mysql_query($sql);
}
?>
  	<div id="leftmenu">
		<?php include "blocks/page/menu_left.php"; ?>

  </div>
  <div id="profilter"
  <?php include "blocks/page/menu.php"; ?>
  
	<div id="mainpage">
    	<?php
		if(!empty($listSP)){
		while($row_sp = mysql_fetch_assoc($listSP)){
			$chitiet = $sp->getDetailSP($row_sp['sp_id']);
			$row_chitiet= mysql_fetch_assoc($chitiet);		
		?>
    	<div id="item">
            <a href="<?php echo $row_chitiet['ten_sp_vi_kd']?>-<?php echo $row_chitiet['sp_id']; ?>.html"><img src="<?php echo $sp->getImageSizeHoang($row_chitiet['hinh_dai_dien'],255); ?>" width="255" height="360" /></a><br />
            <a href="<?php echo $row_chitiet['ten_sp_vi_kd']?>-<?php echo $row_chitiet['sp_id']; ?>.html"><?php echo $row_chitiet['ten_sp_vi']; ?></a><br />
            <strong><?php echo number_format($row_chitiet['gia']-($row_chitiet['khuyen_mai']*$row_chitiet['gia'])/100);?> đ</strong>
        </div>       
        <?php } } ?>
        
    </div>
	<?php include "blocks/page/footer.php"; ?>
</div>	