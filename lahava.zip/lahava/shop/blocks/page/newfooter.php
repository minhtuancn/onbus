	<div id="footerinfo">
	<ul id="listFT">
    	<li class="shopguide">
        	<p><?php echo $sp->language('huong-dan-mua-hang',$lang); ?></p>
            <ul class="navlist">
            	<li><a href="javascript:;" idM="1" class="fmenu"><?php echo $sp->language('cac-buoc-mua-hang',$lang); ?></a></li>
                <li><a href="javascript:;"  idM="3" class="fmenu"><?php echo $sp->language('thanh-toan',$lang); ?></a></li>
                <li><a href="javascript:;"  idM="4" class="fmenu"><?php echo $sp->language('giao-nhan',$lang); ?></a></li>
                <li><a href="javascript:;"  idM="2" class="fmenu"><?php echo $sp->language('cach-chon-size',$lang); ?></a></li>
            </ul>
        </li>
        <li class="followus">
        	<p><?php echo $sp->language('theo-chung-toi',$lang); ?></p>
            <ul class="navlist">
				<li><a href="javascript:;">Blogs</a></li>
            	<li><a href="javascript:;" id="res_email"><?php echo $sp->language('dang-ki-nhan-mail',$lang); ?></a></li>
                <li><a target="_blank" href="http://facebook.com/lahava.vn">facebook</a></li>
                <li><a target="_blank" href="http://www.youtube.com/lahavacouture">youtube</a></li>
            </ul>
        </li>
        <li class="aboutus">
        	<p>LAhAVA</p>
            <ul class="navlist">
            	<li><a href="javascript:;" class="fmenu"  idM="9"><?php echo $sp->language('gioi-thieu',$lang); ?></a></li>
                <li><a href="javascript:;" class="fmenu"  idM="6"><?php echo $sp->language('hop-tac',$lang); ?></a></li>
                <li><a href="javascript:;" class="fmenu"  idM="7">showroom</a></li>
                <li><a href="javascript:;" class="fmenu"  id="contact"><?php echo $sp->language('lien-he',$lang); ?></a></li>
            </ul>
        </li>
        <li class="copyrightship">
        <div id="earthcat"><img src="images/globe.png" width="15" height="15" /></div>
        <div id="countrycat">Shipping to Worldwide</div>
        <div id="copyrightcat">© 2013 LAHAVA, All rights reserved</div>
        </li>        
    </ul>
</div>



<div id="pupPanel" class="modal" style="visibility: visible; zoom: 1; opacity: 1; top: 24px; left: 178px; z-index: 1000;">
    <div class="lt ieSh"></div><div class="rt ieSh"></div><div class="lb ieSh"></div><div class="rb ieSh"></div><div class="modalClose">
        <a href="javascript:void(0)" title="Cerrar ventana">Close</a></div><div class="modalContent"><div class="modalTitle">
                <h2 id="title_fmenu">
	<?php echo $sp->language('cac-buoc-mua-hang',$lang); ?>
</h2></div><div class="modalInfo" style="height: 320px;"><div>	
	<div>
		
		<div class="infoShoppingGuide">
			<div class="line">				
				<div class="unit size1of4 shoppingGuideNav" style="float:left;width:25%">
					<ul class="navShoppingGuide">						
                        <?php 
                        $rs = mysql_query("SELECT idMenu,ten_vi,ten_en FROM menu WHERE idMenu < 10 ORDER BY idMenu") or die(mysql_error());
                        while($row = mysql_fetch_assoc($rs)){
							if($row['idMenu']!=5 && $row['idMenu'] !=8){
                        ?>    
						<li class="ajaxNav" >
							<a href="javascript:void(0)" idM="<?php echo $row['idMenu']; ?>">
								<?php echo $row['ten_'.$lang]; ?>
							</a>
						</li>
                        <?php } } ?>
			   		</ul>
				</div>
                <div id="updatableContent" style="float: left;width:75%;font-size: 12px">
                
				</div>
			</div>
		</div>
	</div>
</div></div></div></div>

<div id="pupPanel_mail" class="modal" style="visibility: visible; zoom: 1; opacity: 1; top: 24px; left: 178px; z-index: 1000;">
</div>

<script type="text/javascript">
$(function(){
	 $('.ajaxNav a').click(function(){
        var idMenu = $(this).attr('idM');
        $('.shoppingGuideNav a').removeClass('selected');
        $(this).addClass('selected');
        $.post('ajax/getcontent.php',{idMenu:idMenu},function(data){
            
            var arrRes = JSON.parse(data);
            
            $('#updatableContent').html(arrRes.noidung_<?php echo $lang; ?>).fadeIn(1000);
            $('#title_fmenu').html(arrRes.ten_<?php echo $lang; ?>).fadeIn(1000);
        })
    })
	$(".navlist li a.fmenu,#ho_tro,#choose_size").click(function(){
		var lang = '<?php echo $lang; ?>';
        var idMenu = $(this).attr('idM');
		if(idMenu){
			$('.shoppingGuideNav a').removeClass('selected');
			$('.shoppingGuideNav a[idM='+idMenu+']').addClass('selected');
			$.post('ajax/getcontent.php',{idMenu:idMenu},function(data){
				
				var arrRes = JSON.parse(data);
				if(lang=='vi') noidung = arrRes.noidung_vi;else noidung = arrRes.noidung_en;
				if(lang=='vi') title = arrRes.ten_vi;else title = arrRes.ten_en;
							
				$('#updatableContent').html(noidung).fadeIn(1000);
				$('#title_fmenu').html(title).fadeIn(1000);
			})
			$("#che").fadeIn(500);
			$("#che").fadeTo(0,0.8);				
			var top = ($(window).height()-490)/2 - 25;
			var width = ($(window).width()-400);
			var left = ($(window).width() - width)/2 - 25;
			$("#pupPanel").css({'top':top + 'px','left' :left + "px" ,"width" : width + "px"});
			$("#pupPanel").fadeIn(1000);	
			return false;	
		}
	});	
	$("#res_email").click(function(){      	 
		$.post('blocks/page/res_email_<?php echo $lang; ?>.php',null,function(data){            
			$('#pupPanel_mail').html(data).fadeIn(1000);            
		})
		$("#che").fadeIn(500);
		$("#che").fadeTo(0,0.8);				
		var top = ($(window).height()-390)/2 - 25;
		var width = ($(window).width()-700);
		var left = ($(window).width() - width)/2 - 25;
		$("#pupPanel_mail").css({'top':top + 'px','left' :left + "px" ,"width" : width + "px","height" : '200px'});
		$("#pupPanel_mail").fadeIn(1000);	
		return false;
		
	});
	$("#contact").click(function(){       
		$.post('blocks/page/contact.php',{lang:'<?php echo $lang; ?>'},function(data){            
			$('#pupPanel').html(data).fadeIn(1000);            
		})
		$("#che").fadeIn(500);
		$("#che").fadeTo(0,0.8);				
		var top = ($(window).height()-500)/2 - 25;
		var width = ($(window).width()-700);
		var left = ($(window).width() - width)/2 - 25;
		$("#pupPanel").css({'top':top + 'px','left' :left + "px" ,"width" : width + "px","height" : '200px'});
		$("#pupPanel").fadeIn(1000);	
		return false;
		
	});
})

</script>
  
  