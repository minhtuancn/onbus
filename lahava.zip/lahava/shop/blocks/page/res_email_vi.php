<?php $lang = 'en'; ?>
<div class="lt ieSh"></div><div class="rt ieSh"></div><div class="lb ieSh"></div><div class="rb ieSh"></div><div class="modalClose">
        <a href="javascript:void(0)" title="Cerrar ventana">Đóng</a></div><div class="modalContent"><div class="modalTitle">
                <h2 id="title_fmenu">
	Đăng ký nhận Email
</h2></div><div class="modalInfo" style="height: 200px;"><div>	
	<div>
		<div class="infoLogin registerUserPanel gaTrack gaPanel" id="registerUserPanel" style="visibility: visible; opacity: 1;">
	<div class="infoSubtitle">
		<p>			
			Fill out the following form in order to register with <strong>lahava.vn</strong>.<br>
			We will save the details you provide in order to facilitate your purchases on our website.
		</p>
	</div>
	
		<div class="controls">			
			<ul class="formControls">				
				<li class="formControl">
					<div style="float:left;padding-top:5px">
					<input type="text" class="inputText required" id="email" name="email" style="float:left;height:35px;width:300px">
                    </div>
					<div class="actions" style="float:left">
                        <button id="btnSend" type="button" value="Registrar" class="button butBlack actionButton" style="padding:0px">
                            <span>GỞI</span>
                        </button>
                    </div>	
				</li>
                <li class="formControl" style="text-align:center;display:none" id="report_res">
					<span style="color:red;font-style:italic;" >Đăng ký thành công !</span>
				</li>
				
			</ul>
					
		</div>			
</div>
		
		
	</div>
</div></div></div>

<script type="text/javascript">
$(document).ready(function() { 
	 $("#btnSend").click(function(){ 		
		var email =  $('#email').val(); 	
		
		if(email==''){
			$('#email').css('border','1px solid red');
			return false;
		}else{
			$.post("ajax/check_email.php",{email:email},function(data){
				
				if(data==1) { 
					$('#email').css('border','1px solid red');	
					return false;
				}else{					
					$.post('ajax/check_email_res.php',{email:email},function(data){					
						if(data==0){
							$('#report_res').show();
							$('#email').val('');
						}else{
							$('#email').css('border','1px solid red');	
							return false;
						}
						setTimeout('dongthongbao()',4000);						
					});
				}
			})
		}
	}) 
	$("#email").blur(function(){	
		if($.trim($(this).val())){
			$(this).css('border','1px solid #666');
		}else{
		 	$(this).css('border','1px solid red');
		}
			
	});
	$("#email").blur(function(){	
		var email =  $('#email').val(); 
		$.post("ajax/check_email.php",{email:email,action:'blur'},function(data){			
			if(data==1) { 
				$('#email').css('border','1px solid red');	
				return false;
			}else{
				$('#email').css('border','1px solid #666');
			}
		})
			
	});
	
}); 
function dongthongbao(){
	$('#report_res').hide();
}
</script>