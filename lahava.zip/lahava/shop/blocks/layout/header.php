<?php 
$so_sp_gio_hang = 0;
if(isset($_SESSION['daySoLuong'])){
	$tong_so_luong = $_SESSION['daySoLuong'];
	foreach($tong_so_luong as $sl)
	{
		$so_sp_gio_hang+=$sl;
	}
}
?>
<div id="linemenu">  
    <div class="select_box">
        <span class="result_select"><?php echo ($lang=='en') ? "English" : "Vietnamese" ; ?></span>
        <div class="box_list">
            <ul>
                <li class="<?php echo ($lang=='en') ? "active" : "" ; ?>"><a href="javascript:;" lang="en">English</a></li>
                <li class="<?php echo ($lang=='vi') ? "active" : "" ; ?>"><a href="javascript:;" lang="vi">Vietnamese</a></li>
            </ul>
        </div>
    </div>
         

   
  	<div id="mybag"><img src="images/giohang.jpg" align='left' class="show_gio_hang" />
    <span class="show_gio_hang"><?php echo $tc->language('gio-hang',$lang);?></span>&nbsp;
    <span id="so_sp_gio_hang"><?php echo $so_sp_gio_hang;?> </span>
    </div>        
  </div>
<script type="text/javascript">
	$(function(){
		$("#navs > li > a").click(function () { // binding onclick
			if ($(this).parent().hasClass('selected')) {
				$(this).parent().find('.icon_up_down').attr('src','images/arrow_down.png');
				$("#nav .selected div div").slideUp(100); // hiding popups
				$("#nav .selected").removeClass("selected");
			} else {
				$(this).parent().find('.icon_up_down').attr('src','images/arrow_down.png');
				$("#nav .selected div div").slideUp(100); // hiding popups
				$("#nav .selected").removeClass("selected");
	
				if ($(this).next(".subs").length) {
					$(this).parent().find('.icon_up_down').attr('src','images/arrow_up.png');
					$(this).parent().addClass("selected"); // display popup
					$(this).next(".subs").children().slideDown(200);
					$("#slider-vertical").show();
				}
			}
		}); 
		$('#language').change(function(){			
		});
	})
</script>  