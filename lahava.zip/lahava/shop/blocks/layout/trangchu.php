<div id="indexpage">
<div id="imgsindex"><img src="images/imgsindex.jpg" width="1000" height="401" />
   	  <div class="navwedding"><a href="<?php echo $lang=='vi' ? "dam-cuoi" : "wedding-dresses"; ?>.html"><?php echo $sp->language('ao-cuoi',$lang); ?></a></div>
      <div class="navevening"><a href="<?php echo $lang=='vi' ? "dam-da-hoi" : "evening-dresses"; ?>.html"><?php echo $sp->language('dam-da-hoi',$lang); ?></a></div>
      <div class="navcocktail"><a href="<?php echo $lang=='vi' ? "dam-ngan" : "cocktail-dresses"; ?>.html"><?php echo $sp->language('dam-ngan',$lang); ?></a></div>
    </div>
    <div id="navproindex">
    	<ul id="listPro">
   	  <li class="navmargin"><a href="dam-cuoi.html"><img src="item/webnav.jpg" width="321" height="321" border="0" /></a>
       	  <div class="shopnow">shop now</div>     
          <div class="textnav">Wedding Dresses</div>
          <div class="descriptionnav">Find your dream wedding gown in LAHAVA's large selection of beautiful wedding dresses! Let LAHAVA dress everyone in your bridal party for your big day.</div>
          </li>
            <li class="navmargin"><a href="dam-da-hoi.html"><img src="item/evenav.jpg" width="321" height="321" border="0" /></a>
   	      <div class="shopnow">shop now</div>
                <div class="textnav">Evening Dresses</div>
                <div class="descriptionnav">Evening dresses are suitable for many special occasion parties. If you still do not have an awesome evening dress 2013, then buy one from LAHAVA</div>
            </li>
            <li class="navno-margin"><a href="dam-ngan.html"><img src="item/cocnav.jpg" width="321" height="321" border="0" /></a>
   	      <div class="shopnow">shop now</div>
                <div class="textnav">Cocktail Dresses</div>
                <div class="descriptionnav">Cocktail dresses are among the most adaptable of dress types and can be worn on most occasions. Depending on the style, they are even acceptable for more.</div>
            </li>
        </ul>
    </div>
    <div id="bottommid"><a target="_blank" href="http://damdahoi.com.vn/thoi-trang-vay-cuoi-long-lay-AC129.htm"><img src="item/wed5.jpg" width="323" height="450" border="0" /></a>
    <div class="promotion"><img src="images/20.png" width="60" height="80" /></div>
    	<div id="timecountdown">Váy cưới ren dạ hội<div id="countdowncontainer"></div>
<br />



</div>
    </div>
    <div id="bottomleft">
    <div id="event"><a target="_blank" href="http://damrendep.com"><img src="images/event1.gif" width="323" height="221" border="0" /></a></div>
    <div id="newletter"><input type="text" value="Đăng ký email nhận khuyến mãi mới" name="dk_email" id="dk_email" onclick="if(this.value=='Đăng ký email nhận khuyến mãi mới') this.value=''" onblur="if(this.value=='') this.value='Đăng ký email nhận khuyến mãi mới'"><span id="btnmail">GO</span></div>
    <div id="textkm"><img src="images/freeShipping.gif" width="323" height="80" /></div>
    </div>    
<div id="bottomright">
    	<div id="video"><iframe width="323" height="230" src="http://www.youtube.com/embed/pXwQGGVeUBU" frameborder="0" allowfullscreen></iframe></div>
      <div id="sharefb"><iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com%2Flahava.vn&amp;send=false&amp;layout=standard&amp;width=323&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=35" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:323px; height:35px;" allowTransparency="true"></iframe></div>
        <div id="shareiconbtn"><a href="#" target="_blank" title="Blogs - Event"><img src="images/blogicon.jpg" width="25" height="25" border="0" /></a> <a href="http://facebook.com/lahava.vn" target="_blank" title="LAHAVA on Facebook"><img src="images/fbicon.jpg" width="25" height="25" border="0" /></a> <a href="http://www.youtube.com/lahavacouture" target="_blank" title="LAHAVA on Youtube"><img src="images/youtubeicon.jpg" width="25" height="25" border="0" /></a> <a href="http://twitter.com/lahavavietnam" target="_blank" title="LAHAVA on Twitter"><img src="images/footericon.jpg" width="25" height="25" border="0" /></a></div>
    </div>
    <div id="bgdot">
    	<span class="titlebg">about lahava</span>
    </div>
    <div id="textabout">Được thành lập vào năm 2010, không phải là tiên phong nhưng với niềm đam mê và khát khao, chúng tôi sau vài năm đã từng bước khẳng định vị trí của mình trên thị trường Thời trang dạ hội - <a href="http://lahava.vn">Áo cưới</a> vốn rất sôi động ở Sài gòn nói riêng và Việt Nam nói chung. Sản phẩm của LAHAVA chủ yếu bao gồm <a href="http://lahava.vn/tag/vay-cuoi.html">váy cưới</a>, <a href="http://damdahoi.com.vn">váy dạ hội</a> và <a href="http://lahava.vn/tag/dam-du-tiec-cuoi.html">đầm dự tiệc cưới</a>.</div>
<div id="footerindex">
    	<div id="earth"><img src="images/globe.png" width="15" height="15" /></div>
        <div id="country">Shipping to Worldwide</div>
        <div id="copyright">© 2013 LAHAVA, All rights reserved</div>
    </div><br>
</div><!--index page-->